"""Read-only CPU acceptance and export. Never imports or starts a simulator."""
import argparse
import csv
import json
from pathlib import Path
import numpy as np
from paired_common import CONFIG, HERE, SEEDS, GROUP, QPOS, QVEL, RGB, CUBE, compare, no_simulator_import, read_json, read_numeric, require, sha, write_json
from saved_checks import check_run, compare_four

def numeric_fingerprint(data):
    import hashlib
    h = hashlib.sha256()
    for key in sorted(data):
        value = np.ascontiguousarray(data[key])
        h.update(json.dumps([key, value.dtype.str, list(value.shape)], separators=(',', ':')).encode('utf-8'))
        h.update(value.tobytes(order='C'))
    return h.hexdigest()

def csv_file(path, header, rows):
    with path.open('x', encoding='utf-8', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(header)
        writer.writerows(rows)

def main(data_root, output):
    if (data_root / 'files.json').is_file():
        file_hashes = read_json(data_root / 'files.json')
        require(all((sha(data_root / name) == digest for name, digest in file_hashes.items())), 'Public package file SHA-256 differs.')
    output.mkdir(parents=True, exist_ok=False)
    try:
        config = read_json(data_root / 'config.json')
        require(config == CONFIG, 'Frozen experiment config differs from implementation.')
        manifest = read_json(data_root / 'dataset_manifest.json')
        environment = read_json(data_root / 'environment.json')
        rows = manifest['sources']
        require([r['source_id'] for r in rows] == list(range(8)) and [(r['seed'], r['condition']) for r in rows] == [(s, g) for s in SEEDS for g in ('U', 'A', 'D', 'E')] and (len({r['trajectory_id'] for r in rows}) == 8) and (manifest['historical_run_count'] == 6) and (manifest['new_run_count'] == 2), 'Source mapping differs.')
        all_metrics, checks, fingerprints, output_arrays = ({}, {}, {}, {})
        actual_new, new_meta = ({}, {})
        for seed in SEEDS:
            entries = [r for r in rows if r['seed'] == seed]
            ref_folder = (data_root / entries[0]['path']).resolve()
            reference = read_numeric(ref_folder / 'rollout.npz')
            groups, metadata, audits = ({}, {}, {})
            for entry in entries:
                g = entry['condition']
                folder = (data_root / entry['path']).resolve()
                require(sha(folder / 'rollout.npz') == entry['rollout_sha256'] and entry['reused_historical_run'] == (g != 'E') and (entry['intervention'] == (g in ('A', 'D'))) and (entry['outer_reference_feedback'] == (g in ('D', 'E'))), 'Source identity/condition mismatch.')
                data, meta, audit, detail = check_run(folder, g, reference, config)
                require(meta['seed'] == seed and meta['group'] == entry['group'] and (meta['completed_steps'] == entry['completed_steps']), 'Source metadata mapping differs.')
                groups[g], metadata[g] = (data, meta)
                checks[f'{seed}-{g}'] = detail
                fingerprints[f'{seed}-{g}'] = numeric_fingerprint(data)
                if audit is not None:
                    audits[g] = audit
                if g == 'E':
                    actual_new[seed], new_meta[seed] = (data, meta)
                    actual_runtime = read_json(folder / 'runtime.json')
                    expected_runtime = environment['reference_runtime_by_seed'][str(seed)]
                    require(actual_runtime == environment['runtime_by_seed'][str(seed)], 'E runtime metadata differs.')
                    for key in ('action_space', 'timing', 'resolved_backend', 'controllers', 'sensor'):
                        require(actual_runtime[key] == expected_runtime[key], 'E runtime changed: ' + key)
                    for key in ('render_system_device', 'render_system_device_name', 'device_is_cpu', 'device_is_cuda', 'device_can_render', 'device_pci_string'):
                        require(actual_runtime['render_provenance'][key] == expected_runtime['render_provenance'][key], 'Render API provenance changed.')
            initial = {g: compare(groups['E'], groups[g], [0]) for g in ('U', 'A', 'D')}
            prefix = {'U_states_0_to_9': compare(groups['E'], groups['U'], list(range(10))), 'A_states_0_to_8': compare(groups['E'], groups['A'], list(range(9))), 'D_states_0_to_8': compare(groups['E'], groups['D'], list(range(9)))}
            e_folder = (data_root / entries[-1]['path']).resolve()
            require(all((r['within_tolerance'] for r in [*initial.values(), *prefix.values()])) and initial == read_json(e_folder / 'initial-checks.json') and (prefix == read_json(e_folder / 'prefix-checks.json')), 'Initial/prefix comparisons differ.')
            checks[f'{seed}-comparability'] = {'initial': initial, 'prefix': prefix}
            metrics, series = compare_four(groups, audits, metadata)
            all_metrics[str(seed)] = metrics
            end = metrics['common_completed_actions']
            arrays = dict(series)
            arrays.update({'all_state_indices': np.arange(end + 1, dtype=np.int64), 'all_state_time_s': reference['time_s'][:end + 1, 0].copy(), 'action_indices': np.arange(end, dtype=np.int64), 'action_time_s': reference['time_s'][:end, 0].copy()})
            for g, data in groups.items():
                arrays[f'{g}/joint1_qpos_rad'] = data[QPOS][:end + 1, 0, 0].copy()
                arrays[f'{g}/joint1_qvel_rad_s'] = data[QVEL][:end + 1, 0, 0].copy()
                arrays[f'{g}/actions'] = data['actions'][:end].copy()
                arrays[f'{g}/tracking_deviation_rad'] = data[QPOS][:end + 1, 0, 0].astype(np.float64) - reference[QPOS][:end + 1, 0, 0]
                if g in audits:
                    arrays.update({f'{g}/feedback/{k}': v.copy() for k, v in audits[g].items()})
            path = output / f'seed-{seed:04d}-comparison.npz'
            with path.open('xb') as stream:
                np.savez_compressed(stream, **arrays)
            reread = read_numeric(path)
            require(set(reread) == set(arrays) and all((np.array_equal(v, reread[k]) for k, v in arrays.items())), 'Saved comparison differs.')
            idx = reread['state_index']
            off = reread['A/joint1_qpos_rad'][idx].astype(np.float64) - reread['U/joint1_qpos_rad'][idx].astype(np.float64)
            on = reread['D/joint1_qpos_rad'][idx].astype(np.float64) - reread['E/joint1_qpos_rad'][idx].astype(np.float64)
            require(np.array_equal(off, reread['r_off_rad']) and np.array_equal(on, reread['r_on_rad']) and np.array_equal(on - off, reread['r_on_minus_r_off_rad']), 'Reopened paired responses differ.')
            csv_file(output / f'seed-{seed:04d}-states.csv', ['state_index', 'simulation_time_s', *[f'{g}_q1_rad' for g in groups], 'r_off_rad', 'r_on_rad', 'r_on_minus_r_off_rad'], ([k, float(reference['time_s'][k, 0]), *[float(groups[g][QPOS][k, 0, 0]) for g in groups], *(float(x[k - 9]) if k >= 9 else 'not_in_comparison' for x in (series['r_off_rad'], series['r_on_rad'], series['r_on_minus_r_off_rad']))] for k in range(end + 1)))
            csv_file(output / f'seed-{seed:04d}-actions.csv', ['action_index', 'simulation_time_s', 'U', 'A', 'D', 'E'], ([t, float(reference['time_s'][t, 0]), *[float(groups[g]['actions'][t, 0]) for g in groups]] for t in range(end)))
            for g, audit in audits.items():
                csv_file(output / f'seed-{seed:04d}-{g}-feedback.csv', ['t', *[k for k in audit if k != 't' and k != 'controller_target_qpos']], ([int(audit['t'][j]), *[audit[k][j].item() for k in audit if k not in ('t', 'controller_target_qpos')]] for j in range(len(audit['t']))))
            output_arrays[seed] = arrays
        metrics_doc = {'version': config['version'], 'seeds': all_metrics, 'new_runs': 2, 'historical_runs_reused': 6, 'units': {'angle': 'rad', 'velocity': 'rad/s', 'cube_displacement': 'm', 'time': 's'}, 'no_significance_test': True, 'no_training': True}
        write_json(output / 'metrics.json', metrics_doc)
        require(read_json(output / 'metrics.json') == metrics_doc, 'Reopened metrics differ.')
        local = {'performed': False}
        no_simulator_import()
        report = {'status': 'passed', 'scope': 'Independent saved-file CPU numerical acceptance; visual review recorded separately', 'verified_pngs': sum((v.get('verified_pngs', 0) for v in checks.values())), 'new_runs': 2, 'historical_runs_reused': 6, 'checks': checks, 'numeric_content_fingerprints': fingerprints, 'local_integrity': local, 'N_and_N_plus_one': True, 'PNG_pixels_equal_RGB': True, 'feedback_recomputed_independently': True, 'metrics_reopened_and_recomputed': True, 'pure_numeric_npz': True, 'simulation_calls': 0, 'training_calls': 0, 'statistics_fits': 0}
        write_json(output / 'validation.json', report)
        print(json.dumps({'status': 'passed', 'verified_pngs': report['verified_pngs'], 'new_runs': 2, 'local_integrity': local, 'seed_results': all_metrics}, ensure_ascii=True), flush=True)
    except Exception as error:
        write_json(output / 'failure.json', {'type': type(error).__name__, 'message': str(error), 'simulation_calls': 0})
        raise
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-root', type=Path, default=HERE)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    main(args.data_root.resolve(), args.output_dir)
