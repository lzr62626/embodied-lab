"""Independent saved-file checks; no simulation imports and no capture controller calls."""
from pathlib import Path
import numpy as np
from PIL import Image
from paired_common import QPOS, QVEL, RGB, CUBE, SUCCESS, STATE_ATOL, compare, plan, read_json, read_numeric, require

F64 = ("q_ref", "q_actual", "error_rad", "u_ff", "correction", "u_raw", "u_clipped_float64")
AUDIT_FIELDS = set(F64) | {"t", "reference_state_index", "actual_state_index", "u_sent", "was_clipped",
                           "sent_at_bound", "controller_target_qpos"}


def check_feedback(data, reference, audit, config):
    times = np.arange(9, len(data["actions"]), dtype=np.int64)
    require(set(audit) == AUDIT_FIELDS and len(times) > 0, "Feedback audit fields/count differ.")
    for key in ("t", "reference_state_index", "actual_state_index"):
        require(audit[key].dtype == np.int64 and np.array_equal(audit[key], times), "Feedback time/index mismatch.")
    for key in F64:
        require(audit[key].shape == (len(times),) and audit[key].dtype == np.float64, "Feedback float64 axes/type differ.")
    require(audit["u_sent"].shape == (len(times),) and audit["u_sent"].dtype == np.float32
            and all(audit[key].shape == (len(times),) and audit[key].dtype == np.bool_
                    for key in ("was_clipped", "sent_at_bound"))
            and audit["controller_target_qpos"].shape == (len(times), 7)
            and audit["controller_target_qpos"].dtype == np.float32, "Feedback output/audit layout differs.")
    expected = {key: [] for key in F64}
    sent, clipped, touched = [], [], []
    bound = config["clip_limit_float64_from_float32"]
    for t in times:
        ref = float(reference[QPOS][t, 0, 0])
        actual = float(data[QPOS][t, 0, 0])
        ff = float(reference["actions"][t, 0])
        error = ref - actual
        correction = config["gain"] * error / config["joint_delta_scale_rad"]
        raw = ff + correction
        limited = min(bound, max(-bound, raw))
        value = np.float32(limited)
        for key, item in zip(F64, (ref, actual, error, ff, correction, raw, limited)):
            expected[key].append(item)
        sent.append(value)
        clipped.append(raw < -bound or raw > bound)
        touched.append(abs(value) == np.float32(bound))
    differences = {key: float(np.max(np.abs(audit[key] - np.asarray(values, dtype=np.float64))))
                   for key, values in expected.items()}
    require(all(v <= config["numeric_audit_atol"] for v in differences.values()), "Independent feedback formula differs.")
    require(np.array_equal(audit["u_sent"], np.array(sent, dtype=np.float32))
            and np.array_equal(audit["u_sent"], data["actions"][times, 0])
            and np.array_equal(audit["was_clipped"], np.array(clipped, dtype=np.bool_))
            and np.array_equal(audit["sent_at_bound"], np.array(touched, dtype=np.bool_))
            and np.array_equal(audit["controller_target_qpos"], data["diagnostic/arm_target_qpos"][times, 0]),
            "Actual sent command, clipping/touch flag or controller target differs.")
    return differences


def check_run(folder, condition, reference, config, *, check_png=True):
    folder = Path(folder)
    data, meta = read_numeric(folder / "rollout.npz"), read_json(folder / "run.json")
    n = len(data["actions"])
    require(9 < n <= 20 and meta["completed_steps"] == meta["step_attempts"] == n
            and meta["explicit_reset_calls"] == 1 and meta["step_cap"] <= 20, "Invalid run length/accounting.")
    base_fields = {k: v for k, v in reference.items() if not k.startswith("audit/")}
    allowed = set(base_fields)
    if condition == "A":
        allowed |= {"audit/action_source", "audit/intervention", "audit/policy_active"}
    elif condition in ("D", "E"):
        allowed |= {"audit/action_source", "audit/intervention", "audit/feedback_active"}
    require(set(data) == allowed, "Unexpected trajectory fields.")
    for key, original in base_fields.items():
        state = key.startswith("obs/") or key in (CUBE, "step_index", "time_s")
        shape = original.shape if key.startswith("reset_info/") else (n + int(state), *original.shape[1:])
        require(data[key].shape == shape and data[key].dtype == original.dtype, "Field shape/type mismatch: " + key)
    for key in allowed - set(base_fields):
        require(data[key].shape == (n,) and data[key].dtype == (np.int64 if key.endswith("action_source") else np.bool_),
                "Invalid provenance axis/type.")
    require(np.array_equal(data["step_index"][:, 0], np.arange(n + 1))
            and np.array_equal(data["info/elapsed_steps"][:, 0], np.arange(1, n + 1))
            and np.array_equal(data["time_s"][:, 0], np.arange(n + 1, dtype=np.float64) * .05)
            and data["reset_info/elapsed_steps"].tolist() == [0], "Transition/state time alignment differs.")
    done = (data["terminated"] | data["truncated"])[:, 0]
    require(not done[:-1].any() and (n == meta["step_cap"] or done[-1])
            and meta["stopping_reason"] == ("terminated_or_truncated" if done[-1] else "step_budget")
            and meta["success_any"] == bool(data[SUCCESS].any()), "Episode boundary or budget flag differs.")
    actions = data["actions"]
    require(actions.dtype == np.float32 and np.all(np.abs(actions) <= 1)
            and np.all(np.abs(actions[:, 0]) <= np.float32(config["command_limit_float32"]))
            and np.all(actions[:, 1:7] == 0) and np.all(actions[:, 7] == 1), "Action bounds/interface differ.")
    expected = plan()[:n]
    if condition == "A":
        expected[8, 0] = np.float32(.1)
    if condition in ("U", "A"):
        require(np.array_equal(actions, expected), "Historical script plan differs.")
    else:
        if condition == "D":
            expected[8, 0] = np.float32(.1)
        require(np.array_equal(actions[:9], expected[:9]), "Prefix or intervention differs.")
    if condition != "U":
        labels = np.array([0] * 8 + [1] + [2] * (n - 9), dtype=np.int64)
        if condition == "E":
            labels[8] = 0
        intervention = np.arange(n) == 8 if condition in ("A", "D") else np.zeros(n, dtype=np.bool_)
        require(np.array_equal(data["audit/action_source"], labels)
                and np.array_equal(data["audit/intervention"], intervention),
                "Intervention/provenance labels differ.")
        active = "audit/policy_active" if condition == "A" else "audit/feedback_active"
        require(np.array_equal(data[active], np.zeros(n, dtype=np.bool_) if condition == "A" else np.arange(n) >= 9),
                "Feedback activation differs.")
    audit, audit_errors = None, None
    if condition in ("D", "E"):
        audit = read_numeric(folder / "feedback_audit.npz")
        audit_errors = check_feedback(data, reference, audit, config)
        require(meta["feedback_decisions"] == n - 9 and meta["intervention_calls"] == int(condition == "D"),
                "Feedback decision metadata differs.")
    target = data[QPOS][:-1, 0, :7].astype(np.float64) + actions[:, :7].astype(np.float64) * .1
    target_error = float(np.max(np.abs(target - data["diagnostic/arm_target_qpos"][:, 0])))
    require(target_error <= config["controller_target_atol_rad"], "PD target mapping differs from current-position delta.")
    count = 0
    if check_png:
        files = sorted((folder / "frames").glob("*.png"))
        require([p.name for p in files] == [f"{s:04d}.png" for s in range(n + 1)], "Raw frame names/count differ.")
        for s, path in enumerate(files):
            with Image.open(path) as image:
                require(image.mode == "RGB" and image.size == (256, 256)
                        and np.array_equal(np.asarray(image), data[RGB][s, 0]), "PNG/RGB pixel mismatch.")
            count += 1
    return data, meta, audit, {"verified_pngs": count, "fields": len(data), "steps": n,
                              "feedback_formula_max_abs_errors": audit_errors, "controller_target_max_abs_error_rad": target_error}


def summary(delta):
    a = np.asarray(delta, dtype=np.float64)
    require(a.ndim == 1 and len(a) > 0 and np.isfinite(a).all(), "Invalid metric series.")
    result = {"max_abs_rad": float(np.abs(a).max()), "rmse_rad": float(np.sqrt(np.mean(a * a, dtype=np.float64))),
              "end_signed_rad": float(a[-1]), "end_abs_rad": float(abs(a[-1]))}
    # Different scalar reduction independently cross-checks the reported aggregation.
    direct = (sum(float(x) ** 2 for x in a) / len(a)) ** .5
    require(abs(direct - result["rmse_rad"]) <= 1e-12, "Metric reduction cross-check failed.")
    return result


def compare_four(groups, audits, metadata):
    end = min(len(d["actions"]) for d in groups.values())
    require(end >= 10, "Insufficient common post-takeover coverage.")
    indices = np.arange(9, end + 1, dtype=np.int64)
    angles = {g: d[QPOS][:end + 1, 0, 0].astype(np.float64) for g, d in groups.items()}
    r_off = angles["A"][indices] - angles["U"][indices]
    r_on = angles["D"][indices] - angles["E"][indices]
    series = {"state_index": indices, "time_s": groups["U"]["time_s"][indices, 0].copy(),
              "r_off_rad": r_off, "r_on_rad": r_on, "r_on_minus_r_off_rad": r_on - r_off}
    outcomes = {}
    for condition, data in groups.items():
        n = len(data["actions"])
        cube_delta = data[CUBE][-1, 0, :3].astype(np.float64) - data[CUBE][0, 0, :3]
        outcome = {"reused_historical_run": condition != "E", "actual_steps": n,
                   "simulation_time_s": float(data["time_s"][-1, 0]),
                   "cube_net_xyz_m": cube_delta.tolist(), "cube_net_displacement_m": float(np.linalg.norm(cube_delta)),
                   "reward_sum": float(data["rewards"].astype(np.float64).sum()),
                   "success_any": bool(data[SUCCESS].any()), "success_final": bool(data[SUCCESS][-1, 0]),
                   "terminated_final": bool(data["terminated"][-1, 0]), "truncated_final": bool(data["truncated"][-1, 0]),
                   "stopping_reason": metadata[condition]["stopping_reason"]}
        if condition in audits:
            audit = audits[condition]
            outcome.update(feedback_decisions=len(audit["t"]), clipped_decisions=int(audit["was_clipped"].sum()),
                           sent_at_bound_decisions=int(audit["sent_at_bound"].sum()),
                           touch_without_clipping=int((audit["sent_at_bound"] & ~audit["was_clipped"]).sum()),
                           max_abs_correction=float(np.abs(audit["correction"]).max()))
        outcomes[condition] = outcome
    full_end = min(len(groups["E"]["actions"]), len(groups["U"]["actions"]))
    clean_delta = groups["E"][QPOS][:full_end + 1, 0, 0].astype(np.float64) - groups["U"][QPOS][:full_end + 1, 0, 0]
    action_delta = groups["E"]["actions"][:full_end, 0].astype(np.float64) - groups["U"]["actions"][:full_end, 0]
    result = {"comparison_state_indices": indices.tolist(), "common_completed_actions": end,
              "r_off_A_minus_U": summary(r_off), "r_on_D_minus_E": summary(r_on),
              "tracking_relative_to_U": {g: summary(angles[g][indices] - angles["U"][indices]) for g in ("A", "D", "E")},
              "E_vs_U_without_intervention": {"state_indices": list(range(full_end + 1)),
                  "angle": summary(clean_delta), "actions_exact": bool(np.array_equal(groups["E"]["actions"][:full_end], groups["U"]["actions"][:full_end])),
                  "max_abs_action0_difference": float(np.abs(action_delta).max()),
                  "actions_changed_count": int(np.count_nonzero(action_delta)),
                  "qpos_exact": bool(np.array_equal(groups["E"][QPOS][:full_end + 1], groups["U"][QPOS][:full_end + 1])),
                  "qvel_exact": bool(np.array_equal(groups["E"][QVEL][:full_end + 1], groups["U"][QVEL][:full_end + 1])),
                  "RGB_exact": bool(np.array_equal(groups["E"][RGB][:full_end + 1], groups["U"][RGB][:full_end + 1]))},
              "outcomes": outcomes,
              "interpretation": "Signed paired responses under the frozen rules; no significance test, independence or task-success claim."}
    return result, series
