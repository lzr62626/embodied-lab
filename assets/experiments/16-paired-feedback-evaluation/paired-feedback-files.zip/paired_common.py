"""Portable saved-file helpers; private collection/maintenance helpers omitted."""

import hashlib
import json
from pathlib import Path
import sys
import numpy as np

HERE = Path(__file__).resolve().parent

SEEDS = (45, 46)

GROUP = "E-unperturbed-reference-feedback"

QPOS, QVEL = "obs/agent/qpos", "obs/agent/qvel"

RGB, CUBE, SUCCESS = "obs/sensor_data/base_camera/rgb", "diagnostic/cube_pose", "info/success"

STATE_ATOL = {QPOS: 1e-6, QVEL: 1e-5, CUBE: 1e-6}

TASK = {"task": "PushCube-v1", "robot": "panda", "num_envs": 1,
        "obs_mode": "rgb", "control_mode": "pd_joint_delta_pos", "camera": "base_camera",
        "width": 256, "height": 256, "shader_pack": "minimal",
        "sim_backend": "cpu", "render_backend": "cpu"}

CONFIG = {
    "version": "paired-feedback-evaluation-v1", "seeds": list(SEEDS), "group": GROUP,
    "new_runs": 2, "max_steps_per_run": 20, "max_step_attempts_total": 40,
    "gain": 1.0, "joint_delta_scale_rad": .1,
    "command_limit_nominal": .1, "command_limit_float32": float(np.float32(.1)),
    "clip_limit_float64_from_float32": float(np.float32(.1)),
    "boundary_rule": "Clip in float64 against the existing float32 interface bound, then cast to float32",
    "clipped_flag": "unclipped value strictly outside the fixed interface bounds",
    "touch_flag": "actual float32 sent value equals either fixed bound; not synonymous with clipping",
    "reference_observation_index": "t, never t+1", "actual_observation_index": "t",
    "formula": "e=q_ref[t]-q_actual[t]; c=1.0*e/0.1rad; raw=u_ff[t]+c; sent=float32(clip(raw))",
    "prefix_action_indices": list(range(9)), "override_count": 0,
    "feedback_takeover_t": 9, "action_source_labels": {"0": "original_script_0_to_8", "2": "reference_feedback_9_onward"},
    "initial_and_prefix_atol": STATE_ATOL, "numeric_audit_atol": 1e-12,
    "numeric_audit_rtol": 0.0, "sent_action_comparison": "exact float32 equality",
    "controller_target_atol_rad": 1e-6, "metric_calculation_dtype": "float64",
    "compute_device": "cpu", "training_calls": 0, "statistics_fits": 0,
    "model_updates": 0, "candidate_expansions": 0, "task": TASK,
    "comparison_start_state_index": 9,
    "reset_note": "One explicit seeded reset per run; constructor initialization recorded separately.",
    "interpretation": "Two previously used seeds; historical U/A/D reused; finite paired comparisons, not independent randomized trials.",
}

def require(condition, message):
    if not condition:
        raise ValueError(message)

def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def write_json(path, data):
    with Path(path).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")

def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def read_numeric(path):
    with np.load(path, allow_pickle=False) as archive:
        data = {key: archive[key].copy() for key in archive.files}
    require(all(v.dtype.kind in "buif" and np.isfinite(v).all() for v in data.values()),
            "Non-finite or non-numeric saved input: " + str(path))
    return data

def no_simulator_import():
    require(not any(name == prefix or name.startswith(prefix + ".")
                    for name in sys.modules for prefix in ("mani_skill", "sapien", "gymnasium")),
            "Offline operation imported a simulator.")

def plan():
    actions = np.zeros((20, 8), dtype=np.float32)
    actions[:, 0] = np.repeat(np.array([.1, -.1, .1, -.1], dtype=np.float32), 5)
    actions[:, 7] = 1
    return actions

def compare(actual, reference, indices):
    fields = {}
    for key, atol in STATE_ATOL.items():
        a, b = actual[key][indices], reference[key][indices]
        require(a.shape == b.shape, "State comparison shape mismatch.")
        delta = np.abs(a.astype(np.float64) - b.astype(np.float64))
        row = {"atol": atol, "max_abs": float(delta.max()), "exact": bool(np.array_equal(a, b)),
               "within_tolerance": bool(np.all(delta <= atol))}
        if key in (QPOS, QVEL):
            row.update(arm_max_abs=float(delta[..., :7].max()), finger_max_abs=float(delta[..., 7:].max()),
                       arm_unit="rad" if key == QPOS else "rad/s", finger_unit="m" if key == QPOS else "m/s")
        else:
            row.update(xyz_max_abs_m=float(delta[..., :3].max()), quaternion_max_abs=float(delta[..., 3:].max()))
        fields[key] = row
    return {"state_indices": list(indices), "fields": fields,
            "within_tolerance": all(v["within_tolerance"] for v in fields.values()),
            "exact": all(v["exact"] for v in fields.values())}
