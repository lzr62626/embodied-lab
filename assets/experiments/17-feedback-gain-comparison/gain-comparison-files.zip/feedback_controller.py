"""Explicit non-negative gain, fixed physical scale and existing float32 command bounds."""
import numpy as np

JOINT_DELTA_SCALE_RAD = np.float64(.1)
COMMAND_LIMIT_FLOAT32 = np.float32(.1)
COMMAND_LIMIT_FLOAT64 = np.float64(COMMAND_LIMIT_FLOAT32)


def finite_scalar(value, name):
    array = np.asarray(value)
    if array.ndim != 0 or array.dtype.kind not in "iuf" or not np.isfinite(array).item():
        raise ValueError("Expected finite scalar: " + name)
    return np.float64(array)


def feedback(q_ref, q_actual, u_ff, gain):
    """Live collection permits only protocol gains .5/2; gains0/1 support offline checks."""
    reference = finite_scalar(q_ref, "q_ref")
    actual = finite_scalar(q_actual, "q_actual")
    ff = finite_scalar(u_ff, "u_ff")
    coefficient = finite_scalar(gain, "gain")
    if coefficient < 0 or abs(ff) > COMMAND_LIMIT_FLOAT64:
        raise ValueError("Gain must be non-negative and feedforward inside fixed demonstration bounds.")
    error = np.float64(reference - actual)
    correction = np.float64(coefficient * error / JOINT_DELTA_SCALE_RAD)
    raw = np.float64(ff + correction)
    if not np.isfinite([error, correction, raw]).all():
        raise ValueError("Non-finite feedback calculation.")
    limited = np.float64(np.clip(raw, -COMMAND_LIMIT_FLOAT64, COMMAND_LIMIT_FLOAT64))
    sent = np.float32(limited)
    return {"gain": coefficient, "joint_delta_scale": JOINT_DELTA_SCALE_RAD,
            "q_ref": reference, "q_actual": actual, "error_rad": error,
            "u_ff": ff, "correction": correction, "u_raw": raw,
            "u_clipped_float64": limited, "u_sent": sent,
            "was_clipped": np.bool_(raw < -COMMAND_LIMIT_FLOAT64 or raw > COMMAND_LIMIT_FLOAT64),
            "sent_at_bound": np.bool_(abs(sent) == COMMAND_LIMIT_FLOAT32)}
