"""Portable protocol constants and pure saved-data helpers; no private maintenance or collection code."""

from pathlib import Path
import numpy as np
from numeric_helpers import QPOS,QVEL,RGB,CUBE,SUCCESS,STATE_ATOL,require,read_json,write_json,read_numeric,sha,compare,plan,no_simulator_import

HERE = Path(__file__).resolve().parent

SEEDS = (45, 46)

GROUP_GAINS = {"G0": 0.0, "G05": .5, "G1": 1.0, "G2": 2.0}

NEW_GROUPS = {"G05": "G05-reference-feedback", "G2": "G2-reference-feedback"}

RUN_ORDER = [(seed, condition) for seed in SEEDS for condition in ("G05", "G2")]

TASK = {"task": "PushCube-v1", "robot": "panda", "num_envs": 1,
        "obs_mode": "rgb", "control_mode": "pd_joint_delta_pos", "camera": "base_camera",
        "width": 256, "height": 256, "shader_pack": "minimal", "sim_backend": "cpu", "render_backend": "cpu"}

CONFIG = {
    "version": "feedback-gain-comparison-v1", "seeds": list(SEEDS), "group_gains": GROUP_GAINS,
    "new_gains": [.5, 2.0], "new_groups": NEW_GROUPS, "run_order": [[s, g] for s, g in RUN_ORDER],
    "new_runs": 4, "max_steps_per_run": 20, "max_step_attempts_total": 80,
    "joint_delta_scale_rad": .1, "command_limit_nominal": .1,
    "command_limit_float32": float(np.float32(.1)), "clip_limit_float64_from_float32": float(np.float32(.1)),
    "boundary_rule": "Clip in float64 against the existing float32 interface bound, then cast to float32",
    "clipped_flag": "unclipped value strictly outside the fixed interface bounds",
    "touch_flag": "actual float32 sent value equals either fixed bound; not synonymous with clipping",
    "reference_observation_index": "t, never t+1", "actual_observation_index": "t",
    "formula": "e=q_ref[t]-q_actual[t]; c=gain*e/0.1rad; raw=u_ff[t]+c; sent=float32(clip(raw))",
    "prefix_action_indices": list(range(8)), "override_t": 8, "override_action0": .1,
    "feedback_takeover_t": 9, "action_source_labels": {"0": "common_script_prefix", "1": "forced_override", "2": "reference_feedback"},
    "G0_source2_note": "Historical source2 means script continuation; policy_active always false; no real outer-feedback queries.",
    "initial_and_prefix_atol": STATE_ATOL, "numeric_audit_atol": 1e-12, "numeric_audit_rtol": 0.0,
    "sent_action_comparison": "exact float32 equality", "controller_target_atol_rad": 1e-6,
    "metric_calculation_dtype": "float64", "comparison_start_state_index": 9,
    "compute_device": "cpu", "training_calls": 0, "statistics_fits": 0, "model_updates": 0,
    "candidate_expansions": 0, "task": TASK,
    "reset_note": "One explicit seeded reset per new run; constructor initialization recorded separately.",
    "interpretation": "Two previously used seeds; G0 is historical script action-equivalent to gain0, G1 historical gain1; only G05/G2 newly collected. No new clean-condition controls or gain selection.",
}
