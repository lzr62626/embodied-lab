"""Read-only CPU verification, gain comparison and numeric export; never simulates."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import numpy as np
from gain_common import CONFIG, HERE, SEEDS, RUN_ORDER, NEW_GROUPS, GROUP_GAINS, QPOS, QVEL, CUBE, RGB, SUCCESS, compare, read_json, read_numeric, require, sha, no_simulator_import, write_json
from saved_checks import check_run, summary

def numeric_fingerprint(data):
    h = hashlib.sha256()
    for key in sorted(data):
        value = np.ascontiguousarray(data[key])
        h.update(json.dumps([key, value.dtype.str, list(value.shape)], separators=(',', ':')).encode('utf-8'))
        h.update(value.tobytes(order='C'))
    return h.hexdigest()

def csv_file(path, header, rows):
    with path.open('x', encoding='utf-8', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(header)
        writer.writerows(rows)

def group_metrics(data, meta, audit, reference, indices, condition):
    deviation = data[QPOS][indices, 0, 0].astype(np.float64) - reference[QPOS][indices, 0, 0].astype(np.float64)
    result = summary(deviation)
    xyz = data[CUBE][-1, 0, :3].astype(np.float64) - data[CUBE][0, 0, :3]
    start, end = (int(indices[0]), int(indices[-1]))
    post_actions = data['actions'][9:end, 0]
    result.update(gain=GROUP_GAINS[condition], reused_historical_run=condition in ('G0', 'G1'), comparison_state_indices=indices.tolist(), actual_steps=len(data['actions']), simulation_time_s=float(data['time_s'][-1, 0]), cube_net_xyz_m=xyz.tolist(), cube_net_displacement_m=float(np.linalg.norm(xyz)), reward_sum=float(data['rewards'].astype(np.float64).sum()), success_any=bool(data[SUCCESS].any()), success_final=bool(data[SUCCESS][-1, 0]), terminated_final=bool(data['terminated'][-1, 0]), truncated_final=bool(data['truncated'][-1, 0]), stopping_reason=meta['stopping_reason'], compared_post9_action_indices=list(range(9, end)), actual_post9_action_touch_count=int(np.count_nonzero(np.abs(post_actions) == np.float32(CONFIG['command_limit_float32']))))
    if audit is None:
        result.update(feedback_decisions=0, max_abs_correction=None, clipped_decisions=None, clipped_action_indices=None, sent_at_bound_decisions=None, touch_without_clipping=None, feedback_statistics_note='Not applicable:historical script,not actual feedback queries;gain0 action equivalence checked offline.')
    else:
        result.update(feedback_decisions=len(audit['t']), max_abs_correction=float(np.abs(audit['correction']).max()), clipped_decisions=int(audit['was_clipped'].sum()), clipped_action_indices=audit['t'][audit['was_clipped']].tolist(), sent_at_bound_decisions=int(audit['sent_at_bound'].sum()), touch_without_clipping=int((audit['sent_at_bound'] & ~audit['was_clipped']).sum()), feedback_action_indices=audit['t'].tolist())
    return (result, deviation)

def main(data_root, output):
    if (data_root / 'files.json').is_file():
        expected_files = read_json(data_root / 'files.json')
        require(all((sha(data_root / name) == digest for name, digest in expected_files.items())), 'Public package SHA-256 differs.')
    output.mkdir(parents=True, exist_ok=False)
    try:
        config = read_json(data_root / 'config.json')
        require(config == CONFIG, 'Frozen configuration differs.')
        manifest, environment = (read_json(data_root / 'dataset_manifest.json'), read_json(data_root / 'environment.json'))
        rows = manifest['sources']
        expected = [(s, g) for s in SEEDS for g in ('U', 'G0', 'G05', 'G1', 'G2')]
        require([r['source_id'] for r in rows] == list(range(10)) and [(r['seed'], r['condition']) for r in rows] == expected and (len({r['trajectory_id'] for r in rows}) == 10) and (manifest['historical_run_count'] == 6) and (manifest['new_run_count'] == 4), 'Source mapping differs.')
        results, checks, fingerprints, new_data, new_meta, equivalent = ({}, {}, {}, {}, {}, 0)
        for seed in SEEDS:
            entries = [r for r in rows if r['seed'] == seed]
            reference = read_numeric((data_root / entries[0]['path']).resolve() / 'rollout.npz')
            groups, audits, metadata = ({}, {}, {})
            for entry in entries:
                g = entry['condition']
                folder = (data_root / entry['path']).resolve()
                require(sha(folder / 'rollout.npz') == entry['rollout_sha256'] and entry['gain'] == GROUP_GAINS.get(g) and (entry['reused_historical_run'] == (g in ('U', 'G0', 'G1'))) and (entry['intervention'] == (g != 'U')) and (entry['outer_reference_feedback'] == (g not in ('U', 'G0'))) and (entry['G0_action_equivalent_only'] == (g == 'G0')), 'Source condition/identity differs.')
                kind = 'U' if g == 'U' else 'A' if g == 'G0' else 'D'
                data, meta, audit, detail = check_run(folder, kind, reference, {**config, 'gain': GROUP_GAINS.get(g, 0.0)})
                require(meta['seed'] == seed and meta['group'] == entry['group'] and (meta['completed_steps'] == entry['completed_steps']), 'Metadata identity differs.')
                groups[g], metadata[g] = (data, meta)
                fingerprints[f'{seed}-{g}'] = numeric_fingerprint(data)
                checks[f'{seed}-{g}'] = detail
                if audit is not None:
                    audits[g] = audit
                if g == 'G0':
                    require(not (folder / 'feedback_audit.npz').exists(), 'G0 must not acquire a fabricated feedback audit.')
                    for t in range(9, len(data['actions'])):
                        ff = float(reference['actions'][t, 0])
                        zero_gain_raw = ff + 0.0 * (float(reference[QPOS][t, 0, 0]) - float(data[QPOS][t, 0, 0])) / 0.1
                        bound = config['clip_limit_float64_from_float32']
                        require(np.float32(min(bound, max(-bound, zero_gain_raw))) == data['actions'][t, 0], 'Gain0 action equivalence differs.')
                        equivalent += 1
                if g in NEW_GROUPS:
                    require(meta['condition'] == g and meta['gain'] == GROUP_GAINS[g] and (set(audit) >= {'gain', 'joint_delta_scale'}), 'New gain audit metadata differs.')
                    new_data[seed, g], new_meta[seed, g] = (data, meta)
                    actual_runtime = read_json(folder / 'runtime.json')
                    expected_runtime = environment['reference_runtime_by_seed'][str(seed)]
                    require(actual_runtime == environment['runtime_by_run'][meta['run_id']], 'Runtime metadata differs.')
                    for key in ('action_space', 'timing', 'resolved_backend', 'controllers', 'sensor'):
                        require(actual_runtime[key] == expected_runtime[key], 'Non-gain runtime differs: ' + key)
                    for key in ('render_system_device', 'render_system_device_name', 'device_is_cpu', 'device_is_cuda', 'device_can_render', 'device_pci_string'):
                        require(actual_runtime['render_provenance'][key] == expected_runtime['render_provenance'][key], 'Render device API differs.')
            for entry in [r for r in entries if r['condition'] in NEW_GROUPS]:
                g = entry['condition']
                initial = {k: compare(groups[g], groups[k], [0]) for k in ('U', 'G0', 'G1')}
                prefix = {'G0_states_0_to_9': compare(groups[g], groups['G0'], list(range(10))), 'G1_states_0_to_9': compare(groups[g], groups['G1'], list(range(10))), 'U_states_0_to_8': compare(groups[g], reference, list(range(9)))}
                folder = (data_root / entry['path']).resolve()
                require(all((r['within_tolerance'] for r in [*initial.values(), *prefix.values()])) and initial == read_json(folder / 'initial-checks.json') and (prefix == read_json(folder / 'prefix-checks.json')), 'Shared start/prefix/intervention not comparable.')
                checks[f'{seed}-{g}-comparability'] = {'initial': initial, 'prefix': prefix}
            end = min((len(data['actions']) for data in groups.values()))
            require(end >= 10, 'Insufficient post-takeover coverage.')
            idx = np.arange(9, end + 1, dtype=np.int64)
            arrays = {'comparison_state_indices': idx, 'all_state_indices': np.arange(end + 1, dtype=np.int64), 'all_state_time_s': reference['time_s'][:end + 1, 0].copy(), 'action_indices': np.arange(end, dtype=np.int64), 'action_time_s': reference['time_s'][:end, 0].copy()}
            per_gain = {}
            for g, data in groups.items():
                arrays[f'{g}/joint1_qpos_rad'] = data[QPOS][:end + 1, 0, 0].copy()
                arrays[f'{g}/joint1_qvel_rad_s'] = data[QVEL][:end + 1, 0, 0].copy()
                arrays[f'{g}/actions'] = data['actions'][:end].copy()
                arrays[f'{g}/tracking_deviation_rad'] = data[QPOS][:end + 1, 0, 0].astype(np.float64) - reference[QPOS][:end + 1, 0, 0]
                if g != 'U':
                    per_gain[g], _ = group_metrics(data, metadata[g], audits.get(g), reference, idx, g)
                if g in audits:
                    arrays.update({f'{g}/feedback/{k}': v.copy() for k, v in audits[g].items()})
            results[str(seed)] = {'common_completed_actions': end, 'comparison_state_indices': idx.tolist(), 'groups': per_gain, 'reference': {'source': 'article13 same-seed U', 'actual_steps': len(reference['actions'])}}
            with (output / f'seed-{seed:04d}-comparison.npz').open('xb') as stream:
                np.savez_compressed(stream, **arrays)
            reread = read_numeric(output / f'seed-{seed:04d}-comparison.npz')
            require(set(arrays) == set(reread) and all((np.array_equal(a, reread[k]) for k, a in arrays.items())), 'Exported comparison differs.')
            for g, recorded in per_gain.items():
                dev = reread[f'{g}/joint1_qpos_rad'][idx].astype(np.float64) - reread['U/joint1_qpos_rad'][idx].astype(np.float64)
                calculated = summary(dev)
                require(all((calculated[k] == recorded[k] for k in calculated)), 'Independent reopened metric differs.')
            csv_file(output / f'seed-{seed:04d}-states.csv', ['state_index', 'time_s', *[f'{g}_q1_rad' for g in groups], *[f'{g}_minus_U_rad' for g in GROUP_GAINS]], ([k, float(reference['time_s'][k, 0]), *[float(groups[g][QPOS][k, 0, 0]) for g in groups], *[float(arrays[f'{g}/tracking_deviation_rad'][k]) for g in GROUP_GAINS]] for k in range(end + 1)))
            csv_file(output / f'seed-{seed:04d}-actions.csv', ['action_index', 'time_s', *groups], ([t, float(reference['time_s'][t, 0]), *[float(groups[g]['actions'][t, 0]) for g in groups]] for t in range(end)))
            for g, audit in audits.items():
                fields = [k for k in audit if k != 'controller_target_qpos']
                csv_file(output / f'seed-{seed:04d}-{g}-feedback.csv', fields, ([audit[k][j].item() for k in fields] for j in range(len(audit['t']))))
        metrics = {'version': config['version'], 'seeds': results, 'new_runs': 4, 'historical_runs_reused_including_U': 6, 'G0_actual_feedback_queries': 0, 'G0_gain0_action_equivalence_checks': equivalent, 'no_gain_selection': True, 'no_significance_test': True, 'new_clean_condition_runs': 0, 'units': {'angle': 'rad', 'velocity': 'rad/s', 'cube_displacement': 'm', 'time': 's'}}
        write_json(output / 'metrics.json', metrics)
        require(read_json(output / 'metrics.json') == metrics, 'Metrics reread differs.')
        local = {'performed': False}
        no_simulator_import()
        validation = {'status': 'passed', 'scope': 'Independent saved-file CPU numerical acceptance;visual review separate', 'new_runs': 4, 'new_pngs': sum((checks[f'{s}-{g}']['verified_pngs'] for s, g in RUN_ORDER)), 'verified_pngs': sum((v.get('verified_pngs', 0) for v in checks.values())), 'checks': checks, 'numeric_content_fingerprints': fingerprints, 'local_integrity': local, 'N_and_N_plus_one': True, 'PNG_pixels_equal_RGB': True, 'feedback_recomputed_independently': True, 'metrics_reopened_and_recomputed': True, 'G0_action_equivalence_checks': equivalent, 'G0_fabricated_audits': False, 'pure_numeric_npz': True, 'simulation_calls': 0, 'training_calls': 0, 'statistics_fits': 0}
        write_json(output / 'validation.json', validation)
        print(json.dumps({'status': 'passed', 'new_pngs': validation['new_pngs'], 'verified_pngs': validation['verified_pngs'], 'local_integrity': local, 'metrics': results}, ensure_ascii=True), flush=True)
    except Exception as error:
        write_json(output / 'failure.json', {'type': type(error).__name__, 'message': str(error), 'simulation_calls': 0})
        raise
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-root', type=Path, default=HERE)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    main(args.data_root.resolve(), args.output_dir)
