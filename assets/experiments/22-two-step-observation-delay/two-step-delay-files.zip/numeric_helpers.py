"""Simulator-free helpers copied from article16; source SHA recorded by preflight."""
import hashlib
import json
import os
from pathlib import Path
import sys
import numpy as np
QPOS, QVEL = "obs/agent/qpos", "obs/agent/qvel"
RGB, CUBE, SUCCESS = "obs/sensor_data/base_camera/rgb", "diagnostic/cube_pose", "info/success"
STATE_ATOL = {QPOS: 1e-6, QVEL: 1e-5, CUBE: 1e-6}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, data):
    with Path(path).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def read_numeric(path):
    with np.load(path, allow_pickle=False) as archive:
        data = {key: archive[key].copy() for key in archive.files}
    require(all(v.dtype.kind in "buif" and np.isfinite(v).all() for v in data.values()),
            "Non-finite or non-numeric saved input: " + str(path))
    return data


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def compare(actual, reference, indices):
    fields = {}
    for key, atol in STATE_ATOL.items():
        a, b = actual[key][indices], reference[key][indices]
        require(a.shape == b.shape, "State comparison shape mismatch.")
        delta = np.abs(a.astype(np.float64) - b.astype(np.float64))
        row = {"atol": atol, "max_abs": float(delta.max()), "exact": bool(np.array_equal(a, b)),
               "within_tolerance": bool(np.all(delta <= atol))}
        if key in (QPOS, QVEL):
            row.update(arm_max_abs=float(delta[..., :7].max()), finger_max_abs=float(delta[..., 7:].max()),
                       arm_unit="rad" if key == QPOS else "rad/s", finger_unit="m" if key == QPOS else "m/s")
        else:
            row.update(xyz_max_abs_m=float(delta[..., :3].max()), quaternion_max_abs=float(delta[..., 3:].max()))
        fields[key] = row
    return {"state_indices": list(indices), "fields": fields,
            "within_tolerance": all(v["within_tolerance"] for v in fields.values()),
            "exact": all(v["exact"] for v in fields.values())}


def plan():
    actions = np.zeros((20, 8), dtype=np.float32)
    actions[:, 0] = np.repeat(np.array([.1, -.1, .1, -.1], dtype=np.float32), 5)
    actions[:, 7] = 1
    return actions


def configure_cpu():
    import torch
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)


def no_simulator_import():
    require(not any(name == prefix or name.startswith(prefix + ".")
                    for name in sys.modules for prefix in ("mani_skill", "sapien", "gymnasium")),
            "Offline operation imported a simulator.")


class Journal:
    """Exclusive append-only ledger, flushed to disk before every step attempt."""
    def __init__(self, path):
        self.path = path
        with path.open("x", encoding="utf-8"):
            pass

    def record(self, event, **fields):
        with self.path.open("a", encoding="utf-8", newline="\n") as stream:
            stream.write(json.dumps({"event": event, **fields}, allow_nan=False) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
