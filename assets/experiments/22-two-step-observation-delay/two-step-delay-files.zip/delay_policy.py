"""Select one delayed measurement, then calculate a scalar outer feedback command."""

from dataclasses import dataclass

import numpy as np

from feedback_controller import GAIN, JOINT_DELTA_SCALE_RAD, feedback, finite_scalar
from numeric_helpers import require


@dataclass(frozen=True)
class Measurement:
    index: int
    time_s: np.float64
    q: np.float64
    v: np.float64


class ObservationHistory:
    def __init__(self, dt, time_atol):
        self.dt = finite_scalar(dt, "control period")
        self.time_atol = finite_scalar(time_atol, "clock tolerance")
        require(self.dt > 0 and self.time_atol >= 0, "Invalid clock settings.")
        self._measurements = []

    def append(self, index, time_s, q, v):
        require(index == len(self._measurements), "Observation history is not contiguous.")
        time_s = finite_scalar(time_s, "measurement time")
        require(abs(time_s - index * self.dt) <= self.time_atol, "Measurement clock is misaligned.")
        self._measurements.append(Measurement(index, time_s, finite_scalar(q, "position"), finite_scalar(v, "velocity")))

    def delayed(self, t, delay):
        require(isinstance(t, int) and delay in (1, 2) and t >= delay, "Invalid observation delay/index.")
        require(len(self._measurements) == t + 1, "Measurement history must end at the current state.")
        return self._measurements[t - delay]


def decide(method, t, delay, now_s, ref_s, q_ref, u_ff, measurement, dt, time_atol):
    """The sole actual-state argument is the selected old measurement."""
    require(method in ("hold", "velocity") and delay in (1, 2), "Unknown feedback method/delay.")
    require(t >= delay and measurement.index == t - delay, "Wrong delayed observation index.")
    now_s = finite_scalar(now_s, "current time")
    ref_s = finite_scalar(ref_s, "reference time")
    age_s = np.float64(now_s - finite_scalar(measurement.time_s, "measurement time"))
    require(abs(age_s - delay * dt) <= time_atol and abs(now_s - ref_s) <= time_atol,
            "The measurement age or reference clock differs.")
    q_measured = finite_scalar(measurement.q, "measurement q")
    increment = (finite_scalar(measurement.v, "measurement v") * age_s
                 if method == "velocity" else np.float64(0))
    estimate = np.float64(q_measured + increment)
    audit = feedback(q_ref, estimate, u_ff)
    del audit["q_actual"]  # feedback() accepts the estimate in this argument.
    audit.update(
        t=np.int64(t), measurement_state_index=np.int64(measurement.index), reference_state_index=np.int64(t),
        actual_state_index=np.int64(t), delay_steps=np.int64(delay), current_time_s=now_s, reference_time_s=ref_s,
        measurement_time_s=measurement.time_s, measurement_age_s=age_s, q_measured_rad=q_measured,
        v_measured_rad_s=measurement.v, prediction_increment_rad=increment, q_est_rad=estimate,
        gain=GAIN, joint_delta_scale=JOINT_DELTA_SCALE_RAD,
    )
    return audit
