"""Validate and reproduce the two-step delay study using only saved files."""

import argparse
import csv
import math
from pathlib import Path

import numpy as np

from numeric_helpers import CUBE, QPOS, SUCCESS, compare, no_simulator_import, read_json, read_numeric, require, write_json
from replay import columns, scalar_replay, verify_source
from saved_checks import summary

GROUPS = ("U", "P1-Hold", "P1-Velocity", "P2-Hold", "P2-Velocity")
METHODS = ("hold", "velocity")
PAIRS = (
    ("two_minus_one_hold", "P2-Hold", "P1-Hold"),
    ("two_minus_one_velocity", "P2-Velocity", "P1-Velocity"),
    ("velocity_minus_hold_d1", "P1-Velocity", "P1-Hold"),
    ("velocity_minus_hold_d2", "P2-Velocity", "P2-Hold"),
)


def scalar(value):
    return value.item() if isinstance(value, np.generic) else value


def write_csv(path, rows):
    with path.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        for row in rows:
            writer.writerow({name: scalar(value) for name, value in row.items()})


def write_npz(path, arrays):
    with path.open("xb") as stream:
        np.savez_compressed(stream, **arrays)


def actual_feedback_row(seed, group, source_id, row):
    flat = {key: value for key, value in row.items() if key != "controller_target_qpos"}
    for i, value in enumerate(row["controller_target_qpos"], start=1):
        flat[f"controller_target_joint_{i}_rad"] = value
    return {"seed": np.int64(seed), "source_id": np.int64(source_id), **flat}, {"group": group, **flat}


def summarize_outcome(data, meta, queries):
    positions = data[CUBE][:, 0, :3].astype(np.float64)
    gripper = data["diagnostic/gripper_target_qpos"]
    require(gripper.dtype == np.float32 and gripper.shape[1:] == (1, 2)
            and bool(np.all(gripper == np.float32(0.04))), "Saved gripper target differs from the fixed open target.")
    rewards = data["rewards"][:, 0]
    return {
        "steps": len(rewards), "elapsed_s": float(data["time_s"][-1, 0]),
        "stop": meta["stopping_reason"], "feedback_decisions": len(queries),
        "strict_clips": sum(bool(q["was_clipped"]) for q in queries) if queries else None,
        "boundary_touches": sum(bool(q["sent_at_bound"]) for q in queries) if queries else None,
        "cube_net_displacement_m": float(np.linalg.norm(positions[-1] - positions[0])),
        "cumulative_reward": math.fsum(float(x) for x in rewards), "success_any": bool(data[SUCCESS].any()),
        "terminated_final": bool(data["terminated"][-1, 0]), "truncated_final": bool(data["truncated"][-1, 0]),
    }


def same_state_candidates(seed, row, data, reference, queries, config):
    candidate_records = []
    error_metrics = {}
    stages = {}
    condition = row["condition"]
    actual = config["conditions"][condition]
    for delay in (1, 2):
        by_method = {}
        for method_id, method in enumerate(METHODS):
            candidates = []
            actual_rule = delay == actual["delay_steps"] and method == actual["method"]
            for executed in queries:
                t = int(executed["t"])
                candidate = scalar_replay(data, reference, t, delay, method, config)
                del candidate["controller_target_qpos"]  # A hypothetical command has no physical target readback.
                if actual_rule:
                    require(candidate["u_sent"].tobytes() == data["actions"][t, 0].tobytes(), "Candidate/actual mismatch.")
                candidates.append(candidate)
                candidate_records.append({"seed": np.int64(seed), "source_id": np.int64(row["source_id"]),
                                          "method_id": np.int64(method_id), "is_actual_rule": np.bool_(actual_rule), **candidate})
            errors = np.array([item["estimate_error_rad"] for item in candidates], dtype=np.float64)
            error_metrics[f"d{delay}-{method}"] = {
                "decisions": len(errors), "rmse_rad": float(np.sqrt(np.mean(errors * errors))),
                "max_abs_rad": float(np.max(np.abs(errors))),
                "peak_action_indices": [int(row["t"]) for row in candidates if abs(row["estimate_error_rad"]) == np.max(np.abs(errors))],
                "is_actual_rule": actual_rule,
            }
            by_method[method] = candidates
        differences = {"raw": [], "clipped": [], "sent": []}
        classes = {"A": 0, "B": 0, "C": 0, "D": 0}
        for hold, velocity in zip(by_method["hold"], by_method["velocity"]):
            raw = velocity["u_raw"] - hold["u_raw"]
            clipped = velocity["u_clipped_float64"] - hold["u_clipped_float64"]
            sent = float(velocity["u_sent"]) - float(hold["u_sent"])
            expect = -config["gain"] * (velocity["q_est_rad"] - hold["q_est_rad"]) / config["joint_delta_scale_rad"]
            atol = config["numeric_audit_atol"]
            require(abs(raw - expect) <= atol and abs(clipped) <= abs(raw) + atol, "Command gap or clipping contraction differs.")
            for key, value in (("raw", raw), ("clipped", clipped), ("sent", sent)):
                differences[key].append(value)
            case = "A" if raw == 0 else "B" if clipped == 0 else "C" if sent == 0 else "D"
            classes[case] += 1
        stages[f"d{delay}"] = {
            "cases": classes,
            "max_abs_normalized_difference": {name: max(map(abs, values)) for name, values in differences.items()},
            "rmse_normalized_difference": {name: math.sqrt(math.fsum(x*x for x in values) / len(values))
                                            for name, values in differences.items()},
        }
    return candidate_records, {"estimates": error_metrics, "velocity_minus_hold": stages}


def tracking(seed, groups, meta, audits, source_rows, config):
    start = config["comparison_start_state_index"]
    stop = min(len(data["actions"]) for data in groups.values())
    require(stop > start, "Common coverage ends before the first feedback transition.")
    states = np.arange(stop + 1, dtype=np.int64)
    actions = np.arange(stop, dtype=np.int64)
    q_ref = groups["U"][QPOS][states, 0, 0].astype(np.float64)
    time = groups["U"]["time_s"][states, 0]
    arrays = {"state_index": states, "action_index": actions, "state_time_s": time, "action_time_s": time[:-1]}
    outcomes = {}
    state_rows, action_rows = [], []
    for group, data in groups.items():
        q = data[QPOS][states, 0, 0].astype(np.float64)
        action = data["actions"][actions, 0]
        diff = q - q_ref
        target = data["diagnostic/arm_target_qpos"][actions, 0, 0]
        arrays.update({f"{group}/q_rad": q, f"{group}/deviation_rad": diff, f"{group}/u_sent": action,
                       f"{group}/target_q1_rad": target})
        row = source_rows[group]
        outcomes[group] = {"source_id": row["source_id"], "historical": row["reused_historical_run"],
                           "tracking": summary(diff[start:]), **summarize_outcome(data, meta[group], audits[group])}
        for k in states:
            state_rows.append({"seed": seed, "group": group, "source_id": row["source_id"], "state_index": k,
                               "time_s": time[k], "joint_1_rad": q[k], "reference_rad": q_ref[k], "deviation_rad": diff[k]})
        for t in actions:
            action_rows.append({"seed": seed, "group": group, "source_id": row["source_id"], "action_index": t,
                                "time_s": time[t], "u_sent_joint_1": action[t], "controller_target_joint_1_rad": target[t]})
    differences = {}
    for name, lhs, rhs in PAIRS:
        left, right = outcomes[lhs]["tracking"], outcomes[rhs]["tracking"]
        angle_gap = arrays[f"{lhs}/q_rad"][start:] - arrays[f"{rhs}/q_rad"][start:]
        differing = np.flatnonzero(arrays[f"{lhs}/u_sent"].view(np.uint32) != arrays[f"{rhs}/u_sent"].view(np.uint32))
        arrays[f"pair/{name}/angle_difference_rad"] = angle_gap
        differences[name] = {
            "lhs": lhs, "rhs": rhs, "angle_difference": summary(angle_gap),
            "change_in_tracking_rmse_rad": left["rmse_rad"] - right["rmse_rad"],
            "different_actual_commands": len(differing),
            "first_different_action_index": int(differing[0]) if len(differing) else None,
        }
    return arrays, state_rows, action_rows, {
        "common_state_interval": [start, stop], "common_time_s": [float(time[start]), float(time[stop])],
        "states_in_metrics": stop - start + 1, "groups": outcomes, "contrasts": differences,
    }


def replay_all(root, output):
    config = read_json(root / "config.json")
    manifest = read_json(root / "source_manifest.json")
    provenance = read_json(root / "capture_provenance.json")
    sources = manifest["sources"]
    seeds = config["seeds"]
    expected = [(seed, group) for seed in seeds for group in GROUPS]
    require([(row["seed"], row["condition"]) for row in sources] == expected and
            [row["source_id"] for row in sources] == list(range(len(expected))), "Source IDs or pairing changed.")
    require(tuple(config["conditions"]) == GROUPS and seeds == [45, 46], "Frozen conditions changed.")
    fingerprint_count = len({row["numeric_content_fingerprint"] for row in sources})
    require(provenance["run_order"] == [f"seed-{s:04d}/{g}" for s, g in config["run_order"]]
            and provenance["explicit_resets"] == provenance["constructor_calls"] == 4
            and provenance["historical_reruns"] == provenance["training_calls"] == provenance["statistics_fits"]
            == provenance["model_updates"] == 0, "Unexpected capture accounting.")
    output.mkdir(parents=True, exist_ok=False)
    checks, stats, real_rows, real_csv, candidate_rows, case_rows = {}, {}, [], [], [], []
    for seed in seeds:
        sid = f"seed-{seed:04d}"
        rows = {row["condition"]: row for row in sources if row["seed"] == seed}
        groups, meta, audits, detail = {}, {}, {}, {}
        reference = read_numeric((root / rows["U"]["path"]).resolve() / "rollout.npz")
        estimates = {}
        for group, row in rows.items():
            data, run, queries, check = verify_source(root, row, reference, config)
            is_new = config["conditions"][group]["article"] == 22
            require(row["reused_historical_run"] != is_new
                    and row["original_collection_article"] == config["conditions"][group]["article"], "Source provenance differs.")
            groups[group], meta[group], audits[group], detail[group] = data, run, queries, check
            for query in queries:
                number, record = actual_feedback_row(seed, group, row["source_id"], query)
                real_rows.append(number)
                real_csv.append({"seed": seed, "source_id": row["source_id"], **record})
                if is_new and int(query["t"]) in (9, 10, 11):
                    case_rows.append({name: scalar(value) for name, value in real_csv[-1].items()})
            if is_new:
                require(provenance["step_counts"][f"{sid}/{group}"] == len(data["actions"])
                        <= config["max_steps_per_run"], "Step count differs from the sealed ledger.")
                calculated, estimates[group] = same_state_candidates(seed, row, data, reference, queries, config)
                candidate_rows.extend(calculated)

        prefix = {f"{g}_vs_U_states_0_to_8": compare(groups[g], groups["U"], range(9)) for g in GROUPS[1:]}
        prefix.update({f"{g}_vs_P1_Hold_states_0_to_9": compare(groups[g], groups["P1-Hold"], range(10)) for g in GROUPS[2:]})
        prefix.update({f"{g}_vs_P1_Velocity_states_0_to_9": compare(groups[g], groups["P1-Velocity"], range(10))
                       for g in GROUPS[3:]})
        prefix["P2_Velocity_vs_P2_Hold_states_0_to_9"] = compare(groups["P2-Velocity"], groups["P2-Hold"], range(10))
        require(all(row["within_tolerance"] for row in prefix.values()), "An independently checked prefix differs.")
        checks[str(seed)] = {"sources": detail, "prefix": prefix}
        arrays, states, actions, stats[str(seed)] = tracking(seed, groups, meta, audits, rows, config)
        stats[str(seed)]["same_state_candidates"] = estimates
        write_npz(output / f"{sid}-comparison.npz", arrays)
        write_csv(output / f"{sid}-states.csv", states)
        write_csv(output / f"{sid}-actions.csv", actions)

    counts = provenance["step_counts"]
    total = sum(counts.values())
    require(set(counts) == set(provenance["run_order"]) and total == provenance["step_attempts"] == provenance["completed_steps"]
            and total <= config["max_step_attempts_total"], "Aggregate step budget differs.")
    total_pngs = sum(detail["verified_pngs"] for seed in checks.values() for detail in seed["sources"].values())
    new_pngs = sum(seed["sources"][g]["verified_pngs"] for seed in checks.values() for g in GROUPS[3:])
    real_new = sum(bool(row["is_actual_rule"]) for row in candidate_rows)
    write_npz(output / "actual-feedback.npz", columns(real_rows))
    write_csv(output / "actual-feedback.csv", real_csv)
    write_npz(output / "same-state-candidates.npz", columns(candidate_rows))
    write_csv(output / "same-state-candidates.csv", candidate_rows)
    write_json(output / "timing-cases.json", {"actions": [9, 10, 11], "two_step_cases": case_rows})
    write_json(output / "metrics.json", {"seeds": stats, "candidate_method_id": {"0": "hold", "1": "velocity"},
               "command_gap_cases": {"A": "same raw", "B": "same float64 clipped", "C": "same float32 sent", "D": "different float32 sent"}})
    result = {"status": "passed", "new_runs": 4, "historical_runs": 6, "step_attempts": total, "new_pngs": new_pngs,
              "verified_pngs": total_pngs, "new_actual_feedback_decisions": real_new,
              "all_actual_feedback_decisions": len(real_rows), "same_state_candidate_rows": len(candidate_rows),
              "distinct_numeric_fingerprints": fingerprint_count, "verification_simulation_calls": 0, "source_checks": checks}
    write_json(output / "validation.json", result)
    no_simulator_import()
    return result


def compare_saved(data_root, output):
    checked = []
    for path in sorted(output.iterdir()):
        original = data_root / path.name
        if path.suffix == ".npz":
            stored, replayed = read_numeric(original), read_numeric(path)
            require(stored.keys() == replayed.keys() and all(stored[key].shape == replayed[key].shape
                    and stored[key].dtype == replayed[key].dtype and stored[key].tobytes() == replayed[key].tobytes()
                    for key in stored), f"Recomputed arrays differ: {path.name}")
        else:
            require(original.read_bytes() == path.read_bytes(), f"Recomputed file differs: {path.name}")
        checked.append(path.name)
    return checked


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path, required=True, help="A new directory for independent outputs.")
    parser.add_argument("--compare-saved", action="store_true")
    args = parser.parse_args()
    result = replay_all(args.data_root.resolve(), args.output.resolve())
    comparison = compare_saved(args.data_root.resolve(), args.output.resolve()) if args.compare_saved else []
    print(f"PASS: {result['new_runs']} new runs, {result['step_attempts']} attempts, {result['verified_pngs']} verified PNGs, "
          f"{result['new_actual_feedback_decisions']} real new feedback decisions, "
          f"{result['same_state_candidate_rows']} same-state candidates, {len(comparison)} saved files matched; no simulation.")
