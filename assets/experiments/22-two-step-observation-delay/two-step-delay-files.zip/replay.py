"""Independent scalar replay of the saved states, without the live policy or simulator."""

import hashlib
import json
from pathlib import Path

import numpy as np

from numeric_helpers import QPOS, QVEL, read_numeric, require, sha
from saved_checks import check_run

TARGET = "diagnostic/arm_target_qpos"
METHODS = {1: "hold", 2: "velocity"}


def fingerprint(data):
    digest = hashlib.sha256()
    for name, array in sorted(data.items()):
        array = np.ascontiguousarray(array)
        digest.update(json.dumps([name, array.dtype.str, list(array.shape)], separators=(",", ":")).encode())
        digest.update(array.tobytes(order="C"))
    return digest.hexdigest()


def scalar_replay(data, reference, t, delay, method, config):
    """Recompute by array indexing and scalar arithmetic rather than using the live cache."""
    m = t - delay
    require(0 <= m < t < len(data["actions"]) and method in METHODS.values() and delay in (1, 2),
            "Wrong replay index or mode.")
    now = float(data["time_s"][t, 0])
    then = float(data["time_s"][m, 0])
    ref_time = float(reference["time_s"][t, 0])
    age = now - then
    tolerance = config["measurement_age_atol_s"]
    require(abs(age - delay * config["control_dt_s"]) <= tolerance and abs(now - ref_time) <= tolerance,
            "The saved measurement or reference clock is misaligned.")
    q_ref = float(reference[QPOS][t, 0, 0])
    q_current = float(data[QPOS][t, 0, 0])
    q = float(data[QPOS][m, 0, 0])
    v = float(data[QVEL][m, 0, 0])
    increment = v * age if method == "velocity" else 0.0
    estimate = q + increment
    u_ff = float(reference["actions"][t, 0])
    gain = config["gain"]
    scale = config["joint_delta_scale_rad"]
    error = q_ref - estimate
    correction = gain * error / scale
    raw = u_ff + correction
    bound = config["clip_limit_float64_from_float32"]
    limited = min(bound, max(-bound, raw))
    sent = np.float32(limited)
    return {
        "t": np.int64(t), "measurement_state_index": np.int64(m), "reference_state_index": np.int64(t),
        "actual_state_index": np.int64(t), "delay_steps": np.int64(delay),
        "current_time_s": now, "reference_time_s": ref_time, "measurement_time_s": then, "measurement_age_s": age,
        "q_measured_rad": q, "v_measured_rad_s": v, "prediction_increment_rad": increment, "q_est_rad": estimate,
        "q_ref": q_ref, "q_current_diagnostic": q_current, "estimate_error_rad": estimate - q_current,
        "u_ff": u_ff, "error_rad": error, "correction": correction, "u_raw": raw,
        "u_clipped_float64": limited, "u_sent": sent, "was_clipped": raw < -bound or raw > bound,
        "sent_at_bound": abs(sent) == np.float32(bound), "gain": gain, "joint_delta_scale": scale,
        "controller_target_qpos": data[TARGET][t, 0].copy(),
    }


def original_audit_layout(row, group):
    """Map equivalent scalar quantities to the unmodified historical audit formats."""
    if group not in ("P1-Hold", "P1-Velocity"):
        return row
    row = dict(row)
    position = row.pop("q_measured_rad")
    speed = row.pop("v_measured_rad_s")
    increment = row.pop("prediction_increment_rad")
    estimate = row.pop("q_est_rad")
    if group == "P1-Velocity":
        row.update(q_latest=position, v_latest=speed, predicted_increment=increment,
                   q_pred_velocity=estimate, prediction_target_state_index=row["t"])
    else:
        current = row.pop("q_current_diagnostic")
        del row["estimate_error_rad"]
        row.update(q_used=position, q_current=current, error_used_rad=row.pop("error_rad"),
                   error_current_rad=row["q_ref"] - current)
    return row


def columns(rows):
    return {name: np.stack([row[name] for row in rows]) for name in rows[0]}


def check_stored_audit(data, reference, audit, group, config):
    condition = config["conditions"][group]
    t0 = config["feedback_takeover_t"]
    rows = [scalar_replay(data, reference, t, condition["delay_steps"], condition["method"], config)
            for t in range(t0, len(data["actions"]))]
    expected = columns([original_audit_layout(row, group) for row in rows])
    require(set(audit) == set(expected), f"{group}: audit fields differ.")
    require(config["numeric_audit_rtol"] == 0.0, "Audit tolerance must be absolute.")
    maximum = {}
    for key, expected_array in expected.items():
        actual = audit[key]
        require(actual.dtype == expected_array.dtype and actual.shape == expected_array.shape,
                f"{group}: audit type/shape differs for {key}.")
        if actual.dtype == np.float64:
            maximum[key] = float(np.max(np.abs(actual - expected_array)))
            require(maximum[key] <= config["numeric_audit_atol"], f"{group}: scalar replay differs for {key}.")
        else:
            require(actual.tobytes() == expected_array.tobytes(), f"{group}: exact audit differs for {key}.")
    require(audit["u_sent"].tobytes() == data["actions"][t0:, 0].tobytes(), f"{group}: actual command differs.")
    return rows, maximum


def verify_source(data_root, row, reference, config):
    folder = (Path(data_root) / row["path"]).resolve()
    require(sha(folder / "rollout.npz") == row["rollout_sha256"], "Stored rollout SHA-256 differs.")
    group = row["condition"]
    is_reference = group == "U"
    audit_name = row["audit_filename"]
    if not is_reference:
        require(sha(folder / audit_name) == row["audit_sha256"], "Stored feedback audit SHA-256 differs.")
    data, meta, audit, detail = check_run(
        folder, "U" if is_reference else "D", reference, config,
        check_feedback_audit=False, audit_filename=audit_name,
    )
    require(meta["seed"] == row["seed"] and meta["group"] == row["group"]
            and detail["steps"] == row["completed_steps"], "Source seed/group/length differs.")
    require(fingerprint(data) == row["numeric_content_fingerprint"], "Rollout numeric fingerprint differs.")
    saved_rows = []
    if not is_reference:
        require(meta["delay_steps"] == config["conditions"][group]["delay_steps"] and meta["gain"] == config["gain"],
                "The recorded gain or delay differs.")
        saved_rows, detail["audit_replay_max_abs_differences"] = check_stored_audit(
            data, reference, audit, group, config,
        )
    return data, meta, saved_rows, detail


def check_ledger(ledger, data_by_run, meta_by_run, config):
    """Replay the collection ledger, including reserved calls, against every numeric action."""
    expected = [f"seed-{seed:04d}/{group}" for seed, group in config["run_order"]]
    actual = list(data_by_run)
    require(actual == expected, "Saved run order differs from the frozen configuration.")
    position = 0
    total = 0
    delays = config["conditions"]

    def expect(event, run_id=None, **fields):
        nonlocal position
        require(position < len(ledger), f"Ledger ended before {event}.")
        row = ledger[position]
        position += 1
        require(row["event"] == event and (run_id is None or row["run_id"] == run_id)
                and all(row[key] == value for key, value in fields.items()), f"Ledger differs at {position}: {event}.")
        return row

    for run_id, (seed, group) in zip(expected, config["run_order"]):
        meta = meta_by_run[run_id]
        data = data_by_run[run_id]
        expect("construct", run_id, seed=seed, constructor_internal_initialization=True)
        expect("explicit_reset", run_id, seed=seed)
        for t, action in enumerate(data["actions"]):
            total += 1
            row = expect("step_reserved", run_id, t=t, global_attempt=total,
                         action_source=int(data["audit/action_source"][t]), delay_steps=delays[group]["delay_steps"],
                         method=delays[group]["method"])
            require(np.asarray(row["action"], dtype=np.float32).tobytes() == action.tobytes(),
                    "Reserved action differs from saved float32 action.")
            expect("step_returned", run_id, t=t)
        expect("group_saved", run_id, steps=meta["completed_steps"], reason=meta["stopping_reason"])
        expect("closed", run_id)
    expect("finished", attempts={run_id: meta_by_run[run_id]["step_attempts"] for run_id in expected})
    require(position == len(ledger) and total <= config["max_step_attempts_total"], "Unexpected events or excess calls.")
    return {"step_attempts": total, "completed_steps": total, "run_order": expected, "explicit_resets": len(expected),
            "constructor_calls": len(expected), "step_counts": {run_id: len(data_by_run[run_id]["actions"]) for run_id in expected}}
