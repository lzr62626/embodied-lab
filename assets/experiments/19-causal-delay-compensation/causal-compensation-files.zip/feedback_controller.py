"""One fixed, scalar outer reference-feedback rule; no simulator or fitted data."""

import numpy as np

GAIN = np.float64(1.0)
JOINT_DELTA_SCALE_RAD = np.float64(0.1)
COMMAND_LIMIT_NOMINAL = 0.1
COMMAND_LIMIT_FLOAT32 = np.float32(COMMAND_LIMIT_NOMINAL)
# The bound used by the existing float32 action interface, exactly represented in float64.
COMMAND_LIMIT_FLOAT64 = np.float64(COMMAND_LIMIT_FLOAT32)


def finite_scalar(value, name):
    array = np.asarray(value)
    if array.ndim != 0 or array.dtype.kind not in "iuf" or not np.isfinite(array).item():
        raise ValueError("Expected finite scalar: " + name)
    return np.float64(array)


def feedback(q_ref, q_actual, u_ff):
    """Only the three named scalars enter the controller; returned storage is independent."""
    reference = finite_scalar(q_ref, "q_ref")
    actual = finite_scalar(q_actual, "q_actual")
    feedforward = finite_scalar(u_ff, "u_ff")
    if abs(feedforward) > COMMAND_LIMIT_FLOAT64:
        raise ValueError("Feedforward command exceeds the frozen demonstration bound.")
    error = np.float64(reference - actual)
    correction = np.float64(GAIN * error / JOINT_DELTA_SCALE_RAD)
    raw = np.float64(feedforward + correction)
    if not np.isfinite([error, correction, raw]).all():
        raise ValueError("Non-finite feedback calculation.")
    clipped = np.float64(np.clip(raw, -COMMAND_LIMIT_FLOAT64, COMMAND_LIMIT_FLOAT64))
    sent = np.float32(clipped)
    return {
        "q_ref": reference, "q_actual": actual, "error_rad": error,
        "u_ff": feedforward, "correction": correction, "u_raw": raw,
        "u_clipped_float64": clipped, "u_sent": sent,
        "was_clipped": np.bool_(raw < -COMMAND_LIMIT_FLOAT64 or raw > COMMAND_LIMIT_FLOAT64),
        "sent_at_bound": np.bool_(abs(sent) == COMMAND_LIMIT_FLOAT32),
    }
