"""Independent reconstruction from saved arrays; no decision/cache/controller calls."""
import numpy as np
from compensation_common import QPOS, require, read_numeric


def check_compensated(data, reference, audit, config):
    times = np.arange(9, len(data["actions"]), dtype=np.int64)
    integers = {"t": times, "reference_state_index": times, "actual_state_index": times,
                "prediction_target_state_index": times, "measurement_state_index": times - 1,
                "previous_measurement_state_index": times - 2, "delay_steps": np.ones_like(times),
                "prediction_horizon_steps": np.ones_like(times)}
    floats = ("q_ref", "q_previous", "q_latest", "delta_q", "q_estimated", "velocity_estimated", "q_current",
              "error_estimated_rad", "estimate_error_rad", "hold_error_rad", "error_current_rad",
              "u_ff", "correction", "u_raw", "u_clipped_float64", "gain", "joint_delta_scale",
              "current_time_s", "reference_time_s", "previous_measurement_time_s", "measurement_time_s",
              "measurement_age_s", "previous_measurement_age_s", "measurement_interval_s", "prediction_horizon_s")
    require(set(audit) == set(integers) | set(floats) | {"u_sent", "was_clipped", "sent_at_bound", "controller_target_qpos"}, "Compensation audit fields differ.")
    for key, value in integers.items():
        require(audit[key].dtype == np.int64 and np.array_equal(audit[key], value), "Audit integer/index differs:" + key)
    for key in floats:
        require(audit[key].shape == times.shape and audit[key].dtype == np.float64, "Audit float64 layout differs:" + key)
    require(audit["u_sent"].shape == times.shape and audit["u_sent"].dtype == np.float32
            and audit["controller_target_qpos"].shape == (len(times), 7) and audit["controller_target_qpos"].dtype == np.float32, "Output/target layout differs.")
    for key in ("was_clipped", "sent_at_bound"):
        require(audit[key].shape == times.shape and audit[key].dtype == np.bool_, "Boundary flag layout differs.")
    expected = {key: [] for key in floats}
    sent, clipped, touched = [], [], []
    bound = config["clip_limit_float64_from_float32"]
    for t in times:
        qr, qc = float(reference[QPOS][t, 0, 0]), float(data[QPOS][t, 0, 0])
        previous, latest = float(data[QPOS][t - 2, 0, 0]), float(data[QPOS][t - 1, 0, 0])
        delta = latest - previous
        estimate = latest + delta
        error = qr - estimate
        ff = float(reference["actions"][t, 0])
        correction = 1. * error / .1
        raw = ff + correction
        limited = min(bound, max(-bound, raw))
        value = np.float32(limited)
        now, before, older = (float(data["time_s"][s, 0]) for s in (t, t - 1, t - 2))
        ref_time = float(reference["time_s"][t, 0])
        values = (qr, previous, latest, delta, estimate, delta / .05, qc, error, estimate - qc, latest - qc, qr - qc,
                  ff, correction, raw, limited, 1., .1, now, ref_time, older, before, now - before, now - older, before - older, .05)
        for key, item in zip(floats, values): expected[key].append(item)
        sent.append(value)
        clipped.append(raw < -bound or raw > bound)
        touched.append(abs(value) == np.float32(bound))
        require(all(abs(error) <= config["measurement_age_atol_s"] for error in
                    (now - ref_time, now - before - .05, now - older - .10, before - older - .05)), "Actual sample clock/measurement ages differ.")
    differences = {key: float(np.max(np.abs(audit[key] - np.asarray(values, dtype=np.float64)))) for key, values in expected.items()}
    require(all(value <= config["numeric_audit_atol"] for value in differences.values()), "Independent extrapolation/feedback arithmetic differs.")
    require(np.array_equal(audit["u_sent"], np.asarray(sent, dtype=np.float32))
            and np.array_equal(audit["u_sent"], data["actions"][times, 0])
            and np.array_equal(audit["was_clipped"], np.asarray(clipped, dtype=np.bool_))
            and np.array_equal(audit["sent_at_bound"], np.asarray(touched, dtype=np.bool_))
            and np.array_equal(audit["controller_target_qpos"], data["diagnostic/arm_target_qpos"][times, 0]), "Actual send,flags or controller targets differ.")
    return differences


def error_metrics(values):
    a = np.asarray(values, dtype=np.float64)
    require(a.ndim == 1 and len(a) > 0 and np.isfinite(a).all(), "Invalid estimation errors.")
    rmse = float(np.sqrt(np.mean(a * a, dtype=np.float64)))
    require(abs(rmse - (sum(float(x) ** 2 for x in a) / len(a)) ** .5) <= 1e-12, "Estimation reduction cross-check differs.")
    return {"samples": len(a), "max_abs_rad": float(np.abs(a).max()), "rmse_rad": rmse, "mean_signed_rad": float(np.mean(a, dtype=np.float64))}


def export_estimation(data, audit, output, stem, csv_file):
    t = audit["t"].copy()
    previous = data[QPOS][t - 2, 0, 0].astype(np.float64)
    latest = data[QPOS][t - 1, 0, 0].astype(np.float64)
    current = data[QPOS][t, 0, 0].astype(np.float64)
    delta = latest - previous
    estimated = latest + delta
    arrays = {"t": t, "state_time_s": data["time_s"][t, 0].copy(), "q_previous_rad": previous,
              "q_latest_rad": latest, "delta_q_rad": delta, "velocity_estimated_rad_s": delta / .05,
              "q_estimated_rad": estimated, "q_current_rad": current,
              "estimate_error_rad": estimated - current, "hold_error_rad": latest - current}
    path = output / (stem + "-estimation.npz")
    with path.open("xb") as stream: np.savez_compressed(stream, **arrays)
    reread = read_numeric(path)
    require(set(reread) == set(arrays) and all(np.array_equal(value, reread[key]) for key, value in arrays.items()), "Saved estimation arrays differ.")
    fields = list(arrays)
    csv_file(output / (stem + "-estimation.csv"), fields, ([arrays[key][j].item() for key in fields] for j in range(len(t))))
    return {"decision_action_indices": t.tolist(), "estimated": error_metrics(reread["estimate_error_rad"]),
            "hold_latest": error_metrics(reread["hold_error_rad"]), "unit": "rad",
            "truth": "same run actual obs[t],offline evaluation only;never outer input",
            "hold_latest_scope": "same-run estimation comparison,not another executed closed-loop controller"}
