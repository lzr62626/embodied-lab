"""Unchanged saved-file functions extracted from article18; never collect."""
import hashlib
import json
import numpy as np
from compensation_common import QPOS, require

def numeric_fingerprint(data):
    digest = hashlib.sha256()
    for key in sorted(data):
        value = np.ascontiguousarray(data[key])
        digest.update(json.dumps([key, value.dtype.str, list(value.shape)], separators=(",", ":")).encode())
        digest.update(value.tobytes(order="C"))
    return digest.hexdigest()

def check_delayed(data, reference, audit, config):
    """Recompute directly from saved indices, without MeasurementCache/decide/feedback."""
    times = np.arange(9, len(data["actions"]), dtype=np.int64)
    integers = {"t": times, "reference_state_index": times, "actual_state_index": times,
                "measurement_state_index": times - 1, "delay_steps": np.ones_like(times)}
    floats = ("q_ref", "q_current", "q_used", "error_used_rad", "error_current_rad", "u_ff", "correction", "u_raw",
              "u_clipped_float64", "gain", "joint_delta_scale", "current_time_s", "reference_time_s",
              "measurement_time_s", "measurement_age_s")
    require(set(audit) == set(integers) | set(floats) | {"u_sent", "was_clipped", "sent_at_bound", "controller_target_qpos"},
            "Delayed audit fields differ.")
    for key, expected in integers.items():
        require(audit[key].dtype == np.int64 and np.array_equal(audit[key], expected), "Audit index differs: " + key)
    for key in floats:
        require(audit[key].shape == times.shape and audit[key].dtype == np.float64, "Audit float64 layout differs: " + key)
    require(audit["u_sent"].shape == times.shape and audit["u_sent"].dtype == np.float32
            and audit["controller_target_qpos"].shape == (len(times), 7) and audit["controller_target_qpos"].dtype == np.float32,
            "Sent command/target layout differs.")
    for key in ("was_clipped", "sent_at_bound"):
        require(audit[key].shape == times.shape and audit[key].dtype == np.bool_, "Boundary flag layout differs.")
    expected = {key: [] for key in floats}
    sent, clipped, touched = [], [], []
    bound = config["clip_limit_float64_from_float32"]
    for t in times:
        qr, qc, qu = (float(reference[QPOS][t, 0, 0]), float(data[QPOS][t, 0, 0]), float(data[QPOS][t - 1, 0, 0]))
        ff = float(reference["actions"][t, 0])
        err, current_error = qr - qu, qr - qc
        correction = 1. * err / .1
        raw = ff + correction
        limited = min(bound, max(-bound, raw))
        value = np.float32(limited)
        now, before, ref_time = float(data["time_s"][t, 0]), float(data["time_s"][t - 1, 0]), float(reference["time_s"][t, 0])
        values = (qr, qc, qu, err, current_error, ff, correction, raw, limited, 1., .1, now, ref_time, before, now - before)
        for key, item in zip(floats, values):
            expected[key].append(item)
        sent.append(value)
        clipped.append(raw < -bound or raw > bound)
        touched.append(abs(value) == np.float32(bound))
        require(abs(now - ref_time) <= config["measurement_age_atol_s"]
                and abs(now - before - config["control_dt_s"]) <= config["measurement_age_atol_s"], "Measurement/reference clock differs.")
    differences = {key: float(np.max(np.abs(audit[key] - np.asarray(values, dtype=np.float64)))) for key, values in expected.items()}
    require(all(value <= config["numeric_audit_atol"] for value in differences.values()), "Independent delayed formula differs.")
    require(np.array_equal(audit["u_sent"], np.array(sent, dtype=np.float32))
            and np.array_equal(audit["u_sent"], data["actions"][times, 0])
            and np.array_equal(audit["was_clipped"], np.array(clipped, dtype=np.bool_))
            and np.array_equal(audit["sent_at_bound"], np.array(touched, dtype=np.bool_))
            and np.array_equal(audit["controller_target_qpos"], data["diagnostic/arm_target_qpos"][times, 0]),
            "Actual command, clipping/touch flags or target differs.")
    return differences
