"""Two same-run past positions predict the current angle; current truth is audit only."""
import numpy as np
from feedback_controller import feedback, finite_scalar

DT = np.float64(.05)
TIME_ATOL = np.float64(1e-12)


class PastStateCache:
    def __init__(self, run_id):
        self.run_id = run_id
        self.values, self.times = [], []

    def append(self, run_id, state_index, time_s, joint1):
        if run_id != self.run_id or type(state_index) is not int or state_index != len(self.values):
            raise ValueError("Wrong cache owner or non-sequential state index.")
        value = finite_scalar(joint1, "observed_joint1")
        timestamp = finite_scalar(time_s, "state_time_s")
        if abs(timestamp - state_index * DT) > TIME_ATOL:
            raise ValueError("Non-continuous control time.")
        self.values.append(np.float64(value))
        self.times.append(np.float64(timestamp))

    def past_pair(self, run_id, t):
        if run_id != self.run_id or type(t) is not int or t < 2 or t >= len(self.values):
            raise ValueError("Wrong cache owner or insufficient actual past; no padding.")
        return {"q_previous": np.float64(self.values[t - 2]), "q_latest": np.float64(self.values[t - 1]),
                "previous_measurement_state_index": np.int64(t - 2), "measurement_state_index": np.int64(t - 1),
                "previous_measurement_time_s": np.float64(self.times[t - 2]), "measurement_time_s": np.float64(self.times[t - 1])}

    def current_for_audit(self, run_id, t):
        if run_id != self.run_id or type(t) is not int or not 0 <= t < len(self.values):
            raise ValueError("Invalid diagnostic state.")
        return np.float64(self.values[t])


def decide(cache, run_id, t, q_ref, u_ff, reference_time_s):
    pair = cache.past_pair(run_id, t)
    reference_time = finite_scalar(reference_time_s, "reference_time_s")
    now = cache.times[t]
    age = np.float64(now - pair["measurement_time_s"])
    older_age = np.float64(now - pair["previous_measurement_time_s"])
    interval = np.float64(pair["measurement_time_s"] - pair["previous_measurement_time_s"])
    if any(abs(error) > TIME_ATOL for error in (reference_time - now, age - DT, older_age - 2 * DT, interval - DT)):
        raise ValueError("Reference/current clock or past measurement intervals differ.")
    delta = finite_scalar(pair["q_latest"] - pair["q_previous"], "delta_q")
    estimated = finite_scalar(pair["q_latest"] + delta, "q_estimated")
    result = feedback(q_ref, estimated, u_ff)
    result["q_estimated"] = result.pop("q_actual")
    result["error_estimated_rad"] = result.pop("error_rad")
    # No current-angle access until the complete outer command above is computed.
    current = cache.current_for_audit(run_id, t)
    result.update(pair)
    result.update(t=np.int64(t), reference_state_index=np.int64(t), actual_state_index=np.int64(t),
                  prediction_target_state_index=np.int64(t), delay_steps=np.int64(1), prediction_horizon_steps=np.int64(1),
                  gain=np.float64(1.), joint_delta_scale=np.float64(.1),
                  delta_q=delta, velocity_estimated=np.float64(delta / DT), q_current=current,
                  estimate_error_rad=np.float64(estimated - current), hold_error_rad=np.float64(pair["q_latest"] - current),
                  error_current_rad=np.float64(result["q_ref"] - current), current_time_s=np.float64(now),
                  reference_time_s=reference_time, measurement_age_s=age, previous_measurement_age_s=older_age,
                  measurement_interval_s=interval, prediction_horizon_s=DT)
    return result
