"""Portable protocol constants and pure saved-data helpers; no private maintenance or collection code."""

from pathlib import Path
import numpy as np
from numeric_helpers import QPOS,QVEL,RGB,CUBE,SUCCESS,STATE_ATOL,require,read_json,write_json,read_numeric,sha,compare,plan,no_simulator_import

HERE = Path(__file__).resolve().parent

SEEDS = (45, 46)

CONDITIONS = ("U", "C0", "P0", "C1", "P1", "CE", "PE")

NEW_GROUPS = {"CE": "CE-extrapolated-clean", "PE": "PE-extrapolated-perturbed"}

RUN_ORDER = [(seed, condition) for seed in SEEDS for condition in ("CE", "PE")]

TASK = {"task": "PushCube-v1", "robot": "panda", "num_envs": 1,
        "obs_mode": "rgb", "control_mode": "pd_joint_delta_pos", "camera": "base_camera",
        "width": 256, "height": 256, "shader_pack": "minimal", "sim_backend": "cpu", "render_backend": "cpu"}

CONFIG = {
    "version": "causal-delay-compensation-v1", "seeds": list(SEEDS), "gain": 1.,
    "new_groups": NEW_GROUPS, "run_order": [[s, g] for s, g in RUN_ORDER],
    "condition_delays": {"C0": 0, "P0": 0, "C1": 1, "P1": 1, "CE": 1, "PE": 1},
    "compensated_conditions": ["CE", "PE"], "new_runs": 4, "max_steps_per_run": 20, "max_step_attempts_total": 80,
    "joint_delta_scale_rad": .1, "command_limit_nominal": .1,
    "command_limit_float32": float(np.float32(.1)), "clip_limit_float64_from_float32": float(np.float32(.1)),
    "boundary_rule": "Clip in float64 against the existing float32 interface bound, then cast to float32",
    "reference_observation_index": "t, never delayed", "actual_observation_index": "t,diagnostic only",
    "measurement_observation_indices": ["t-2 previous", "t-1 latest available"], "prediction_target_index": "t",
    "prediction_horizon_control_steps": 1, "formula_order": "delta=q_latest-q_previous;q_estimated=q_latest+delta;error=q_ref-q_estimated;correction=error/0.1;raw=u_ff+correction;sent=float32(clip(raw))",
    "feedback_takeover_t": 9, "override_t": 8, "override_condition": "PE only",
    "control_dt_s": .05, "measurement_age_atol_s": 1e-12,
    "initial_and_prefix_atol": STATE_ATOL, "numeric_audit_atol": 1e-12, "numeric_audit_rtol": 0.,
    "sent_action_comparison": "exact float32 equality", "controller_target_atol_rad": 1e-6,
    "comparison_start_state_index": 9, "metric_calculation_dtype": "float64",
    "action_source_labels": {"0": "original_script_prefix", "1": "PE_forced_override_t8", "2": "actual_causal_extrapolated_feedback"},
    "compute_device": "cpu", "training_calls": 0, "statistics_fits": 0, "model_updates": 0, "candidate_expansions": 0,
    "task": TASK, "reset_note": "One explicit seeded reset per new run;constructor initialization separately recorded.",
    "delay_scope": "Newest outer measurement is t-1;also read older t-2.No current angle,qvel,RGB,truth,history actions or future values enter the estimate.Reference/feedforward and bottom PD anchor remain current.",
    "interpretation": "Fixed hand-written one-step extrapolation,not a trained dynamics model.Two known seeds,known reference/clock,historical controls reused.No parameter search or general stability/task-success claim.",
}
