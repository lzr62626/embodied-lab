"""Reopen exported CSV/NPZ and compare to the saved source values independently."""
import csv
import numpy as np
from compensation_common import SEEDS, CONDITIONS, NEW_GROUPS, read_numeric, require, sha


def verify_csv(path, header, columns):
    with path.open(encoding="utf-8", newline="") as stream:
        rows = list(csv.reader(stream))
    require(rows[0] == header and len(rows) == len(columns[0]) + 1, "CSV header/count differs:" + path.name)
    number = lambda value: 1. if value == "True" else 0. if value == "False" else float(value)
    actual = np.asarray([[number(value) for value in row] for row in rows[1:]], dtype=np.float64)
    expected = np.column_stack(columns).astype(np.float64)
    require(actual.shape == expected.shape and np.array_equal(actual, expected), "CSV values differ from saved arrays:" + path.name)
    return {"file": path.name, "rows": len(actual), "columns": len(header), "sha256": sha(path)}


def verify_numeric_exports(data_root, entries, output):
    checks = []
    for seed in SEEDS:
        comparison = read_numeric(output / f"seed-{seed:04d}-comparison.npz")
        names = [key for key in comparison if key.endswith("_rad")]
        checks.append(verify_csv(output / f"seed-{seed:04d}-states.csv", ["state_index", "time_s", *names],
                                [comparison["all_state_indices"], comparison["state_time_s"], *[comparison[key] for key in names]]))
        checks.append(verify_csv(output / f"seed-{seed:04d}-actions.csv", ["action_index", "time_s", *CONDITIONS],
                                [comparison["action_indices"], comparison["action_time_s"], *[comparison[f"{g}/action1"] for g in CONDITIONS]]))
        for entry in [row for row in entries if row["seed"] == seed and row["condition"] != "U"]:
            g = entry["condition"]
            audit = read_numeric((data_root / entry["path"]).resolve() / "feedback_audit.npz")
            fields = [key for key in audit if key != "controller_target_qpos"]
            checks.append(verify_csv(output / f"seed-{seed:04d}-{g}-feedback.csv", fields, [audit[key] for key in fields]))
            if g in NEW_GROUPS:
                estimate = read_numeric(output / f"seed-{seed:04d}-{g}-estimation.npz")
                fields = list(estimate)
                checks.append(verify_csv(output / f"seed-{seed:04d}-{g}-estimation.csv", fields, list(estimate.values())))
    return {"status": "passed", "CSV_files": len(checks), "checks": checks, "reopened": True, "source_numeric_values_exact": True}
