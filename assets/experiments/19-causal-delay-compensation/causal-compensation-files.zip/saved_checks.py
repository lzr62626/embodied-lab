"""Independent saved-file checks; no simulation imports and no capture controller calls."""
from pathlib import Path
import numpy as np
from PIL import Image
from compensation_common import QPOS, QVEL, RGB, CUBE, SUCCESS, STATE_ATOL, compare, plan, read_json, read_numeric, require
F64 = ('q_ref', 'q_actual', 'error_rad', 'u_ff', 'correction', 'u_raw', 'u_clipped_float64')
AUDIT_FIELDS = set(F64) | {'t', 'reference_state_index', 'actual_state_index', 'u_sent', 'was_clipped', 'sent_at_bound', 'controller_target_qpos'}

def check_feedback(data, reference, audit, config):
    times = np.arange(9, len(data['actions']), dtype=np.int64)
    extra = {"gain", "joint_delta_scale"} if "gain" in audit else set()
    require(set(audit) == AUDIT_FIELDS | extra and len(times) > 0, "Feedback audit fields/count differ.")
    if extra:
        for key, expected_value in (("gain", config["gain"]), ("joint_delta_scale", config["joint_delta_scale_rad"])):
            require(audit[key].shape == (len(times),) and audit[key].dtype == np.float64 and np.all(audit[key] == expected_value), "Gain/scale audit mismatch.")
    for key in ('t', 'reference_state_index', 'actual_state_index'):
        require(audit[key].dtype == np.int64 and np.array_equal(audit[key], times), 'Feedback time/index mismatch.')
    for key in F64:
        require(audit[key].shape == (len(times),) and audit[key].dtype == np.float64, 'Feedback float64 axes/type differ.')
    require(audit['u_sent'].shape == (len(times),) and audit['u_sent'].dtype == np.float32 and all((audit[key].shape == (len(times),) and audit[key].dtype == np.bool_ for key in ('was_clipped', 'sent_at_bound'))) and (audit['controller_target_qpos'].shape == (len(times), 7)) and (audit['controller_target_qpos'].dtype == np.float32), 'Feedback output/audit layout differs.')
    expected = {key: [] for key in F64}
    sent, clipped, touched = ([], [], [])
    bound = config['clip_limit_float64_from_float32']
    for t in times:
        ref = float(reference[QPOS][t, 0, 0])
        actual = float(data[QPOS][t, 0, 0])
        ff = float(reference['actions'][t, 0])
        error = ref - actual
        correction = config['gain'] * error / config['joint_delta_scale_rad']
        raw = ff + correction
        limited = min(bound, max(-bound, raw))
        value = np.float32(limited)
        for key, item in zip(F64, (ref, actual, error, ff, correction, raw, limited)):
            expected[key].append(item)
        sent.append(value)
        clipped.append(raw < -bound or raw > bound)
        touched.append(abs(value) == np.float32(bound))
    differences = {key: float(np.max(np.abs(audit[key] - np.asarray(values, dtype=np.float64)))) for key, values in expected.items()}
    require(all((v <= config['numeric_audit_atol'] for v in differences.values())), 'Independent feedback formula differs.')
    require(np.array_equal(audit['u_sent'], np.array(sent, dtype=np.float32)) and np.array_equal(audit['u_sent'], data['actions'][times, 0]) and np.array_equal(audit['was_clipped'], np.array(clipped, dtype=np.bool_)) and np.array_equal(audit['sent_at_bound'], np.array(touched, dtype=np.bool_)) and np.array_equal(audit['controller_target_qpos'], data['diagnostic/arm_target_qpos'][times, 0]), 'Actual sent command, clipping/touch flag or controller target differs.')
    return differences

def check_run(folder, condition, reference, config, *, check_png=True, check_feedback_audit=True):
    folder = Path(folder)
    data, meta = (read_numeric(folder / 'rollout.npz'), read_json(folder / 'run.json'))
    n = len(data['actions'])
    require(9 < n <= 20 and meta['completed_steps'] == meta['step_attempts'] == n and (meta['explicit_reset_calls'] == 1) and (meta['step_cap'] <= 20), 'Invalid run length/accounting.')
    base_fields = {k: v for k, v in reference.items() if not k.startswith('audit/')}
    allowed = set(base_fields)
    if condition == 'A':
        allowed |= {'audit/action_source', 'audit/intervention', 'audit/policy_active'}
    elif condition in ('D', 'E'):
        allowed |= {'audit/action_source', 'audit/intervention', 'audit/feedback_active'}
    require(set(data) == allowed, 'Unexpected trajectory fields.')
    for key, original in base_fields.items():
        state = key.startswith('obs/') or key in (CUBE, 'step_index', 'time_s')
        shape = original.shape if key.startswith('reset_info/') else (n + int(state), *original.shape[1:])
        require(data[key].shape == shape and data[key].dtype == original.dtype, 'Field shape/type mismatch: ' + key)
    for key in allowed - set(base_fields):
        require(data[key].shape == (n,) and data[key].dtype == (np.int64 if key.endswith('action_source') else np.bool_), 'Invalid provenance axis/type.')
    require(np.array_equal(data['step_index'][:, 0], np.arange(n + 1)) and np.array_equal(data['info/elapsed_steps'][:, 0], np.arange(1, n + 1)) and np.array_equal(data['time_s'][:, 0], np.arange(n + 1, dtype=np.float64) * 0.05) and (data['reset_info/elapsed_steps'].tolist() == [0]), 'Transition/state time alignment differs.')
    done = (data['terminated'] | data['truncated'])[:, 0]
    require(not done[:-1].any() and (n == meta['step_cap'] or done[-1]) and (meta['stopping_reason'] == ('terminated_or_truncated' if done[-1] else 'step_budget')) and (meta['success_any'] == bool(data[SUCCESS].any())), 'Episode boundary or budget flag differs.')
    actions = data['actions']
    require(actions.dtype == np.float32 and np.all(np.abs(actions) <= 1) and np.all(np.abs(actions[:, 0]) <= np.float32(config['command_limit_float32'])) and np.all(actions[:, 1:7] == 0) and np.all(actions[:, 7] == 1), 'Action bounds/interface differ.')
    expected = plan()[:n]
    if condition == 'A':
        expected[8, 0] = np.float32(0.1)
    if condition in ('U', 'A'):
        require(np.array_equal(actions, expected), 'Historical script plan differs.')
    else:
        if condition == 'D':
            expected[8, 0] = np.float32(0.1)
        require(np.array_equal(actions[:9], expected[:9]), 'Prefix or intervention differs.')
    if condition != 'U':
        labels = np.array([0] * 8 + [1] + [2] * (n - 9), dtype=np.int64)
        if condition == 'E':
            labels[8] = 0
        intervention = np.arange(n) == 8 if condition in ('A', 'D') else np.zeros(n, dtype=np.bool_)
        require(np.array_equal(data['audit/action_source'], labels) and np.array_equal(data['audit/intervention'], intervention), 'Intervention/provenance labels differ.')
        active = 'audit/policy_active' if condition == 'A' else 'audit/feedback_active'
        require(np.array_equal(data[active], np.zeros(n, dtype=np.bool_) if condition == 'A' else np.arange(n) >= 9), 'Feedback activation differs.')
    audit, audit_errors = (None, None)
    if condition in ('D', 'E'):
        audit = read_numeric(folder / 'feedback_audit.npz')
        audit_errors = check_feedback(data, reference, audit, config) if check_feedback_audit else None
        require(meta['feedback_decisions'] == n - 9 and meta['intervention_calls'] == int(condition == 'D'), 'Feedback decision metadata differs.')
    target = data[QPOS][:-1, 0, :7].astype(np.float64) + actions[:, :7].astype(np.float64) * 0.1
    target_error = float(np.max(np.abs(target - data['diagnostic/arm_target_qpos'][:, 0])))
    require(target_error <= config['controller_target_atol_rad'], 'PD target mapping differs from current-position delta.')
    count = 0
    if check_png:
        files = sorted((folder / 'frames').glob('*.png'))
        require([p.name for p in files] == [f'{s:04d}.png' for s in range(n + 1)], 'Raw frame names/count differ.')
        for s, path in enumerate(files):
            with Image.open(path) as image:
                require(image.mode == 'RGB' and image.size == (256, 256) and np.array_equal(np.asarray(image), data[RGB][s, 0]), 'PNG/RGB pixel mismatch.')
            count += 1
    return (data, meta, audit, {'verified_pngs': count, 'fields': len(data), 'steps': n, 'feedback_formula_max_abs_errors': audit_errors, 'controller_target_max_abs_error_rad': target_error})

def summary(delta):
    a = np.asarray(delta, dtype=np.float64)
    require(a.ndim == 1 and len(a) > 0 and np.isfinite(a).all(), 'Invalid metric series.')
    result = {'max_abs_rad': float(np.abs(a).max()), 'rmse_rad': float(np.sqrt(np.mean(a * a, dtype=np.float64))), 'end_signed_rad': float(a[-1]), 'end_abs_rad': float(abs(a[-1]))}
    direct = (sum((float(x) ** 2 for x in a)) / len(a)) ** 0.5
    require(abs(direct - result['rmse_rad']) <= 1e-12, 'Metric reduction cross-check failed.')
    return result
