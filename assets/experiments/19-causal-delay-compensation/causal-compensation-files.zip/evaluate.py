"""Independent read-only CPU verification; no simulator or collection-controller calls."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import numpy as np
from compensation_common import CONFIG, HERE, SEEDS, RUN_ORDER, NEW_GROUPS, CONDITIONS, QPOS, QVEL, CUBE, RGB, SUCCESS, compare, read_json, read_numeric, require, sha, no_simulator_import, write_json
from saved_checks import check_run, summary
from legacy_delay_checks import check_delayed
from saved_compensation import check_compensated, export_estimation
from verify_exports import verify_numeric_exports

def numeric_fingerprint(data):
    digest = hashlib.sha256()
    for key in sorted(data):
        value = np.ascontiguousarray(data[key])
        digest.update(json.dumps([key, value.dtype.str, list(value.shape)], separators=(',', ':')).encode())
        digest.update(value.tobytes(order='C'))
    return digest.hexdigest()

def csv_file(path, header, rows):
    with path.open('x', encoding='utf-8', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(header)
        writer.writerows(rows)

def outcome(data, meta, audit, reused):
    xyz = data[CUBE][-1, 0, :3].astype(np.float64) - data[CUBE][0, 0, :3]
    return {'actual_steps': len(data['actions']), 'simulation_time_s': float(data['time_s'][-1, 0]), 'stopping_reason': meta['stopping_reason'], 'reused_historical_run': reused, 'cube_net_xyz_m': xyz.tolist(), 'cube_net_displacement_m': float(np.linalg.norm(xyz)), 'reward_sum': float(data['rewards'].astype(np.float64).sum()), 'reward_final': float(data['rewards'][-1, 0]), 'success_any': bool(data[SUCCESS].any()), 'success_final': bool(data[SUCCESS][-1, 0]), 'terminated_final': bool(data['terminated'][-1, 0]), 'truncated_final': bool(data['truncated'][-1, 0]), 'feedback_decisions': len(audit['t']) if audit is not None else 0, 'clipped_decisions': int(audit['was_clipped'].sum()) if audit is not None else None, 'sent_at_bound_decisions': int(audit['sent_at_bound'].sum()) if audit is not None else None, 'clipped_action_indices': audit['t'][audit['was_clipped']].tolist() if audit is not None else None, 'sent_at_bound_action_indices': audit['t'][audit['sent_at_bound']].tolist() if audit is not None else None}

def main(data_root, output):
    if (data_root / 'files.json').is_file():
        expected_files = read_json(data_root / 'files.json')
        require(all((sha(data_root / name) == digest for name, digest in expected_files.items())), 'Public package SHA-256 differs.')
    output.mkdir(parents=True, exist_ok=False)
    try:
        config = read_json(data_root / 'config.json')
        require(config == CONFIG, 'Frozen configuration differs.')
        manifest = read_json(data_root / 'dataset_manifest.json')
        rows = manifest['sources']
        expected = [(s, g) for s in SEEDS for g in CONDITIONS]
        require([r['source_id'] for r in rows] == list(range(14)) and [(r['seed'], r['condition']) for r in rows] == expected and (len({r['trajectory_id'] for r in rows}) == 14) and (manifest['historical_run_count'] == 10) and (manifest['new_run_count'] == 4), 'Source mapping differs.')
        results, estimates, checks, fingerprints, new_data, new_meta, prefix_results = ({}, {}, {}, {}, {}, {}, {})
        for seed in SEEDS:
            entries = [r for r in rows if r['seed'] == seed]
            reference = read_numeric((data_root / entries[0]['path']).resolve() / 'rollout.npz')
            groups, audits, metadata = ({}, {}, {})
            for entry in entries:
                g = entry['condition']
                folder = (data_root / entry['path']).resolve()
                expected_prior_id = SEEDS.index(seed) * 5 + CONDITIONS.index(g) if g not in NEW_GROUPS else None
                require(sha(folder / 'rollout.npz') == entry['rollout_sha256'] and entry['prior_article18_source_id'] == expected_prior_id and (entry['measurement_delay_steps'] == config['condition_delays'].get(g)) and (entry['reused_historical_run'] == (g not in NEW_GROUPS)) and (entry['linear_extrapolation'] == (g in NEW_GROUPS)) and (entry['intervention'] == g.startswith('P')) and (entry['outer_reference_feedback'] == (g != 'U')), 'Source condition/identity differs.')
                kind = 'U' if g == 'U' else 'D' if g.startswith('P') else 'E'
                data, meta, audit, detail = check_run(folder, kind, reference, config, check_feedback_audit=g not in ('C1', 'P1', 'CE', 'PE'))
                require(meta['seed'] == seed and meta['group'] == entry['group'] and (meta['completed_steps'] == entry['completed_steps']), 'Source metadata differs.')
                if g in ('C1', 'P1'):
                    detail['delayed_formula_max_abs_errors'] = check_delayed(data, reference, audit, config)
                if g in NEW_GROUPS:
                    require(meta['condition'] == g and meta['delay_steps'] == 1 and (meta['gain'] == 1.0) and meta['linear_extrapolation'], 'New condition metadata differs.')
                    detail['compensation_formula_max_abs_errors'] = check_compensated(data, reference, audit, config)
                    runtime = read_json(folder / 'runtime.json')
                    expected_runtime = read_json(data_root / 'environment.json')['reference_runtime_by_seed'][str(seed)]
                    require(all((runtime[key] == expected_runtime[key] for key in ('action_space', 'timing', 'resolved_backend', 'controllers', 'sensor'))), 'Saved runtime core differs.')
                    new_data[seed, g], new_meta[seed, g] = (data, meta)
                require(numeric_fingerprint(data) == entry['numeric_content_fingerprint'], 'Numeric manifest fingerprint differs.')
                groups[g], metadata[g] = (data, meta)
                audits[g] = audit
                fingerprints[f'{seed}-{g}'] = numeric_fingerprint(data)
                checks[f'{seed}-{g}'] = detail
            paired = {'CE_vs_C1_states_0_to_9': compare(groups['CE'], groups['C1'], list(range(10))), 'CE_vs_C0_states_0_to_9': compare(groups['CE'], groups['C0'], list(range(10))), 'CE_vs_U_states_0_to_9': compare(groups['CE'], reference, list(range(10))), 'PE_vs_P1_states_0_to_9': compare(groups['PE'], groups['P1'], list(range(10))), 'PE_vs_P0_states_0_to_9': compare(groups['PE'], groups['P0'], list(range(10))), 'PE_vs_CE_states_0_to_8': compare(groups['PE'], groups['CE'], list(range(9)))}
            require(all((row['within_tolerance'] for row in paired.values())), 'Saved paired prefixes differ.')
            for entry in entries:
                g = entry['condition']
                if g not in NEW_GROUPS:
                    continue
                folder = (data_root / entry['path']).resolve()
                initial = {name: compare(groups[g], groups[name], [0]) for name in ('U', 'C0', 'P0', 'C1', 'P1')}
                if g == 'CE':
                    prefix = {'C1_states_0_to_9': compare(groups[g], groups['C1'], list(range(10))), 'C0_states_0_to_9': compare(groups[g], groups['C0'], list(range(10))), 'U_states_0_to_9': compare(groups[g], reference, list(range(10)))}
                else:
                    prefix = {'P1_states_0_to_9': compare(groups[g], groups['P1'], list(range(10))), 'P0_states_0_to_9': compare(groups[g], groups['P0'], list(range(10))), 'CE_states_0_to_8': compare(groups[g], groups['CE'], list(range(9)))}
                require(initial == read_json(folder / 'initial-checks.json') and prefix == read_json(folder / 'prefix-checks.json'), 'Saved comparability audit differs.')
            prefix_results[str(seed)] = paired
            estimates[str(seed)] = {g: export_estimation(groups[g], audits[g], output, f'seed-{seed:04d}-{g}', csv_file) for g in NEW_GROUPS}
            end = min((len(data['actions']) for data in groups.values()))
            idx = np.arange(9, end + 1, dtype=np.int64)
            require(len(idx) > 1, 'Insufficient common feedback-stage coverage.')
            arrays = {'comparison_state_indices': idx, 'all_state_indices': np.arange(end + 1, dtype=np.int64), 'state_time_s': reference['time_s'][:end + 1, 0].copy(), 'action_indices': np.arange(end, dtype=np.int64), 'action_time_s': reference['time_s'][:end, 0].copy()}
            per_group = {}
            for g, data in groups.items():
                arrays[f'{g}/q1_rad'] = data[QPOS][:end + 1, 0, 0].astype(np.float64)
                arrays[f'{g}/qvel1_rad_s'] = data[QVEL][:end + 1, 0, 0].astype(np.float64)
                arrays[f'{g}/action1'] = data['actions'][:end, 0].copy()
                arrays[f'{g}/tracking_deviation_rad'] = arrays[f'{g}/q1_rad'] - reference[QPOS][:end + 1, 0, 0].astype(np.float64)
                per_group[g] = outcome(data, metadata[g], audits[g], g not in NEW_GROUPS)
                per_group[g]['tracking'] = summary(arrays[f'{g}/tracking_deviation_rad'][idx])
            arrays['r0_rad'] = arrays['P0/q1_rad'] - arrays['C0/q1_rad']
            arrays['r1_rad'] = arrays['P1/q1_rad'] - arrays['C1/q1_rad']
            arrays['rE_rad'] = arrays['PE/q1_rad'] - arrays['CE/q1_rad']
            arrays['rE_minus_r1_rad'] = arrays['rE_rad'] - arrays['r1_rad']
            arrays['CE_minus_C1_rad'] = arrays['CE/q1_rad'] - arrays['C1/q1_rad']
            arrays['PE_minus_P1_rad'] = arrays['PE/q1_rad'] - arrays['P1/q1_rad']
            paired_metrics = {key: summary(arrays[key][idx]) for key in ('r0_rad', 'r1_rad', 'rE_rad', 'rE_minus_r1_rad', 'CE_minus_C1_rad', 'PE_minus_P1_rad')}
            first = {}
            for g in NEW_GROUPS:
                audit = audits[g]
                selected = np.flatnonzero(np.isin(audit['t'], (9, 10, 19)))
                first[g] = [{key: audit[key][j].item() for key in audit if key != 'controller_target_qpos'} for j in selected]
            onset = {}
            for g in CONDITIONS[1:]:
                changed = np.flatnonzero(np.abs(arrays[f'{g}/tracking_deviation_rad']) > config['initial_and_prefix_atol'][QPOS])
                changed_action = np.flatnonzero(arrays[f'{g}/action1'] != arrays['U/action1'])
                onset[g] = {'first_tracking_state_above_1e_6_rad': int(changed[0]) if len(changed) else None, 'first_action_unequal_to_U': int(changed_action[0]) if len(changed_action) else None}
            different_measurements = np.flatnonzero(audits['CE']['q_latest'] != audits['PE']['q_latest'])
            first_affected_query = int(audits['PE']['t'][different_measurements[0]]) if len(different_measurements) else None
            require(first_affected_query is None or first_affected_query >= 10, 'An intervention-affected measurement arrived too early.')
            results[str(seed)] = {'common_completed_actions': end, 'comparison_state_indices': idx.tolist(), 'groups': per_group, 'paired_responses': paired_metrics, 'selected_decisions': first, 'onset_vs_U': onset, 'first_different_delayed_measurement_action_index': first_affected_query, 'first_measurement_after_intervention_state_index': 9, 'first_action_using_that_measurement_index': 10}
            with (output / f'seed-{seed:04d}-comparison.npz').open('xb') as stream:
                np.savez_compressed(stream, **arrays)
            reread = read_numeric(output / f'seed-{seed:04d}-comparison.npz')
            require(set(arrays) == set(reread) and all((np.array_equal(value, reread[key]) for key, value in arrays.items())), 'Numeric export differs.')
            names = [key for key in arrays if key.endswith('_rad')]
            csv_file(output / f'seed-{seed:04d}-states.csv', ['state_index', 'time_s', *names], ([k, float(reference['time_s'][k, 0]), *[float(arrays[key][k]) for key in names]] for k in range(end + 1)))
            csv_file(output / f'seed-{seed:04d}-actions.csv', ['action_index', 'time_s', *groups], ([t, float(reference['time_s'][t, 0]), *[float(groups[g]['actions'][t, 0]) for g in groups]] for t in range(end)))
            for g, audit in audits.items():
                if audit is None:
                    continue
                fields = [key for key in audit if key != 'controller_target_qpos']
                csv_file(output / f'seed-{seed:04d}-{g}-feedback.csv', fields, ([audit[key][j].item() for key in fields] for j in range(len(audit['t']))))
        export_checks = verify_numeric_exports(data_root, rows, output)
        write_json(output / 'export-validation.json', export_checks)
        metrics = {'version': config['version'], 'seeds': results, 'new_runs': 4, 'historical_runs_reused_including_U': 10, 'gain': 1.0, 'delay_steps': 1, 'no_parameter_selection': True, 'no_significance_test': True, 'units': {'angle': 'rad', 'velocity': 'rad/s', 'cube_displacement': 'm', 'time': 's'}}
        write_json(output / 'estimation_metrics.json', {'version': config['version'], 'seeds': estimates, 'scope': 'Both estimates evaluated on the same actual run and action indices;current truth offline only;not another executed hold controller.'})
        write_json(output / 'metrics.json', metrics)
        require(read_json(output / 'metrics.json') == metrics, 'Metrics JSON reread differs.')
        local = {'performed': False}
        no_simulator_import()
        validation = {'status': 'passed', 'scope': 'Saved-file independent CPU numerical acceptance;visual QA separate', 'new_runs': 4, 'new_pngs': sum((checks[f'{s}-{g}']['verified_pngs'] for s, g in RUN_ORDER)), 'verified_pngs': sum((row['verified_pngs'] for row in checks.values())), 'checks': checks, 'numeric_content_fingerprints': fingerprints, 'paired_prefixes': prefix_results, 'local_integrity': local, 'N_and_N_plus_one': True, 'PNG_pixels_equal_RGB': True, 'compensated_formula_recomputed_independently': True, 'legacy_delayed_formula_recomputed_independently': True, 'current_PD_anchor_verified': True, 'reference_clock_not_delayed': True, 'same_run_measurements_t_minus_one_and_two': True, 'current_truth_diagnostic_only': True, 'measurement_age_s': 0.05, 'metrics_reopened_and_recomputed': True, 'pure_numeric_npz': True, 'CSV_exports_reopened_and_exact': export_checks['CSV_files'], 'simulation_calls': 0, 'training_calls': 0, 'statistics_fits': 0}
        write_json(output / 'validation.json', validation)
        print(json.dumps({'status': 'passed', 'new_pngs': validation['new_pngs'], 'verified_pngs': validation['verified_pngs'], 'local_integrity': local}, ensure_ascii=True), flush=True)
    except Exception as error:
        write_json(output / 'failure.json', {'type': type(error).__name__, 'message': str(error), 'simulation_calls': 0})
        raise
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-root', type=Path, default=HERE)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    main(args.data_root.resolve(), args.output_dir)
