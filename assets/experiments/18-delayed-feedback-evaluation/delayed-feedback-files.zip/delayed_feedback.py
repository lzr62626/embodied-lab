"""Select a same-run past measurement; keep reference/feedforward at current t."""
import numpy as np
from feedback_controller import feedback, finite_scalar


class MeasurementCache:
    def __init__(self, run_id):
        self.run_id = run_id
        self.values = []
        self.times = []

    def append(self, run_id, state_index, time_s, joint1):
        if run_id != self.run_id or state_index != len(self.values):
            raise ValueError("Cache owner or sequential state index differs.")
        value = finite_scalar(joint1, "observed_joint1")
        timestamp = finite_scalar(time_s, "state_time_s")
        if timestamp < 0 or (self.times and timestamp <= self.times[-1]):
            raise ValueError("Cache simulation time is not increasing.")
        self.values.append(np.float64(value))
        self.times.append(np.float64(timestamp))

    def select(self, run_id, t, delay_steps):
        if run_id != self.run_id or type(t) is not int or type(delay_steps) is not int or delay_steps not in (0, 1):
            raise ValueError("Invalid cache owner/index/delay.")
        used = t - delay_steps
        if used < 0 or t >= len(self.values):
            raise ValueError("Missing actual history; no padding or future substitution.")
        return {"measurement_state_index": np.int64(used), "q_used": np.float64(self.values[used]),
                "measurement_time_s": np.float64(self.times[used])}


def decide(cache, run_id, t, q_ref, u_ff, reference_time_s, delay_steps=1):
    selected = cache.select(run_id, t, delay_steps)
    reference_time = finite_scalar(reference_time_s, "reference_time_s")
    if abs(reference_time - cache.times[t]) > 1e-12:
        raise ValueError("Reference and current simulation clocks must stay at the same t.")
    # Only these three scalars cross into the unchanged article15 outer controller.
    result = feedback(q_ref, selected["q_used"], u_ff)
    result["q_used"] = result.pop("q_actual")
    result["error_used_rad"] = result.pop("error_rad")
    # Current state is read only AFTER the sent command is computed, for diagnostics.
    current = cache.select(run_id, t, 0)
    result.update(t=np.int64(t), reference_state_index=np.int64(t), actual_state_index=np.int64(t),
                  measurement_state_index=selected["measurement_state_index"], delay_steps=np.int64(delay_steps),
                  gain=np.float64(1.), joint_delta_scale=np.float64(.1),
                  q_current=current["q_used"], error_current_rad=np.float64(result["q_ref"] - current["q_used"]),
                  current_time_s=current["measurement_time_s"], reference_time_s=reference_time,
                  measurement_time_s=selected["measurement_time_s"],
                  measurement_age_s=np.float64(current["measurement_time_s"] - selected["measurement_time_s"]))
    return result
