"""Portable protocol constants and pure saved-data helpers; no private maintenance or collection code."""

from pathlib import Path
import numpy as np
from numeric_helpers import QPOS,QVEL,RGB,CUBE,SUCCESS,STATE_ATOL,require,read_json,write_json,read_numeric,sha,compare,plan,no_simulator_import

HERE = Path(__file__).resolve().parent

SEEDS = (45, 46)

NEW_GROUPS = {"C1": "C1-delayed-clean", "P1": "P1-delayed-perturbed"}

RUN_ORDER = [(seed, condition) for seed in SEEDS for condition in ("C1", "P1")]

TASK = {"task": "PushCube-v1", "robot": "panda", "num_envs": 1,
        "obs_mode": "rgb", "control_mode": "pd_joint_delta_pos", "camera": "base_camera",
        "width": 256, "height": 256, "shader_pack": "minimal", "sim_backend": "cpu", "render_backend": "cpu"}

CONFIG = {
    "version": "delayed-feedback-evaluation-v1", "seeds": list(SEEDS), "gain": 1.,
    "new_groups": NEW_GROUPS, "run_order": [[s, g] for s, g in RUN_ORDER],
    "condition_delays": {"C0": 0, "P0": 0, "C1": 1, "P1": 1},
    "new_runs": 4, "max_steps_per_run": 20, "max_step_attempts_total": 80,
    "joint_delta_scale_rad": .1, "command_limit_nominal": .1,
    "command_limit_float32": float(np.float32(.1)), "clip_limit_float64_from_float32": float(np.float32(.1)),
    "boundary_rule": "Clip in float64 against the existing float32 interface bound, then cast to float32",
    "reference_observation_index": "t, never t-1 or t+1", "actual_observation_index": "t",
    "measurement_observation_index": "t-delay_steps from the same actual run",
    "formula": "error_used=q_ref[t]-q_used[t-delay]; correction=error_used/0.1rad; sent=float32(clip(u_ff[t]+correction))",
    "feedback_takeover_t": 9, "override_t": 8, "override_condition": "P1 only",
    "control_dt_s": .05, "measurement_age_atol_s": 1e-12,
    "initial_and_prefix_atol": STATE_ATOL, "numeric_audit_atol": 1e-12, "numeric_audit_rtol": 0.,
    "sent_action_comparison": "exact float32 equality", "controller_target_atol_rad": 1e-6,
    "comparison_start_state_index": 9, "metric_calculation_dtype": "float64",
    "action_source_labels": {"0": "original_script_prefix", "1": "P1_forced_override_t8", "2": "actual_delayed_outer_feedback"},
    "compute_device": "cpu", "training_calls": 0, "statistics_fits": 0, "model_updates": 0, "candidate_expansions": 0,
    "task": TASK, "reset_note": "One explicit seeded reset per new run; constructor initialization separately recorded.",
    "delay_scope": "Only the outer first-joint measurement is stale. Reference/feedforward clock and underlying PD/current-position anchor remain current; no action queue or wall-clock sleep.",
    "interpretation": "Known seeds, historical C0/P0 reused, fixed gain1 for matched conditions; no parameter selection, randomized causal-effect claim or real-robot latency claim.",
}
