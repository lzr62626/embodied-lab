"""Independent CPU replay from numeric sources. No simulator or live predictor imports."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import numpy as np
from numeric_helpers import (QPOS,QVEL,RGB,CUBE,SUCCESS,require,read_json,write_json,read_numeric,sha,compare,no_simulator_import)
from saved_checks import check_run
from saved_compensation import check_compensated

HERE=Path(__file__).resolve().parent
CONDITIONS=('U','CE','PE','CV','PV');NEW=('CV','PV')
KEYS_I=('t','measurement_state_index','reference_state_index','actual_state_index','prediction_target_state_index','delay_steps')
KEYS_B=('was_clipped','sent_at_bound')
KEYS_F=('q_latest','v_latest','measurement_time_s','current_time_s','reference_time_s','measurement_age_s','predicted_increment','q_pred_velocity','q_ref','u_ff','error_rad','correction','u_raw','u_clipped_float64','q_current_diagnostic','estimate_error_rad','gain','joint_delta_scale')

def fingerprint(data):
    digest=hashlib.sha256()
    for key in sorted(data):
        a=np.ascontiguousarray(data[key]);digest.update(json.dumps([key,a.dtype.str,list(a.shape)],separators=(',',':')).encode());digest.update(a.tobytes(order='C'))
    return digest.hexdigest()

def independent_command(reference,estimate,ff,config):
    bound=config['clip_limit_float64_from_float32'];error=reference-estimate;correction=config['gain']*error/config['joint_delta_scale_rad']
    raw=ff+correction;limited=max(-bound,min(bound,raw));sent=np.float32(limited)
    return dict(error_rad=error,correction=correction,u_raw=raw,u_clipped_float64=limited,u_sent=sent,
                was_clipped=raw < -bound or raw > bound,sent_at_bound=abs(sent)==np.float32(bound))

def check_velocity(data,ref,audit,config):
    n=len(data['actions']);times=list(range(9,n));atol=config['numeric_audit_atol'];clocktol=config['measurement_age_atol_s']
    require(set(audit)==set(KEYS_I+KEYS_B+KEYS_F+('u_sent','controller_target_qpos')),'Velocity audit fields differ.')
    for names,dtype in ((KEYS_I,np.int64),(KEYS_B,np.bool_),(KEYS_F,np.float64),(('u_sent',),np.float32)):
        for name in names:require(audit[name].shape==(len(times),) and audit[name].dtype==dtype,'Velocity audit field shape/type differs: '+name)
    require(audit['controller_target_qpos'].shape==(len(times),7) and audit['controller_target_qpos'].dtype==np.float32,'Audit target shape/type differs.')
    rows=[];differences={k:0. for k in KEYS_F}
    for j,t in enumerate(times):
        current=float(data[QPOS][t,0,0]);q=float(data[QPOS][t-1,0,0]);previous=float(data[QPOS][t-2,0,0]);v=float(data[QVEL][t-1,0,0])
        now,measured,older,next_time=(float(data['time_s'][k,0]) for k in (t,t-1,t-2,t+1))
        reference_time=float(ref['time_s'][t,0]);age=now-measured;interval=measured-older
        require(all(abs(x)<=clocktol for x in (reference_time-now,age-.05,interval-.05,next_time-now-.05)),'Measurement/reference/transition clock differs.')
        increment=v*age;estimated=q+increment;r=float(ref[QPOS][t,0,0]);ff=float(ref['actions'][t,0])
        command=independent_command(r,estimated,ff,config)
        expected=dict(t=t,measurement_state_index=t-1,reference_state_index=t,actual_state_index=t,prediction_target_state_index=t,delay_steps=1,
          q_latest=q,v_latest=v,measurement_time_s=measured,current_time_s=now,reference_time_s=reference_time,measurement_age_s=age,
          predicted_increment=increment,q_pred_velocity=estimated,q_ref=r,u_ff=ff,q_current_diagnostic=current,
          estimate_error_rad=estimated-current,gain=config['gain'],joint_delta_scale=config['joint_delta_scale_rad'],**command)
        for key in KEYS_I+KEYS_B:require(audit[key][j]==expected[key],'Velocity audit index/flag differs: '+key)
        for key in KEYS_F:
            error=abs(float(audit[key][j])-expected[key]);require(error<=atol,'Independent float64 audit differs: '+key);differences[key]=max(error,differences[key])
        require(audit['u_sent'][j].tobytes()==command['u_sent'].tobytes()==data['actions'][t,0].tobytes(),'Actual float32 send differs in bits.')
        require(np.array_equal(audit['controller_target_qpos'][j],data['diagnostic/arm_target_qpos'][t,0]),'Actual controller target differs.')
        pos_est=q+(q-previous);v_diff=(q-previous)/interval
        require(abs((estimated-pos_est)-.05*(v-v_diff))<=atol,'Equal-period position/velocity identity differs.')
        pos=independent_command(r,pos_est,ff,config)
        raw_gap=command['u_raw']-pos['u_raw'];clipped_gap=command['u_clipped_float64']-pos['u_clipped_float64'];sent_gap=float(command['u_sent'])-float(pos['u_sent'])
        require(abs(raw_gap+(estimated-pos_est)/config['joint_delta_scale_rad'])<=atol and abs(clipped_gap)<=abs(raw_gap)+atol,'Command gap identity differs.')
        category=0 if raw_gap==0 else 1 if clipped_gap==0 else 2 if sent_gap==0 else 3
        rows.append(dict(t=np.int64(t),previous_state_index=np.int64(t-2),measurement_state_index=np.int64(t-1),current_state_index=np.int64(t),next_state_index=np.int64(t+1),
          previous_time_s=older,measurement_time_s=measured,current_time_s=now,next_time_s=next_time,measurement_age_s=age,previous_interval_s=interval,
          q_previous_rad=previous,q_latest_rad=q,q_current_rad=current,q_ref_rad=r,v_latest_rad_s=v,v_difference_rad_s=v_diff,v_gap_rad_s=v-v_diff,
          predicted_increment_rad=increment,q_hold_rad=q,q_pred_position_rad=pos_est,q_pred_velocity_rad=estimated,
          error_hold_rad=q-current,error_position_rad=pos_est-current,error_velocity_rad=estimated-current,u_ff=ff,
          correction_velocity=command['correction'],correction_position=pos['correction'],raw_velocity=command['u_raw'],raw_position=pos['u_raw'],
          clipped_velocity=command['u_clipped_float64'],clipped_position=pos['u_clipped_float64'],sent_velocity=command['u_sent'],sent_position_candidate=pos['u_sent'],
          velocity_strict_clipped=command['was_clipped'],velocity_at_bound=command['sent_at_bound'],position_candidate_strict_clipped=pos['was_clipped'],position_candidate_at_bound=pos['sent_at_bound'],
          raw_gap=raw_gap,clipped_gap=clipped_gap,sent_gap=sent_gap,rounding_residual=sent_gap-clipped_gap,category=np.int64(category)))
    return {k:np.asarray([row[k] for row in rows]) for k in rows[0]},differences

def stat(values,unit='rad'):
    vals=[float(x) for x in values];require(bool(vals),'Empty metric range.')
    return {'samples':len(vals),'max_abs':max(abs(x) for x in vals),'rmse':math.sqrt(math.fsum(x*x for x in vals)/len(vals)),
            'mean_signed':math.fsum(vals)/len(vals),'unit':unit}

def write_npz_checked(out,name,arrays):
    path=out/name
    with path.open('xb') as stream:np.savez_compressed(stream,**arrays)
    actual=read_numeric(path)
    require(set(actual)==set(arrays) and all(actual[k].dtype==v.dtype and actual[k].shape==v.shape and actual[k].tobytes()==v.tobytes() for k,v in arrays.items()),'NPZ round trip differs.')

def write_csv_checked(out,name,arrays):
    path=out/name
    with path.open('x',encoding='utf-8',newline='') as stream:
        w=csv.writer(stream);w.writerow(list(arrays));w.writerows(zip(*(a.tolist() for a in arrays.values())))
    with path.open(encoding='utf-8',newline='') as stream:rows=list(csv.reader(stream))
    require(rows[0]==list(arrays) and len(rows)==len(next(iter(arrays.values())))+1,'CSV header/row count differs.')
    for i,(key,values) in enumerate(arrays.items()):
        col=[row[i] for row in rows[1:]]
        converted=np.asarray([v=='True' for v in col] if values.dtype.kind=='b' else col,dtype=values.dtype)
        require(converted.tobytes()==values.tobytes(),'CSV numeric bits differ: '+key)

def main(root,out):
    out.mkdir(parents=True,exist_ok=False)
    config=read_json(root/'config.json');manifest=read_json(root/'source_manifest.json');rows=manifest['sources']
    require([(r['seed'],r['condition'],r['source_id']) for r in rows]==[(s,g,i) for i,(s,g) in enumerate((s,g) for s in (45,46) for g in CONDITIONS)],'Stable source map differs.')
    require(manifest['historical_run_count']==6 and manifest['new_run_count']==4,'Wrong source counts.')
    if (root/'files.json').exists():require(all(sha(root/name)==digest for name,digest in read_json(root/'files.json').items()),'Archive integrity differs.')
    environment=read_json(root/'environment.json');checks={};estimates={};seed_metrics={};cases={};emitted=[];attempts=0;queries=0
    for seed in (45,46):
        groups={};meta={};audits={};analysis={};estimates[str(seed)]={}
        sr=[r for r in rows if r['seed']==seed];reference=read_numeric((root/sr[0]['path'])/'rollout.npz')
        for row in sr:
            g=row['condition'];folder=(root/row['path']).resolve();is_new=g in NEW
            require(row['reused_historical_run']==(not is_new) and sha(folder/'rollout.npz')==row['rollout_sha256'],'Source role or SHA differs.')
            if row['audit_filename']:require(sha(folder/row['audit_filename'])==row['audit_sha256'],'Source audit SHA differs.')
            data,info,audit,check=check_run(folder,'U' if g=='U' else 'D' if g.startswith('P') else 'E',reference,config,
                    check_feedback_audit=False,audit_filename=row['audit_filename'] or 'feedback_audit.npz')
            require(info['seed']==seed and fingerprint(data)==row['numeric_content_fingerprint'] and len(data['actions'])==row['completed_steps'],'Run identity or content differs.')
            if is_new:
                attempts+=info['step_attempts'];queries+=len(audit['t'])
                analysis[g],check['velocity_audit_errors']=check_velocity(data,reference,audit,config)
                runtime=read_json(folder/'runtime.json');expected=environment['reference_runtime_by_seed'][str(seed)]
                require(all(runtime[k]==expected[k] for k in ('action_space','timing','resolved_backend','controllers','sensor')),'Runtime core differs.')
                target_history='CE' if g=='CV' else 'PE'
                initial={h:compare(data,groups[h],[0]) for h in ('U','CE','PE')}
                prefix={target_history+'_states_0_to_9':compare(data,groups[target_history],list(range(10)))}
                if g=='CV':prefix['U_states_0_to_9']=compare(data,reference,list(range(10)))
                else:prefix['CV_states_0_to_8']=compare(data,groups['CV'],list(range(9)))
                require(all(x['within_tolerance'] for x in (*initial.values(),*prefix.values())),'New paired conditions not comparable.')
                require(initial==read_json(folder/'initial-checks.json') and prefix==read_json(folder/'prefix-checks.json'),'Saved comparability checks differ.')
                check['initial_checks']=initial;check['prefix_checks']=prefix
            elif audit is not None:check['historical_position_audit_errors']=check_compensated(data,reference,audit,config)
            groups[g]=data;meta[g]=info;audits[g]=audit;checks[f'{seed}-{g}']=check
        common=min(len(x['actions']) for x in groups.values());k=np.arange(common+1,dtype=np.int64);t=np.arange(common,dtype=np.int64)
        states={'state_index':k,'time_s':reference['time_s'][k,0].copy()};actions={'t':t,'time_s':reference['time_s'][t,0].copy()}
        results={};indices=list(range(9,common+1))
        for g,data in groups.items():
            q=data[QPOS][k,0,0].astype(np.float64);r=reference[QPOS][k,0,0].astype(np.float64);delta=q-r
            states[f'q_{g}_rad']=q;states[f'{g}_minus_U_rad']=delta;actions['u_'+g]=data['actions'][t,0].copy()
            cube=data[CUBE][-1,0,:3].astype(np.float64)-data[CUBE][0,0,:3].astype(np.float64);a=audits[g];m=meta[g]
            results[g]={'actual_steps':len(data['actions']),'simulation_time_s':float(data['time_s'][-1,0]),'stopping_reason':m['stopping_reason'],
              'reused_historical_run':g not in NEW,'tracking':{**stat(delta[9:]),'end_signed':float(delta[-1]),'end_abs':abs(float(delta[-1]))},
              'cube_net_xyz_m':cube.tolist(),'cube_net_displacement_m':float(np.linalg.norm(cube)),
              'reward_sum':math.fsum(float(x) for x in data['rewards'][:,0]),'reward_final':float(data['rewards'][-1,0]),
              'success_any':bool(data[SUCCESS].any()),'success_final':bool(data[SUCCESS][-1,0]),
              'terminated_final':bool(data['terminated'][-1,0]),'truncated_final':bool(data['truncated'][-1,0]),
              'feedback_decisions':len(a['t']) if a else 0,'strict_clipped':int(a['was_clipped'].sum()) if a else None,
              'sent_at_bound':int(a['sent_at_bound'].sum()) if a else None}
        paired={}
        for name,left,right in [('position','PE','CE'),('velocity','PV','CV')]:
            delta=states[f'q_{left}_rad']-states[f'q_{right}_rad'];states[f'paired_{name}_rad']=delta
            paired[name]={**stat(delta[9:]),'end_signed':float(delta[-1]),'end_abs':abs(float(delta[-1]))}
        seed_metrics[str(seed)]={'comparison_state_indices':indices,'common_completed_actions':common,'groups':results,'paired_responses':paired}
        stem=f'seed-{seed:04d}-'
        names=[stem+'comparison.npz',stem+'states.csv',stem+'actions.csv'];write_npz_checked(out,names[0],{**states,**{'actions/'+key:value for key,value in actions.items()}})
        write_csv_checked(out,names[1],states);write_csv_checked(out,names[2],actions);emitted.extend(names)
        for g,a in analysis.items():
            methods={name:stat(a['error_'+name+'_rad']) for name in ('hold','position','velocity')}
            peaks={name:np.flatnonzero(np.abs(a['error_'+name+'_rad'])==row['max_abs']).tolist() for name,row in methods.items()}
            select=sorted(set(np.flatnonzero(np.isin(a['t'],[9,10,11,15,16,19])).tolist()+[i for ids in peaks.values() for i in ids]))
            estimates[str(seed)][g]={'decision_action_indices':a['t'].tolist(),'methods':methods,
              'peaks':{name:[int(a['t'][i]) for i in ids] for name,ids in peaks.items()},'velocity_gap':stat(a['v_gap_rad_s'],'rad/s'),
              'command_gaps':{k:stat(a[k],'normalized') for k in ('raw_gap','clipped_gap','sent_gap')},
              'categories':{c:int(np.sum(a['category']==j)) for j,c in enumerate('ABCD')},
              'candidate_clipped':int(a['position_candidate_strict_clipped'].sum()),'candidate_touched':int(a['position_candidate_at_bound'].sum())}
            cases[f'{seed}-{g}']=[{key:value[i].item() for key,value in a.items()} for i in select]
            names=[stem+g+'-diagnostics.npz',stem+g+'-diagnostics.csv'];write_npz_checked(out,names[0],a);write_csv_checked(out,names[1],a);emitted.extend(names)
    metrics={'version':config['version'],'seeds':seed_metrics,'new_runs':4,'historical_runs_reused':6,'units':{'angle':'rad','velocity':'rad/s','time':'s','cube_displacement':'m'},'training_calls':0,'statistics_fits':0}
    for name,data in [('metrics.json',metrics),('estimation_metrics.json',{'version':config['version'],'seeds':estimates,'scope':'Same-run estimation; only velocity was executed in CV/PV.'}),('case_summary.json',{'cases':cases,'scope':'Fixed times plus all exact ties at method peak errors; full rows in diagnostics CSV.'})]:
        write_json(out/name,data);require(read_json(out/name)==data,'Metric JSON round trip differs.');emitted.append(name)
    exact_comparison=0
    if (root/'metrics.json').is_file():
        for name in emitted:
            if name.endswith('.npz'):
                a=read_numeric(root/name);b=read_numeric(out/name);require(a.keys()==b.keys() and all(a[k].tobytes()==b[k].tobytes() and a[k].dtype==b[k].dtype and a[k].shape==b[k].shape for k in a),'Recomputed NPZ differs.')
            elif name.endswith('.json'):require(read_json(root/name)==read_json(out/name),'Recomputed metric JSON differs.')
            else:require(sha(root/name)==sha(out/name),'Recomputed CSV differs.')
            exact_comparison+=1
    tile_count=0
    if (root/'figure-validation.json').is_file():
        from PIL import Image
        fig=read_json(root/'figure-validation.json')
        for name,digest in fig['figure_sha256'].items():
            require(sha(root/name)==digest,'Figure SHA differs.')
            with Image.open(root/name) as image:image.verify()
        with Image.open(root/'velocity-frames.png') as sheet:
            for tile in fig['tiles']:
                row=next(r for r in rows if r['seed']==tile['seed'] and r['condition']==tile['condition'])
                with Image.open(root/row['path']/'frames'/f"{tile['state_index']:04d}.png") as image:
                    require(np.array_equal(np.asarray(image),np.asarray(sheet.crop(tuple(tile['box'])))),'Montage modified raw PNG pixels.')
                tile_count+=1
    require(attempts<=80,'Saved attempt budget exceeds 80.')
    no_simulator_import()
    report={'status':'passed','new_runs':4,'new_pngs':sum(checks[f'{s}-{g}']['verified_pngs'] for s in (45,46) for g in NEW),
      'verified_pngs':sum(x['verified_pngs'] for x in checks.values()),'historical_sources':6,'prediction_decisions':queries,
      'completed_steps_total':attempts,'checks':checks,'scalar_independent_of_live_predictor':True,'same_run_t_minus_one_qpos_qvel':True,
      'current_truth_diagnostic_only':True,'reference_clock_not_delayed':True,'actual_float32_action_bits_exact':True,
      'N_and_N_plus_one':True,'PNG_pixels_equal_RGB':True,'CSV_exports_reopened_and_exact':sum(n.endswith('.csv') for n in emitted),
      'exact_expected_exports_checked':exact_comparison,'case_tiles_pixel_exact':tile_count,
      'simulation_calls':0,'training_calls':0,'statistics_fits':0,'pure_numeric_npz':True}
    write_json(out/'validation.json',report)
    print({k:report[k] for k in ('status','new_runs','new_pngs','verified_pngs','prediction_decisions','exact_expected_exports_checked','simulation_calls')})

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--data-root',type=Path,default=HERE);parser.add_argument('--output-dir',type=Path,required=True)
    a=parser.parse_args();main(a.data_root.resolve(),a.output_dir.resolve())
