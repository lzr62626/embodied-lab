"""Only delayed same-run position and velocity predict current joint position."""
import numpy as np
from feedback_controller import feedback,finite_scalar
DT=np.float64(.05);TIME_ATOL=np.float64(1e-12)

def predict(q_latest,v_latest,measurement_time_s,current_time_s):
    q=finite_scalar(q_latest,'q_latest');v=finite_scalar(v_latest,'v_latest')
    measured=finite_scalar(measurement_time_s,'measurement_time_s');now=finite_scalar(current_time_s,'current_time_s')
    age=np.float64(now-measured)
    if abs(age-DT)>TIME_ATOL:raise ValueError('Measurement must be one actual control period old.')
    increment=finite_scalar(v*age,'predicted_increment')
    estimated=finite_scalar(q+increment,'q_pred_velocity')
    return {'q_latest':q,'v_latest':v,'measurement_time_s':measured,'current_time_s':now,
            'measurement_age_s':age,'predicted_increment':increment,'q_pred_velocity':estimated}

class VelocityStateCache:
    def __init__(self,run_id):self.run_id=run_id;self.values=[];self.velocities=[];self.times=[]
    def append(self,run_id,state_index,time_s,joint1,velocity1):
        if run_id!=self.run_id or type(state_index) is not int or state_index!=len(self.values):raise ValueError('Wrong cache owner or non-sequential index.')
        q=finite_scalar(joint1,'joint1');v=finite_scalar(velocity1,'velocity1');timestamp=finite_scalar(time_s,'state_time_s')
        if abs(timestamp-state_index*DT)>TIME_ATOL:raise ValueError('State clock is not continuous.')
        self.values.append(q);self.velocities.append(v);self.times.append(timestamp)
    def latest(self,run_id,t):
        if run_id!=self.run_id or type(t) is not int or t<1 or t>=len(self.values):raise ValueError('Invalid owner or insufficient delayed state.')
        return {'q_latest':np.float64(self.values[t-1]),'v_latest':np.float64(self.velocities[t-1]),
                'measurement_time_s':np.float64(self.times[t-1]),'measurement_state_index':np.int64(t-1)}
    def current_for_audit(self,run_id,t):
        if run_id!=self.run_id or type(t) is not int or not 0<=t<len(self.values):raise ValueError('Invalid diagnostic state.')
        return np.float64(self.values[t])

def decide(cache,run_id,t,q_ref,u_ff,reference_time_s):
    delayed=cache.latest(run_id,t);now=cache.times[t];reference_time=finite_scalar(reference_time_s,'reference_time_s')
    if abs(reference_time-now)>TIME_ATOL:raise ValueError('Current reference clock differs.')
    prediction=predict(delayed['q_latest'],delayed['v_latest'],delayed['measurement_time_s'],now)
    result=feedback(q_ref,prediction['q_pred_velocity'],u_ff)
    result.pop('q_actual');result.update(prediction)
    result.update(t=np.int64(t),measurement_state_index=delayed['measurement_state_index'],
        reference_state_index=np.int64(t),actual_state_index=np.int64(t),prediction_target_state_index=np.int64(t),
        delay_steps=np.int64(1),gain=np.float64(1),joint_delta_scale=np.float64(.1),reference_time_s=reference_time)
    # Complete command first. Current angle is appended only as diagnostic truth.
    result['q_current_diagnostic']=cache.current_for_audit(run_id,t)
    result['estimate_error_rad']=np.float64(result['q_pred_velocity']-result['q_current_diagnostic'])
    return result
