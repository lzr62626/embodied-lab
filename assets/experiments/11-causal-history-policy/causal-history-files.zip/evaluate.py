"""Recompute the published offline evaluation from saved numeric data on CPU."""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from torch import nn


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def read_npz(path):
    with np.load(path, allow_pickle=False) as archive:
        arrays = {name: archive[name].copy() for name in archive.files}
    require(all(a.dtype.kind in "biuf" and np.isfinite(a).all() for a in arrays.values()),
            "An array has an unsupported dtype or non-finite value.")
    return arrays


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


class Policy(nn.Module):
    def __init__(self, width):
        super().__init__()
        self.network = nn.Sequential(nn.Linear(width, 32), nn.ReLU(),
                                     nn.Linear(32, 32), nn.ReLU(), nn.Linear(32, 1))

    def forward(self, state):
        return 0.1 * torch.tanh(self.network(state))


def load_model(path, width):
    model = Policy(width).cpu()
    arrays = read_npz(path)
    expected = model.state_dict()
    require(set(arrays) == set(expected), "Unexpected parameter fields.")
    require(all(arrays[k].shape == tuple(expected[k].shape) and arrays[k].dtype == np.float32
                for k in arrays), "Unexpected parameter layout.")
    model.load_state_dict({key: torch.from_numpy(value) for key, value in arrays.items()})
    return model.eval()


def inputs(data, statistics, kind):
    n = len(data["actions"])
    state = np.concatenate([
        ((data["obs/agent/" + field][:n, 0].astype(np.float64) - statistics[field + "/mean"])
         / statistics[field + "/scale"]).astype(np.float32)
        for field in ("qpos", "qvel")
    ], axis=1)
    require(state.shape == (n, 18) and np.isfinite(state).all(), "Invalid current-state layout.")
    if kind == "single":
        return state
    t = np.arange(n)[:, None]
    index = np.repeat(t, 4, axis=1) if kind == "current" else np.maximum(t + np.arange(-3, 1), 0)
    require(kind in ("current", "history"), "Unexpected input mode.")
    return state[index].reshape(n, 72)


def predict(model, values):
    with torch.inference_mode():
        chunks = [model(torch.from_numpy(values[start:start + 8])).numpy()
                  for start in range(0, len(values), 8)]
    return np.concatenate(chunks).reshape(-1)


def metrics(target, prediction):
    error = prediction.astype(np.float64) - target.astype(np.float64)
    mse = float(np.mean(error ** 2))
    return {"samples": len(target), "mse": mse, "rmse": float(np.sqrt(mse)),
            "mae": float(np.mean(np.abs(error)))}


def check_rollout(root, group, reference):
    folder = root / "rollouts" / group
    data = read_npz(folder / "rollout.npz")
    n = len(data["actions"])
    require(1 <= n <= 20 and data["actions"].shape == (n, 8)
            and data["actions"].dtype == np.float32, "Invalid action layout.")
    for field in ("qpos", "qvel"):
        value = data["obs/agent/" + field]
        require(value.shape == (n + 1, 1, 9) and value.dtype == np.float32, "Invalid state layout.")
        require(np.max(np.abs(value[0].astype(np.float64) - reference["obs/agent/" + field][0])) <= 1e-5,
                "Initial state differs from the saved reference.")
    require(data["diagnostic/cube_pose"].shape == (n + 1, 1, 7)
            and np.max(np.abs(data["diagnostic/cube_pose"][0].astype(np.float64)
                              - reference["diagnostic/cube_pose"][0])) <= 1e-6, "Cube start differs.")
    require(np.array_equal(data["step_index"][:, 0], np.arange(n + 1))
            and np.array_equal(data["time_s"][:, 0], np.arange(n + 1) * 0.05)
            and np.array_equal(data["info/elapsed_steps"][:, 0], np.arange(1, n + 1)), "Invalid time axis.")
    for field in ("rewards", "terminated", "truncated", "info/success"):
        require(data[field].shape == (n, 1), "Invalid transition field.")
    done = (data["terminated"] | data["truncated"])[:, 0]
    require(not done[:-1].any() and (n == 20 or done[-1]), "Crossed or fabricated episode boundary.")
    require(data["terminated"].dtype == data["truncated"].dtype == np.bool_
            and data["info/success"].dtype == np.bool_, "Invalid flags.")
    action = data["actions"]
    require(np.all(np.abs(action) <= 1) and np.all(np.abs(action[:, 0]) <= np.float32(.1))
            and np.all(action[:, 1:7] == 0) and np.all(action[:, 7] == 1), "Invalid action bounds.")
    rgb = data["obs/sensor_data/base_camera/rgb"]
    require(rgb.shape == (n + 1, 1, 256, 256, 3) and rgb.dtype == np.uint8, "Invalid RGB layout.")
    frames = sorted((folder / "frames").glob("*.png"))
    require([p.name for p in frames] == [f"{t:04d}.png" for t in range(n + 1)], "Frame indices differ.")
    for t, path in enumerate(frames):
        with Image.open(path) as image:
            require(image.mode == "RGB" and np.array_equal(np.asarray(image), rgb[t, 0]), "PNG pixels differ.")
    return data


def main(output):
    root = Path(__file__).resolve().parent
    require(not output.exists(), "Choose a new output directory.")
    files = read_json(root / "package-manifest.json")["sha256"]
    require(all((root / name).resolve().is_relative_to(root) for name in files), "Unsafe package path.")
    require(all(sha(root / name) == digest for name, digest in files.items()), "Package integrity check failed.")
    config = read_json(root / "config.json")
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.manual_seed(2027)
    statistics = read_npz(root / "stats" / "train_stats.npz")
    require(all(statistics[field + "/mean"].shape == (9,) and
                statistics[field + "/scale"].shape == (9,) and np.all(statistics[field + "/scale"] > 0)
                for field in ("qpos", "qvel")), "Invalid frozen statistics.")
    sources = {seed: read_npz(root / "inputs" / f"seed-{seed:04d}.npz") for seed in (42, 43, 44)}
    train_mean = float(np.mean(np.concatenate([sources[s]["actions"][:, 0] for s in (42, 43)]),
                               dtype=np.float64))
    require(train_mean == config["baseline_train_mean"], "Training mean differs.")
    reference = read_npz(root / "reference" / "trajectory.npz")
    saved = read_npz(root / "offline" / "predictions.npz")
    require(np.array_equal(saved["target"].reshape(-1), sources[44]["actions"][:, 0]), "Offline labels differ.")
    models = {group: load_model(root / "weights" / (group + ".npz"), row["width"])
              for group, row in config["models"].items()}
    offline, offline_errors = {}, {}
    for group, model in models.items():
        prediction = predict(model, inputs(sources[44], statistics, config["models"][group]["kind"]))
        expected = saved[config["models"][group]["offline_field"]].reshape(-1)
        offline_errors[group] = float(np.abs(prediction.astype(np.float64) - expected).max())
        require(offline_errors[group] <= 1e-6, "Offline predictions differ after reloading.")
        offline[group] = metrics(saved["target"].reshape(-1), expected)
    groups = {group: check_rollout(root, group, reference) for group in config["groups"]}
    command_errors = {}
    for group, model in models.items():
        state = inputs(groups[group], statistics, config["models"][group]["kind"])
        path = root / "rollouts" / group / "policy-inputs.npz"
        if path.exists():
            require(np.array_equal(read_npz(path)["x"], state), "Saved policy inputs differ.")
        prediction = predict(model, state)
        error = np.abs(prediction.astype(np.float64) - groups[group]["actions"][:, 0])
        command_errors[group] = float(error.max())
        require(command_errors[group] <= 1e-6, "Closed-loop commands differ after reloading.")
    if "A-script" in groups:
        for name in ("actions", "obs/agent/qpos", "obs/agent/qvel", "diagnostic/cube_pose", "rewards",
                     "terminated", "truncated", "info/success"):
            require(np.array_equal(groups["A-script"][name], reference[name]), "Script replay differs.")
        require(np.all(groups["B-constant"]["actions"][:, 0] == train_mean), "Constant commands differ.")
    horizon = min(len(data["actions"]) for data in (reference, *groups.values()))
    summary = {}
    for group, data in groups.items():
        angle = data["obs/agent/qpos"][:, 0, 0].astype(np.float64)
        error = np.abs(angle[:horizon + 1] - reference["obs/agent/qpos"][:horizon + 1, 0, 0])
        changed = np.flatnonzero(error > 1e-6)
        xyz = data["diagnostic/cube_pose"][:, 0, :3].astype(np.float64)
        summary[group] = {"steps": len(data["actions"]), "joint1_net_rad": float(angle[-1] - angle[0]),
                          "max_reference_deviation_rad": float(error.max()),
                          "first_state_deviation": int(changed[0]) if changed.size else None,
                          "cube_net_m": float(np.linalg.norm(xyz[-1] - xyz[0])),
                          "reward_sum": float(np.sum(data["rewards"], dtype=np.float64)),
                          "success_steps": int(data["info/success"].sum())}
    expected = read_json(root / "expected-report.json")
    require(summary == expected["groups"] and offline == expected["offline"], "Recorded metrics differ.")
    output.mkdir(parents=True)
    report = {"result": "PASS", "device": "cpu", "common_control_steps": horizon, "groups": summary,
              "offline": offline, "offline_prediction_reload_max_abs": offline_errors,
              "closed_loop_command_reload_max_abs": command_errors,
              "pngs_verified": sum(len(data["actions"]) + 1 for data in groups.values()),
              "training_calls": 0, "simulation_calls": 0}
    (output / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path("result"))
    main(parser.parse_args().output_dir.resolve())
