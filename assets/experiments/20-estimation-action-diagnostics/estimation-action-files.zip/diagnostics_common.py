"""Pure saved-data IO. No collection, simulation, model, or fitting entry points."""
from pathlib import Path
import hashlib
import json
import numpy as np
from numeric_helpers import QPOS,QVEL,RGB,CUBE,SUCCESS,require,read_json,write_json,read_numeric,sha,no_simulator_import
from saved_checks import check_run
from saved_compensation import check_compensated

HERE = Path(__file__).resolve().parent

def fingerprint(data):
    digest = hashlib.sha256()
    for key in sorted(data):
        value = np.ascontiguousarray(data[key])
        digest.update(json.dumps([key,value.dtype.str,list(value.shape)],separators=(',',':')).encode())
        digest.update(value.tobytes(order='C'))
    return digest.hexdigest()

def load_sources(root):
    root = Path(root)
    config = read_json(root/'config.json')
    manifest = read_json(root/'source_manifest.json')
    require([(r['seed'],r['condition'],r['source_id']) for r in manifest['sources']] ==
            [(45,'U',0),(45,'CE',1),(45,'PE',2),(46,'U',3),(46,'CE',4),(46,'PE',5)], 'Stable six-source mapping differs.')
    loaded, checks = {}, {}
    for row in manifest['sources']:
        folder = (root/row['path']).resolve()
        require(sha(folder/'rollout.npz') == row['rollout_sha256'], 'Source NPZ SHA differs.')
        key = (row['seed'],row['condition'])
        reference = read_numeric(folder/'rollout.npz') if row['condition']=='U' else loaded[(row['seed'],'U')]['data']
        data,meta,audit,check = check_run(folder, {'U':'U','CE':'E','PE':'D'}[row['condition']],reference,config,check_feedback_audit=False)
        require(fingerprint(data)==row['numeric_content_fingerprint'], 'Source numeric fingerprint differs.')
        if audit is not None:
            check['compensation_errors'] = check_compensated(data,reference,audit,config)
        require(meta['seed']==row['seed'], 'Source seed metadata differs.')
        loaded[key] = dict(row=row,folder=folder,data=data,meta=meta,audit=audit)
        checks[f'{key[0]}-{key[1]}'] = check
    no_simulator_import()
    return config,manifest,loaded,checks

def save_npz(path, arrays):
    require(all(v.dtype.kind in 'buif' and np.isfinite(v).all() for v in arrays.values()), 'Only finite numeric arrays allowed.')
    with Path(path).open('xb') as stream:
        np.savez_compressed(stream,**arrays)

def rows_as_json(arrays,indices):
    return [{key:value[i].item() for key,value in arrays.items()} for i in indices]
