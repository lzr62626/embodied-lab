"""Independent read-only CPU acceptance using scalar reconstruction from original qpos."""
import argparse
import csv
import math
from pathlib import Path
import numpy as np
from diagnostics_common import HERE,QPOS,RGB,require,read_json,write_json,read_numeric,sha,load_sources,no_simulator_import

def scalar_record(data,reference,t,config):
    p=float(data[QPOS][t-2,0,0]);l=float(data[QPOS][t-1,0,0]);c=float(data[QPOS][t,0,0])
    r=float(reference[QPOS][t,0,0]);f=float(reference['actions'][t,0])
    require(all(math.isfinite(x) for x in (p,l,c,r,f)), 'Non-finite scalar input.')
    d0=l-p;d1=c-l;estimate=l+d0
    ee=estimate-c;he=l-c;er=r-estimate;cr=r-c
    ce=config['gain']*er/config['joint_delta_scale_rad'];cc=config['gain']*cr/config['joint_delta_scale_rad']
    re=f+ce;rc=f+cc;bound=config['clip_limit_float64_from_float32']
    le=max(-bound,min(bound,re));lc=max(-bound,min(bound,rc))
    se=np.float32(le);sc=np.float32(lc)
    rg=re-rc;cg=le-lc;sg=float(se)-float(sc)
    category=0 if re==rc else 1 if le==lc else 2 if se==sc else 3
    return dict(q_previous_rad=p,q_latest_rad=l,q_current_rad=c,q_ref_rad=r,delta_previous_rad=d0,delta_current_rad=d1,
        q_estimated_rad=estimate,estimate_error_rad=ee,hold_error_rad=he,error_est_rad=er,error_current_rad=cr,
        u_ff=f,correction_est=ce,correction_current=cc,raw_est=re,raw_current=rc,clipped_est=le,clipped_current=lc,
        sent_est=se,sent_current=sc,raw_gap=rg,clipped_gap=cg,sent_gap=sg,rounding_residual=sg-cg,
        est_strict_clipped=re < -bound or re > bound,current_strict_clipped=rc < -bound or rc > bound,
        est_sent_at_bound=abs(se)==np.float32(bound),current_sent_at_bound=abs(sc)==np.float32(bound),
        sent_numeric_equal=se==sc,sent_bits_equal=se.tobytes()==sc.tobytes(),category=category)

def scalar_stats(values):
    values=[float(x) for x in values]
    return {'samples':len(values),'max_abs':max(abs(x) for x in values),
            'rmse':math.sqrt(sum(x*x for x in values)/len(values)), 'mean_signed':sum(values)/len(values)}

def equal_tree(a,b,atol):
    if isinstance(a,dict): return isinstance(b,dict) and a.keys()==b.keys() and all(equal_tree(a[k],b[k],atol) for k in a)
    if isinstance(a,list): return isinstance(b,list) and len(a)==len(b) and all(equal_tree(x,y,atol) for x,y in zip(a,b))
    if isinstance(a,(float,np.floating)): return math.isfinite(float(b)) and abs(float(a)-float(b))<=atol
    return a==b

def independent_summary(a,indices):
    s={k:v[indices] for k,v in a.items()}
    out={'decisions':len(indices),'estimate_error_rad':scalar_stats(s['estimate_error_rad']),
         'hold_error_rad':scalar_stats(s['hold_error_rad']),
         'command_gaps':{k:scalar_stats(s[k]) for k in ('raw_gap','clipped_gap','sent_gap')},
         'rounding_residual_range':[float(min(s['rounding_residual'])),float(max(s['rounding_residual']))],
         'categories':{c:sum(int(v)==i for v in s['category']) for i,c in enumerate('ABCD')},
         'boundary_counts':{k:int(sum(bool(x) for x in s[k])) for k in ('est_strict_clipped','current_strict_clipped','est_sent_at_bound','current_sent_at_bound')},
         'sent_numeric_equal':int(sum(s['sent_numeric_equal'])),'sent_bits_equal':int(sum(s['sent_bits_equal']))}
    for branch in ('est','current'):
        out['boundary_counts'][branch+'_touch_without_clipping']=sum(bool(t) and not bool(c) for t,c in zip(s[branch+'_sent_at_bound'],s[branch+'_strict_clipped']))
    return out

def main(root,output):
    output.mkdir(parents=True,exist_ok=False)
    config,manifest,sources,source_checks=load_sources(root)
    if (root/'files.json').is_file():
        require(all(sha(root/name)==digest for name,digest in read_json(root/'files.json').items()),'Portable package SHA differs.')
    arrays=read_numeric(root/'diagnostic_records.npz')
    index=read_json(root/'sample_index.json')['samples'];metrics=read_json(root/'metrics.json');cases=read_json(root/'case_summary.json')
    motion=read_numeric(root/'historical_motion.npz')
    count=len(index);atol=config['numeric_audit_atol'];n=0
    require(all(v.shape==(count,) for v in arrays.values()), 'Record axis is not scalar decision axis D.')
    require(np.array_equal(arrays['sample_id'],np.arange(count)), 'Sample ID ordering differs.')
    for row in manifest['sources']:
        if row['condition']=='U': continue
        source=sources[(row['seed'],row['condition'])];data=source['data'];audit=source['audit'];reference=sources[(row['seed'],'U')]['data']
        group_indices=[]
        for j,t0 in enumerate(audit['t']):
            t=int(t0);wanted=scalar_record(data,reference,t,config)
            require(index[n]=={'sample_id':n,'source_id':row['source_id'],'article19_source_id':row['article19_source_id'],
               'trajectory_id':row['trajectory_id'],'seed':row['seed'],'condition':row['condition'],'t':t,'state_indices':[t-2,t-1,t,t+1]}, 'Sample/source index metadata differs.')
            expected_meta=dict(sample_id=n,source_id=row['source_id'],article19_source_id=row['article19_source_id'],seed=row['seed'],
                condition_id={'CE':0,'PE':1}[row['condition']],t=t,previous_state_index=t-2,latest_state_index=t-1,current_state_index=t,next_state_index=t+1)
            expected_meta.update(previous_time_s=float(data['time_s'][t-2,0]),latest_time_s=float(data['time_s'][t-1,0]),
                                 current_time_s=float(data['time_s'][t,0]),next_time_s=float(data['time_s'][t+1,0]))
            require(set(arrays)==set(wanted)|set(expected_meta), 'Record fields differ.')
            for key,value in {**wanted,**expected_meta}.items():
                actual=arrays[key][n]
                if key.startswith('sent_') and key in ('sent_est','sent_current'):
                    require(arrays[key].dtype==np.float32 and actual.tobytes()==np.float32(value).tobytes(),'Float32 send bits differ.')
                elif isinstance(value,(bool,np.bool_)):
                    require(arrays[key].dtype==np.bool_ and actual==value,'Boolean field differs.')
                elif isinstance(value,(int,np.integer)):
                    require(arrays[key].dtype==np.int64 and actual==value,'Integer field differs.')
                else:
                    require(arrays[key].dtype==np.float64 and abs(float(actual)-value)<=atol,'Float64 scalar differs: '+key)
            require(wanted['sent_est'].tobytes()==data['actions'][t,0].tobytes()==audit['u_sent'][j].tobytes(),'Actual action/audit bits differ.')
            require(abs(wanted['estimate_error_rad']-(wanted['delta_previous_rad']-wanted['delta_current_rad']))<=atol,'Extrapolation identity differs.')
            require(abs(wanted['hold_error_rad']+wanted['delta_current_rad'])<=atol,'Hold identity differs.')
            require(abs(wanted['raw_gap']+config['gain']*wanted['estimate_error_rad']/config['joint_delta_scale_rad'])<=atol,'Command-error identity differs.')
            require(abs(wanted['clipped_gap'])<=abs(wanted['raw_gap'])+atol,'Float64 clip projection expands difference.')
            group_indices.append(n);n+=1
        key=f"{row['seed']}-{row['condition']}"
        expected=independent_summary(arrays,group_indices)
        k=np.arange(9,min(len(data['actions']),len(reference['actions']))+1,dtype=np.int64)
        q=data[QPOS][k,0,0].astype(np.float64);qr=reference[QPOS][k,0,0].astype(np.float64)
        for suffix,value in [('state_index',k),('q_actual_rad',q),('q_reference_rad',qr),('deviation_rad',q-qr)]:
            require(np.array_equal(motion[key+'/'+suffix],value),'Historical motion is not saved actual data.')
        expected['historical_tracking_rad']={**scalar_stats(q-qr),'state_indices':k.tolist(),'end_signed':float(q[-1]-qr[-1]),'origin_article':19}
        require(equal_tree(expected,metrics['groups'][key],atol),'Group metric reductions differ.')
        maximum=max(abs(float(arrays['estimate_error_rad'][i])) for i in group_indices)
        peak=[i for i in group_indices if abs(float(arrays['estimate_error_rad'][i]))==maximum]
        focus=[i for i in group_indices if int(arrays['t'][i]) in (9,10,11,15,16,19)]
        for label,ids in [('maximum_abs_error_cases',peak),('focus_cases',focus)]:
            require(cases['groups'][key][label]==[{f:v[i].item() for f,v in arrays.items()} for i in ids],'Case selection/values differ.')
    require(n==count and sum(metrics['total']['categories'].values())==count,'Decision coverage differs.')
    require(equal_tree(independent_summary(arrays,list(range(n))),metrics['total'],atol),'Total metrics differ.')
    csv_fields=set();csv_count=0
    for name in ('error_decomposition.csv','command_decomposition.csv'):
        with (root/name).open(encoding='utf-8',newline='') as stream:
            reader=csv.DictReader(stream);rows=list(reader);fields=reader.fieldnames
        require(len(rows)==count,'CSV row count differs.');csv_fields.update(fields)
        for i,row in enumerate(rows):
            for key in fields:
                text=row[key];value=arrays[key][i].item()
                restored=(text=='True') if arrays[key].dtype.kind=='b' else int(text) if arrays[key].dtype.kind in 'iu' else float(text)
                require(restored==value,'Reopened CSV value differs.')
        csv_count+=1
    require(csv_fields==set(arrays),'CSV files do not cover every field.')
    tile_count=0
    if (root/'figure-validation.json').is_file():
        from PIL import Image
        figures=read_json(root/'figure-validation.json')
        with Image.open(root/'case_frames.png') as sheet:
            for tile in figures['tiles']:
                src=sources[(tile['seed'],tile['condition'])]['data'][RGB][tile['state_index'],0]
                require(np.array_equal(np.asarray(sheet.crop(tuple(tile['box']))),src),'Case montage modified raw pixels.')
                tile_count+=1
        for name,expected_sha in figures['figure_sha256'].items():
            require(sha(root/name)==expected_sha,'Figure SHA differs.')
            with Image.open(root/name) as image: image.verify()
    no_simulator_import()
    report={'status':'passed','historical_sources':len(sources),'diagnostic_records':count,
      'source_checks':source_checks,'verified_pngs':sum(x['verified_pngs'] for x in source_checks.values()),
      'CSV_exports_reopened_and_exact':csv_count,'case_tiles_pixel_exact':tile_count,
      'categories':metrics['total']['categories'],'scalar_reconstruction_independent_of_generator':True,
      'same_state_current_command_not_executed':True,'raw_identities_and_clip_nonexpansiveness':True,
      'actual_float32_action_bits_exact':True,'all_rows_indices_types_finite_and_metrics_checked':True,
      'new_runs':0,'simulation_calls':0,'reset_calls':0,'step_calls':0,'training_calls':0,'statistics_fits':0}
    write_json(output/'validation.json',report)
    print({k:report[k] for k in ('status','diagnostic_records','verified_pngs','categories','new_runs','simulation_calls')})
    return report

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-root',type=Path,default=HERE)
    parser.add_argument('--output-dir',type=Path,required=True,help='New report directory, no source writes.')
    args=parser.parse_args();main(args.data_root.resolve(),args.output_dir.resolve())
