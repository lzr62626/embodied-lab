"""Generate offline decomposition from real historical decisions; never execute actions."""
import argparse
import csv
from pathlib import Path
import numpy as np
from diagnostics_common import HERE,QPOS,require,load_sources,write_json,save_npz,rows_as_json,no_simulator_import

def decompose(previous,latest,current,q_ref,u_ff,config):
    values = np.asarray([previous,latest,current,q_ref,u_ff],dtype=np.float64)
    require(np.isfinite(values).all(), 'Non-finite diagnostic input.')
    previous,latest,current,q_ref,u_ff = values
    delta_previous = latest-previous
    delta_current = current-latest
    estimated = latest+delta_previous
    estimate_error = estimated-current
    hold_error = latest-current
    gain,scale,limit = (config[k] for k in ('gain','joint_delta_scale_rad','clip_limit_float64_from_float32'))
    error_est,error_current = q_ref-estimated,q_ref-current
    correction_est,correction_current = gain*error_est/scale,gain*error_current/scale
    raw_est,raw_current = u_ff+correction_est,u_ff+correction_current
    clipped_est,clipped_current = np.clip(raw_est,-limit,limit),np.clip(raw_current,-limit,limit)
    sent_est,sent_current = np.float32(clipped_est),np.float32(clipped_current)
    raw_gap,clipped_gap = raw_est-raw_current,clipped_est-clipped_current
    sent_gap = np.float64(sent_est)-np.float64(sent_current)
    category = 0 if raw_est==raw_current else 1 if clipped_est==clipped_current else 2 if sent_est==sent_current else 3
    return dict(q_previous_rad=previous,q_latest_rad=latest,q_current_rad=current,q_ref_rad=q_ref,
        delta_previous_rad=delta_previous,delta_current_rad=delta_current,q_estimated_rad=estimated,
        estimate_error_rad=estimate_error,hold_error_rad=hold_error,error_est_rad=error_est,error_current_rad=error_current,
        u_ff=u_ff,correction_est=correction_est,correction_current=correction_current,raw_est=raw_est,raw_current=raw_current,
        clipped_est=clipped_est,clipped_current=clipped_current,sent_est=sent_est,sent_current=sent_current,
        raw_gap=raw_gap,clipped_gap=clipped_gap,sent_gap=sent_gap,rounding_residual=sent_gap-clipped_gap,
        est_strict_clipped=np.bool_(raw_est < -limit or raw_est > limit),
        current_strict_clipped=np.bool_(raw_current < -limit or raw_current > limit),
        est_sent_at_bound=np.bool_(abs(sent_est)==np.float32(limit)),
        current_sent_at_bound=np.bool_(abs(sent_current)==np.float32(limit)),
        sent_numeric_equal=np.bool_(sent_est==sent_current),
        sent_bits_equal=np.bool_(sent_est.view(np.uint32)==sent_current.view(np.uint32)),category=np.int64(category))

def stats(a):
    a = np.asarray(a,dtype=np.float64)
    return {'samples':len(a),'max_abs':float(np.abs(a).max()),'rmse':float(np.sqrt(np.mean(a*a,dtype=np.float64))),
            'mean_signed':float(np.mean(a,dtype=np.float64))}

def summarize(arrays,mask):
    a = {key:value[mask] for key,value in arrays.items()}
    out = {'decisions':int(np.count_nonzero(mask)),
           'estimate_error_rad':stats(a['estimate_error_rad']), 'hold_error_rad':stats(a['hold_error_rad']),
           'command_gaps':{key:stats(a[key]) for key in ('raw_gap','clipped_gap','sent_gap')},
           'rounding_residual_range':[float(a['rounding_residual'].min()),float(a['rounding_residual'].max())],
           'categories':{c:int(np.count_nonzero(a['category']==i)) for i,c in enumerate('ABCD')},
           'boundary_counts':{key:int(np.count_nonzero(a[key])) for key in ('est_strict_clipped','current_strict_clipped','est_sent_at_bound','current_sent_at_bound')},
           'sent_numeric_equal':int(np.count_nonzero(a['sent_numeric_equal'])), 'sent_bits_equal':int(np.count_nonzero(a['sent_bits_equal']))}
    out['boundary_counts']['est_touch_without_clipping'] = int(np.count_nonzero(a['est_sent_at_bound'] & ~a['est_strict_clipped']))
    out['boundary_counts']['current_touch_without_clipping'] = int(np.count_nonzero(a['current_sent_at_bound'] & ~a['current_strict_clipped']))
    return out

def write_csv(path,arrays,fields):
    with path.open('x',encoding='utf-8',newline='') as stream:
        writer=csv.writer(stream);writer.writerow(fields)
        for i in range(len(arrays['sample_id'])): writer.writerow([arrays[key][i].item() for key in fields])

def main(root,output):
    output.mkdir(parents=True,exist_ok=False)
    config,manifest,sources,checks=load_sources(root)
    records,index=[],[]
    for row in manifest['sources']:
        if row['condition']=='U': continue
        source=sources[(row['seed'],row['condition'])]
        data,audit=source['data'],source['audit']
        reference=sources[(row['seed'],'U')]['data']
        for t0 in audit['t']:
            t=int(t0);j=len(records)
            result=decompose(*[float(data[QPOS][k,0,0]) for k in (t-2,t-1,t)],
                             float(reference[QPOS][t,0,0]),float(reference['actions'][t,0]),config)
            result.update(sample_id=np.int64(j),source_id=np.int64(row['source_id']),article19_source_id=np.int64(row['article19_source_id']),
                          seed=np.int64(row['seed']),condition_id=np.int64({'CE':0,'PE':1}[row['condition']]),t=np.int64(t),
                          previous_state_index=np.int64(t-2),latest_state_index=np.int64(t-1),current_state_index=np.int64(t),next_state_index=np.int64(t+1),
                          previous_time_s=np.float64(data['time_s'][t-2,0]),latest_time_s=np.float64(data['time_s'][t-1,0]),current_time_s=np.float64(data['time_s'][t,0]),next_time_s=np.float64(data['time_s'][t+1,0]))
            require(result['sent_est'].view(np.uint32)==data['actions'][t,0].view(np.uint32),'Actual float32 command differs.')
            records.append(result)
            index.append({'sample_id':j,'source_id':row['source_id'],'article19_source_id':row['article19_source_id'],
                          'trajectory_id':row['trajectory_id'],'seed':row['seed'],'condition':row['condition'],'t':t,
                          'state_indices':[t-2,t-1,t,t+1]})
    arrays={key:np.asarray([r[key] for r in records]) for key in records[0]}
    save_npz(output/'diagnostic_records.npz',arrays)
    write_json(output/'sample_index.json',{'version':config['version'],'samples':index,'condition_ids':{'0':'CE','1':'PE'},'category_ids':config['category_labels']})
    groups={};cases={};motion={}
    for seed in (45,46):
        reference=sources[(seed,'U')]['data']
        for condition in ('CE','PE'):
            mask=(arrays['seed']==seed)&(arrays['condition_id']=={'CE':0,'PE':1}[condition])
            key=f'{seed}-{condition}'
            groups[key]=summarize(arrays,mask)
            maximum=np.max(np.abs(arrays['estimate_error_rad'][mask]))
            peak=np.flatnonzero(mask & (np.abs(arrays['estimate_error_rad'])==maximum))
            selected=np.flatnonzero(mask & np.isin(arrays['t'],[9,10,11,15,16,19]))
            cases[key]={'maximum_abs_error_cases':rows_as_json(arrays,peak),'focus_cases':rows_as_json(arrays,selected)}
            data=sources[(seed,condition)]['data']
            n=min(len(data['actions']),len(reference['actions']))
            k=np.arange(9,n+1,dtype=np.int64)
            q=data[QPOS][k,0,0].astype(np.float64); qr=reference[QPOS][k,0,0].astype(np.float64)
            motion[f'{key}/state_index']=k;motion[f'{key}/q_actual_rad']=q
            motion[f'{key}/q_reference_rad']=qr;motion[f'{key}/deviation_rad']=q-qr
            groups[key]['historical_tracking_rad']={**stats(q-qr),'state_indices':k.tolist(),
                  'end_signed':float(q[-1]-qr[-1]),'origin_article':19}
    write_json(output/'case_summary.json',{'groups':cases,'selection':'All exact ties at maximum abs estimation error; plus prespecified t=9,10,11,15,16,19.'})
    write_json(output/'metrics.json',{'version':config['version'],'new_runs':0,'simulation_calls':0,'historical_sources':len(sources),
        'groups':groups,'total':summarize(arrays,np.ones(len(records),dtype=np.bool_)),
        'interpretation':'Same-state current-angle commands are offline diagnostics only, never executed trajectories or correct labels. Historical motion comes from article19.'})
    save_npz(output/'historical_motion.npz',motion)
    meta=['sample_id','source_id','article19_source_id','seed','condition_id','t','previous_state_index','latest_state_index','current_state_index','next_state_index','previous_time_s','latest_time_s','current_time_s','next_time_s']
    error_fields=[k for k in arrays if k.endswith('_rad')]
    command_fields=[k for k in arrays if k not in meta+error_fields]
    write_csv(output/'error_decomposition.csv',arrays,meta+error_fields)
    write_csv(output/'command_decomposition.csv',arrays,meta+command_fields)
    no_simulator_import()
    print({'records':len(records),'categories':summarize(arrays,np.ones(len(records),bool))['categories'],'new_simulation_calls':0})

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-root',type=Path,default=HERE)
    parser.add_argument('--output-dir',type=Path,required=True,help='New directory only; source files are read-only.')
    args=parser.parse_args();main(args.data_root.resolve(),args.output_dir.resolve())
