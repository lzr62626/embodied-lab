"""Run the fixed CPU training protocol into a new directory."""
import argparse
import csv
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset

from bc_common import CONFIG, Policy, configure_cpu, load_split, save_weights, write_json


def train(input_dir, output_dir):
    configure_cpu()
    x, y, trajectory, t, _ = load_split(input_dir, 'train')
    if x.shape != (40, 18) or y.shape != (40, 1):
        raise ValueError('Unexpected training sample count or feature dimensions.')
    output_dir.mkdir(parents=True, exist_ok=False)
    write_json(output_dir / 'config.json', CONFIG)
    generator = torch.Generator(device='cpu').manual_seed(CONFIG['seed'])
    loader = DataLoader(TensorDataset(x, y, torch.arange(len(y))), batch_size=CONFIG['batch_size'],
                        shuffle=True, drop_last=False, num_workers=0, generator=generator)
    model = Policy().cpu()
    initial = {name: value.detach().clone() for name, value in model.named_parameters()}
    optimizer = torch.optim.Adam(model.parameters(), lr=CONFIG['learning_rate'])
    criterion = torch.nn.MSELoss()
    updates = 0
    first_batch = None
    with (output_dir / 'training_curve.csv').open('x', newline='', encoding='utf-8') as handle:
        curve = csv.writer(handle)
        curve.writerow(['epoch', 'updates', 'samples', 'train_mse'])
        for epoch in range(1, CONFIG['epochs'] + 1):
            model.train()
            epoch_squared_error = 0.0
            seen = []
            for features, target, indices in loader:
                if updates >= CONFIG['maximum_optimizer_updates']:
                    raise RuntimeError('Optimizer update budget exceeded.')
                optimizer.zero_grad(set_to_none=True)
                prediction = model(features)
                if prediction.shape != target.shape or not torch.isfinite(prediction).all():
                    raise ValueError('Unexpected prediction shape or nonfinite values.')
                loss = criterion(prediction, target)
                loss.backward()
                if any(p.grad is None or not torch.isfinite(p.grad).all() for p in model.parameters()):
                    raise ValueError('Missing or nonfinite gradient.')
                optimizer.step()
                updates += 1
                epoch_squared_error += loss.item() * len(target)
                batch_indices = indices.tolist()
                seen.extend(batch_indices)
                last_batch = {
                    'epoch': epoch, 'update': updates,
                    'input_shape': list(features.shape), 'target_shape': list(target.shape),
                    'samples': [{'trajectory_id': trajectory[i], 't': int(t[i]),
                                 'target': y[i, 0].item()} for i in batch_indices],
                }
                if first_batch is None:
                    first_batch = last_batch
            if sorted(seen) != list(range(len(y))):
                raise ValueError('A training epoch duplicated or skipped a transition.')
            mse = epoch_squared_error / len(seen)
            curve.writerow([epoch, updates, len(seen), mse])
            handle.flush()
            if epoch in (1, 10, 25, 50, 75, CONFIG['epochs']):
                print(f'epoch {epoch:3d} | updates {updates:3d} | train MSE {mse:.9g}', flush=True)
    if updates != CONFIG['maximum_optimizer_updates']:
        raise RuntimeError('Optimizer update count differs from protocol.')
    if not all(torch.isfinite(p).all() for p in model.parameters()):
        raise ValueError('Nonfinite final parameters.')
    deltas = {name: float(torch.linalg.vector_norm((p.detach() - initial[name]).double()))
              for name, p in model.named_parameters()}
    if not any(deltas.values()):
        raise ValueError('Training did not update any parameter.')
    save_weights(model, output_dir / 'model_weights.npz')
    model.eval()
    with torch.inference_mode():
        final_train_prediction = model(x).numpy()
    np.savez_compressed(output_dir / 'training_reference.npz', prediction=final_train_prediction)
    write_json(output_dir / 'training_summary.json', {
        'optimizer_updates': updates, 'train_samples': len(y), 'epochs': CONFIG['epochs'],
        'parameter_delta_l2': deltas, 'first_batch': first_batch, 'last_batch': last_batch,
        'training_reference': 'Training split predictions immediately before independent reload',
    })


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir', type=Path, default=Path('input'))
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    train(args.input_dir, args.output_dir)
