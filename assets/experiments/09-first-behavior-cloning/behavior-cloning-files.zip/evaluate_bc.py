"""Reload saved numeric weights and reproduce the offline comparison."""
import argparse
import csv
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset

from bc_common import CONFIG, SWITCHES, configure_cpu, load_split, load_weights, write_json
from normalization import read_json
from source_utils import read_numeric


def metrics(target, prediction):
    error = prediction.astype(np.float64) - target.astype(np.float64)
    mse = float(np.mean(error ** 2))
    return {'samples': len(target), 'mse': mse, 'rmse': float(np.sqrt(mse)),
            'mae': float(np.mean(np.abs(error)))}


def evaluate(input_dir, run_dir, output_dir):
    configure_cpu()
    if read_json(run_dir / 'config.json') != CONFIG:
        raise ValueError('Run configuration differs from the fixed experiment.')
    model = load_weights(run_dir / 'model_weights.npz')
    model.eval()
    train_x, train_y, *_ = load_split(input_dir, 'train')
    reference = read_numeric(run_dir / 'training_reference.npz')['prediction']
    with torch.inference_mode():
        reloaded = model(train_x).numpy()
    if reloaded.shape != reference.shape or not np.allclose(reloaded, reference, rtol=1e-6, atol=1e-8):
        raise ValueError('Reloaded training predictions differ from the saved reference.')
    mean = float(np.mean(train_y.numpy(), dtype=np.float64))
    x, y, trajectories, t, actions = load_split(input_dir, 'validation')
    loader = DataLoader(TensorDataset(x, y), batch_size=CONFIG['batch_size'],
                        shuffle=False, drop_last=False, num_workers=0)
    chunks, sizes = [], []
    with torch.inference_mode():
        for features, target in loader:
            prediction = model(features)
            if prediction.shape != target.shape or not torch.isfinite(prediction).all():
                raise ValueError('Invalid evaluation predictions.')
            chunks.append(prediction.numpy())
            sizes.append(len(target))
    prediction = np.concatenate(chunks).reshape(-1)
    target = y.numpy().reshape(-1)
    baseline = np.full_like(target, mean)
    switches = np.isin(t, SWITCHES)
    output_dir.mkdir(parents=True, exist_ok=False)
    np.savez_compressed(output_dir / 'predictions.npz', t=t, source_seed=np.full_like(t, 44),
                        target=target, mlp=prediction, baseline=baseline, is_switch=switches,
                        original_action=actions)
    with (output_dir / 'predictions.csv').open('x', newline='', encoding='utf-8') as handle:
        rows = csv.writer(handle)
        rows.writerow(['trajectory_id', 't', 'target', 'mlp', 'baseline', 'is_switch', 'mlp_abs_error', 'baseline_abs_error'])
        for i, step in enumerate(t):
            rows.writerow([trajectories[i], step, float(target[i]), float(prediction[i]),
                           float(baseline[i]), int(switches[i]), abs(float(prediction[i])-float(target[i])),
                           abs(float(baseline[i])-float(target[i]))])
    write_json(output_dir / 'metrics.json', {
        'baseline_train_mean': mean, 'train_samples_for_mean': len(train_y),
        'validation_trajectory': trajectories[0], 'validation_batch_sizes': sizes,
        'reload_max_abs_difference': float(np.max(np.abs(reloaded-reference))),
        'validation': {'mean_baseline': metrics(target, baseline), 'mlp': metrics(target, prediction)},
        'switch_steps': {'t': t[switches].tolist(), 'mean_baseline': metrics(target[switches], baseline[switches]),
                         'mlp': metrics(target[switches], prediction[switches])},
    })


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir', type=Path, default=Path('input'))
    parser.add_argument('--run-dir', type=Path, default=Path('run'))
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    evaluate(args.input_dir, args.run_dir, args.output_dir)
