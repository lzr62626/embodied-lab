"""Shared CPU model and same-time transition reader for article 9."""
import json
from pathlib import Path

import numpy as np
import torch
from torch import nn

from normalization import FrozenNormalizer, context
from source_utils import MODEL_KEYS, file_sha256, numeric_fingerprint, read_numeric, source_path


CONFIG = {
    'seed': 2027, 'epochs': 100, 'batch_size': 8, 'learning_rate': 0.001,
    'optimizer': 'Adam', 'loss': 'MSELoss', 'cpu_threads': 1, 'shuffle_train': True,
    'architecture': [18, 32, 32, 1], 'hidden_activation': 'ReLU',
    'output': '0.1 * tanh(logit)', 'action_index': 0, 'environment_index': 0,
    'feature_order': ['qpos', 'qvel'], 'maximum_optimizer_updates': 500,
}
SPLITS = {'train': ['seed-0042', 'seed-0043'], 'validation': ['seed-0044']}
SWITCHES = [5, 10, 15]
ACTION_AMPLITUDE = 0.1


def write_json(path, value):
    with Path(path).open('x', encoding='utf-8') as handle:
        json.dump(value, handle, indent=2, ensure_ascii=False, allow_nan=False)
        handle.write('\n')


def configure_cpu():
    torch.set_num_threads(CONFIG['cpu_threads'])
    torch.use_deterministic_algorithms(True)
    torch.manual_seed(CONFIG['seed'])


class Policy(nn.Module):
    def __init__(self):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(18, 32), nn.ReLU(), nn.Linear(32, 32), nn.ReLU(), nn.Linear(32, 1)
        )

    def forward(self, state):
        return ACTION_AMPLITUDE * torch.tanh(self.network(state))


def load_split(input_dir, split):
    root = Path(input_dir)
    manifest, splits = context(root)
    if splits != SPLITS:
        raise ValueError('Unexpected trajectory split.')
    normalizer = FrozenNormalizer.load(root / 'normalization')
    normalizer.verify_context(manifest, splits)
    records = {row['trajectory_id']: row for row in manifest['trajectories']}
    states, actions, times, labels = [], [], [], []
    expected_action = np.repeat(np.array([0.1, -0.1, 0.1, -0.1], dtype=np.float32), 5)
    for label in splits[split]:
        row = records[label]
        path = source_path(root / 'trajectories', row['file'])
        if file_sha256(path) != row['file_sha256']:
            raise ValueError('Trajectory file hash changed for ' + label)
        arrays = read_numeric(path)
        if (numeric_fingerprint(arrays) != row['numeric_content_fingerprint'] or
                numeric_fingerprint(arrays, MODEL_KEYS) != row['model_content_fingerprint']):
            raise ValueError('Trajectory content hash changed for ' + label)
        action = arrays['actions']
        if (action.shape != (20, 8) or action.dtype != np.float32 or row['N'] != 20 or
                not np.array_equal(action[:, 0], expected_action) or
                not np.all(action[:, 1:7] == 0) or not np.all(action[:, 7] == 1)):
            raise ValueError('Unexpected demonstration actions for ' + label)
        features = []
        for field in CONFIG['feature_order']:
            state = arrays['obs/agent/' + field]
            if state.shape != (21, 1, 9) or state.dtype != np.float32:
                raise ValueError('Unexpected state layout for ' + label + '/' + field)
            features.append(normalizer.transform(field, state[:len(action), 0, :]))
        states.append(torch.cat(features, dim=1))
        actions.append(action)
        times.extend(range(len(action)))
        labels.extend([label] * len(action))
    action = np.concatenate(actions)
    return torch.cat(states), torch.from_numpy(action[:, :1].copy()), labels, np.array(times), action


def save_weights(model, path):
    np.savez_compressed(path, **{name: value.detach().cpu().numpy()
                                for name, value in model.state_dict().items()})


def load_weights(path):
    model = Policy().cpu()
    expected = model.state_dict()
    saved = read_numeric(path)
    if set(saved) != set(expected):
        raise ValueError('Unexpected weight names.')
    for name, value in saved.items():
        if value.shape != tuple(expected[name].shape) or value.dtype != np.float32 or not np.isfinite(value).all():
            raise ValueError('Invalid weight array ' + name)
    model.load_state_dict({name: torch.from_numpy(value) for name, value in saved.items()}, strict=True)
    return model
