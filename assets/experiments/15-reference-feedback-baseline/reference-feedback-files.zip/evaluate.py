"""Recompute a curated article12--15 package on CPU, using saved files only."""

import argparse
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch
from torch import nn

ROOT = Path(__file__).resolve().parent
QPOS, QVEL, RGB = "obs/agent/qpos", "obs/agent/qvel", "obs/sensor_data/base_camera/rgb"
CUBE, SUCCESS = "diagnostic/cube_pose", "info/success"


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def numeric(path):
    with np.load(path, allow_pickle=False) as data:
        values = {k: data[k].copy() for k in data.files}
    require(all(v.dtype.kind in "biuf" and np.isfinite(v).all() for v in values.values()), "Invalid numeric array.")
    return values


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def equal(actual, expected, atol=1e-12):
    require(actual.shape == expected.shape and actual.dtype == expected.dtype, "Array layout differs.")
    if actual.dtype.kind in "biu":
        require(np.array_equal(actual, expected), "Integer/flag values differ.")
    else:
        require(np.allclose(actual, expected, atol=atol, rtol=0), "Floating values differ.")


def check_report(actual, expected):
    for key, value in expected.items():
        require(key in actual, "Missing expected report field: " + key)
        if isinstance(value, dict):
            check_report(actual[key], value)
        elif isinstance(value, list) or isinstance(value, (str, bool)) or value is None:
            require(actual[key] == value, "Report field differs: " + key)
        elif isinstance(value, int):
            require(actual[key] == value, "Count differs: " + key)
        else:
            require(abs(actual[key] - value) <= 1e-9, "Numeric report differs: " + key)


class Policy(nn.Module):
    def __init__(self):
        super().__init__()
        self.network = nn.Sequential(nn.Linear(72, 32), nn.ReLU(), nn.Linear(32, 32), nn.ReLU(), nn.Linear(32, 1))

    def forward(self, x):
        return .1 * torch.tanh(self.network(x))


def model(name):
    net = Policy().cpu()
    values = numeric(ROOT / "weights" / (name + ".npz"))
    expected = net.state_dict()
    require(set(values) == set(expected), "Unexpected model parameters.")
    require(all(values[k].shape == tuple(expected[k].shape) and values[k].dtype == np.float32 for k in values),
            "Unexpected parameter shape/type.")
    net.load_state_dict({k: torch.from_numpy(v) for k, v in values.items()})
    return net.eval()


def predict(net, x):
    with torch.inference_mode():
        return np.concatenate([net(torch.from_numpy(x[i:i + 8])).numpy() for i in range(0, len(x), 8)])[:, 0]


def features(data, stats):
    n = len(data["actions"])
    current = np.concatenate([((data[key][:n, 0].astype(np.float64) - stats[field + "/mean"])
                               / stats[field + "/scale"]).astype(np.float32)
                              for key, field in ((QPOS, "qpos"), (QVEL, "qvel"))], axis=1)
    require(current.shape == (n, 18), "Current-state layout differs.")
    indices = np.maximum(np.arange(n)[:, None] + np.arange(-3, 1), 0)
    return current, current[indices].reshape(n, 72), indices


def distance(query, candidates):
    delta = query.astype(np.float64)[:, None] - candidates.astype(np.float64)[None]
    return np.sqrt(np.mean(delta ** 2, axis=2, dtype=np.float64))


def nearest(d, source, t, candidates=None):
    ids = np.arange(len(d)) if candidates is None else candidates
    return int(ids[np.lexsort((t[ids], source[ids], d[ids]))[0]])


def loss(y, prediction):
    error = prediction.astype(np.float64) - y.astype(np.float64)
    return {"samples": len(y), "mse": float(np.mean(error ** 2)), "mae": float(np.mean(np.abs(error))),
            "sign_agreement": int(np.sum(np.sign(y) == np.sign(prediction)))}


def train_data(stats):
    raw = {s: numeric(ROOT / "inputs" / f"seed-{s:04d}.npz") for s in (42, 43, 44)}
    train_c, train_h, labels = [], [], []
    for seed in (42, 43):
        c, h, _ = features(raw[seed], stats)
        train_c.append(c)
        train_h.append(h)
        labels.append(raw[seed]["actions"][:, 0])
    return raw, np.concatenate(train_c), np.concatenate(train_h), np.concatenate(labels), np.repeat([0, 1], 20), np.tile(np.arange(20), 2)


def diagnostics(stats, output):
    raw, c, h, labels, source, t = train_data(stats)
    vc, vh, _ = features(raw[44], stats)
    saved = numeric(ROOT / "results/samples.npz")
    for split, values in (("train", (c, h, labels)), ("validation", (vc, vh, raw[44]["actions"][:, 0]))):
        for key, value in zip(("C", "H", "target"), values):
            equal(value, saved[split + "_" + key], 0)
    require(np.array_equal(saved["train_source_id"], source) and np.array_equal(saved["train_t"], t)
            and np.array_equal(saved["validation_source_id"], np.full(20, 2)), "Source mapping differs.")
    train_expected = numeric(ROOT / "results/train_neighbors.npz")
    val_expected = numeric(ROOT / "results/validation_neighbors.npz")
    pairs_expected = numeric(ROOT / "results/opposite_pairs.npz")
    duplicate_expected = read_json(ROOT / "results/duplicate_groups.json")
    report, rebuilt = {"sample_counts": {"train": 40, "validation": 20}, "exact_duplicates": {}, "validation_metrics": {}}, {}
    for representation, train, query in (("C", c, vc), ("H", h, vh)):
        canonical = train.copy()
        canonical[canonical == 0] = 0
        _, inverse = np.unique(canonical, axis=0, return_inverse=True)
        groups, conflicts, same, sse = [], 0, 0, 0.
        for i in range(int(inverse.max()) + 1):
            ids = np.flatnonzero(inverse == i)
            if len(ids) <= 1:
                continue
            ids = ids[np.lexsort((t[ids], source[ids]))]
            y = labels[ids].astype(np.float64)
            different = np.unique(y).size > 1
            conflicts += int(different)
            same += int(not different)
            local_sse = float(np.sum((y - y.mean()) ** 2))
            sse += local_sse
            groups.append({"rows": ids.tolist(), "labels": y.tolist(), "label_mean": float(y.mean()),
                           "conflict": bool(different), "within_group_sse": local_sse})
        groups.sort(key=lambda row: (int(source[row["rows"][0]]), int(t[row["rows"][0]])))
        duplicate = {"unique_inputs": int(np.unique(inverse).size), "duplicate_groups": len(groups),
                     "same_label_duplicate_groups": same, "conflicting_duplicate_groups": conflicts,
                     "empirical_mse_lower_bound": sse / len(train), "groups": groups}
        require(duplicate == duplicate_expected[representation], "Exact duplicate report differs.")
        report["exact_duplicates"][representation] = duplicate
        d = distance(train, train)
        selected = []
        for i in range(40):
            other = np.flatnonzero(np.arange(40) != i)
            selected.append([nearest(d[i], source, t, ids) for ids in
                             (other, other[labels[other] == labels[i]], other[labels[other] == -labels[i]])])
        selected = np.array(selected, np.int64)
        result = {representation + "_distances": d, representation + "_neighbor_rows": selected,
                  representation + "_neighbor_distances": np.take_along_axis(d, selected, axis=1)}
        for key, value in result.items():
            equal(value, train_expected[key])
            rebuilt[key] = value
        left, right = np.triu_indices(40, k=1)
        mask = labels[left] == -labels[right]
        left, right = left[mask], right[mask]
        order = np.lexsort((t[right], source[right], t[left], source[left], d[left, right]))[:10]
        pairs = np.stack((left[order], right[order]), axis=1)
        equal(pairs, pairs_expected[representation + "_rows"])
        equal(d[pairs[:, 0], pairs[:, 1]], pairs_expected[representation + "_distance"])
        equal((train[pairs[:, 0]].astype(np.float64) - train[pairs[:, 1]].astype(np.float64)) ** 2,
              pairs_expected[representation + "_normalized_squared_delta"])
        for field in ("qpos", "qvel"):
            deltas = []
            for a, b in pairs:
                ia = np.array([t[a]]) if representation == "C" else np.maximum(np.arange(t[a] - 3, t[a] + 1), 0)
                ib = np.array([t[b]]) if representation == "C" else np.maximum(np.arange(t[b] - 3, t[b] + 1), 0)
                deltas.append(raw[42 + int(source[a])]["obs/agent/" + field][ia, 0].astype(np.float64)
                              - raw[42 + int(source[b])]["obs/agent/" + field][ib, 0].astype(np.float64))
            equal(np.stack(deltas), pairs_expected[representation + "_" + field + "_delta"])
        vd = distance(query, train)
        rows = np.array([nearest(v, source, t) for v in vd], dtype=np.int64)
        for suffix, value in (("distances", vd), ("neighbor_row", rows),
                              ("nearest_distance", vd[np.arange(20), rows]), ("prediction", labels[rows])):
            equal(value, val_expected[representation + "_" + suffix])
        report["validation_metrics"][representation + "_1NN"] = loss(raw[44]["actions"][:, 0], labels[rows])
    for name, x in (("S", np.tile(vc, (1, 4))), ("H", vh)):
        prediction = predict(model(name), x)
        equal(prediction, saved["validation_prediction_" + name], 1e-6)
        report["validation_metrics"][name + "_MLP"] = loss(raw[44]["actions"][:, 0], prediction)
    with (output / "recomputed-neighbors.npz").open("xb") as stream:
        np.savez_compressed(stream, **rebuilt)
    return {**report, "pngs_verified": 0}


def check_rollout(folder, audit_kind):
    data = numeric(folder / "rollout.npz")
    n = len(data["actions"])
    require(0 < n <= 20 and data["actions"].shape == (n, 8) and data["actions"].dtype == np.float32,
            "Invalid action time axis or dtype.")
    require(data[QPOS].shape == data[QVEL].shape == (n + 1, 1, 9)
            and data[RGB].shape == (n + 1, 1, 256, 256, 3) and data[RGB].dtype == np.uint8,
            "State/RGB N+1 axes differ.")
    require(np.array_equal(data["step_index"][:, 0], np.arange(n + 1))
            and np.array_equal(data["time_s"][:, 0], np.arange(n + 1) * .05)
            and np.array_equal(data["info/elapsed_steps"][:, 0], np.arange(1, n + 1)), "State time discontinuity.")
    done = (data["terminated"] | data["truncated"])[:, 0]
    require(not done[:-1].any() and (n == 20 or done[-1]), "Episode/budget boundary mismatch.")
    a = data["actions"]
    require(np.all(np.abs(a[:, 0]) <= np.float32(.1)) and np.all(a[:, 1:7] == 0)
            and np.all(a[:, 7] == 1), "Action bounds differ.")
    files = sorted((folder / "frames").glob("*.png"))
    require([p.name for p in files] == [f"{i:04d}.png" for i in range(n + 1)], "Raw PNG sequence differs.")
    for i, p in enumerate(files):
        with Image.open(p) as image:
            require(image.mode == "RGB" and np.array_equal(np.asarray(image), data[RGB][i, 0]), "PNG/RGB pixel mismatch.")
    return data, n + 1


def compare_states(actual, reference, index):
    for key, atol in ((QPOS, 1e-6), (QVEL, 1e-5), (CUBE, 1e-6)):
        require(np.all(np.abs(actual[key][index].astype(np.float64) - reference[key][index]) <= atol),
                "Reference initial/prefix state mismatch.")


def loop_metrics(data, reference, index, other=None):
    q = data[QPOS][:, 0, 0].astype(np.float64)
    delta = q[index] - reference[QPOS][index, 0, 0].astype(np.float64)
    xyz = data[CUBE][:, 0, :3].astype(np.float64)
    out = {"steps": len(data["actions"]), "max_deviation_rad": float(np.abs(delta).max()),
           "angle_RMSE_rad": float(np.sqrt(np.mean(delta ** 2))), "end_signed_rad": float(delta[-1]),
           "cube_net_m": float(np.linalg.norm(xyz[-1] - xyz[0])),
           "reward_sum": float(np.sum(data["rewards"], dtype=np.float64)),
           "success_steps": int(data[SUCCESS].sum()), "success_final": bool(data[SUCCESS][-1, 0])}
    if other is not None:
        out["max_same_intervention_A_difference_rad"] = float(np.abs(q[index] - other[QPOS][index, 0, 0]).max())
    return out


def policy_runs(config, stats):
    article = config["article"]
    _, _, candidates, labels, source, t = train_data(stats)
    net = model("H")
    report, pngs = {"seeds": {}}, 0
    for seed in (45, 46):
        groups = {}
        for group in config["groups"]:
            folder = ROOT / "rollouts" / f"seed-{seed:04d}" / group
            data, count = check_rollout(folder, article)
            pngs += count
            groups[group] = data
        a = groups[config["groups"][0]]
        n = min(len(d["actions"]) for d in groups.values())
        reference = a if article == 13 else numeric(ROOT / "references" / f"seed-{seed:04d}.npz")
        per_seed = {"groups": {}}
        for i, (group, data) in enumerate(groups.items()):
            folder = ROOT / "rollouts" / f"seed-{seed:04d}" / group
            compare_states(data, a, [0])
            if article == 14:
                compare_states(data, reference, np.arange(9))
                compare_states(data, a, np.arange(6, 10))
                codes = np.array([0] * 8 + [1] + [2 + i] * (len(data["actions"]) - 9), np.int64)
                equal(codes, data["audit/action_source"])
                require(data["actions"][8, 0] == np.float32(.1), "Override action differs.")
            if i == 0:
                expected = np.zeros((len(data["actions"]), 8), dtype=np.float32)
                expected[:, 0] = np.repeat(np.array([.1, -.1, .1, -.1], np.float32), 5)[:len(expected)]
                expected[:, 7] = 1
                if article == 14:
                    expected[8, 0] = .1
                equal(data["actions"], expected, 0)
            else:
                _, h, indices = features(data, stats)
                begin = 0 if article == 13 else 9
                queries = h[begin:]
                saved = numeric(folder / "policy-inputs.npz")
                equal(saved["x"], queries, 0)
                if article == 14:
                    equal(saved["t"], np.arange(9, len(data["actions"]), dtype=np.int64))
                    equal(saved["state_indices"], indices[9:])
                    equal(data["actions"][:9], a["actions"][:9], 0)
                if i == 1:
                    prediction = predict(net, queries)
                else:
                    d = distance(queries, candidates)
                    rows = np.array([nearest(v, source, t) for v in d], np.int64)
                    actual = numeric(folder / "nearest-neighbors.npz")
                    for key, value in (("row", rows), ("source_id", source[rows]),
                                       ("t" if article == 13 else "train_t", t[rows]),
                                       ("distance", d[np.arange(len(rows)), rows]), ("label", labels[rows].astype(np.float64))):
                        equal(actual[key], value)
                    prediction = labels[rows]
                require(np.allclose(prediction, data["actions"][begin:, 0], atol=1e-6, rtol=0), "Policy commands differ.")
            per_seed["groups"][group] = loop_metrics(data, reference, np.arange(0 if article == 13 else 9, n + 1), a if article == 14 else None)
        if article == 13:
            _, h, _ = features(a, stats)
            rows = np.array([nearest(v, source, t) for v in distance(h, candidates)], np.int64)
            per_seed["offline"] = {"H-MLP": loss(a["actions"][:, 0], predict(net, h)),
                                   "H-1NN": loss(a["actions"][:, 0], labels[rows])}
        report["seeds"][str(seed)] = per_seed
    return {**report, "pngs_verified": pngs}


def feedback_runs(config):
    report, pngs = {"seeds": {}}, 0
    for seed in (45, 46):
        data, count = check_rollout(ROOT / "rollouts" / f"seed-{seed:04d}" / config["groups"][0], 15)
        pngs += count
        reference = numeric(ROOT / "references" / f"seed-{seed:04d}" / "U.npz")
        a = numeric(ROOT / "references" / f"seed-{seed:04d}" / "A.npz")
        compare_states(data, a, np.arange(10))
        audit = numeric(ROOT / "rollouts" / f"seed-{seed:04d}" / config["groups"][0] / "feedback_audit.npz")
        times = np.arange(9, len(data["actions"]), dtype=np.int64)
        equal(audit["t"], times)
        equal(audit["reference_state_index"], times)
        equal(audit["actual_state_index"], times)
        bound = float(np.float32(.1))
        raw = reference["actions"][times, 0].astype(np.float64) + (
            reference[QPOS][times, 0, 0].astype(np.float64) - data[QPOS][times, 0, 0]) / .1
        error = reference[QPOS][times, 0, 0].astype(np.float64) - data[QPOS][times, 0, 0]
        values = {"q_ref": reference[QPOS][times, 0, 0].astype(np.float64),
                  "q_actual": data[QPOS][times, 0, 0].astype(np.float64), "error_rad": error,
                  "u_ff": reference["actions"][times, 0].astype(np.float64), "correction": error / .1,
                  "u_raw": raw, "u_clipped_float64": np.array([min(bound, max(-bound, v)) for v in raw])}
        for key, value in values.items():
            equal(audit[key], value)
        sent = values["u_clipped_float64"].astype(np.float32)
        equal(audit["u_sent"], sent, 0)
        equal(sent, data["actions"][times, 0], 0)
        equal(audit["was_clipped"], (raw < -bound) | (raw > bound))
        equal(audit["sent_at_bound"], np.abs(sent) == np.float32(.1))
        equal(audit["controller_target_qpos"], data["diagnostic/arm_target_qpos"][times, 0], 0)
        codes = np.array([0] * 8 + [1] + [2] * (len(data["actions"]) - 9), np.int64)
        equal(data["audit/action_source"], codes)
        equal(data["actions"][:9], a["actions"][:9], 0)
        groups = {"U": reference, "A": a,
                  "B": numeric(ROOT / "references" / f"seed-{seed:04d}/B.npz"),
                  "C": numeric(ROOT / "references" / f"seed-{seed:04d}/C.npz"), "D": data}
        n = min(len(v["actions"]) for v in groups.values())
        per_seed = {"groups": {g: loop_metrics(v, reference, np.arange(9, n + 1)) for g, v in groups.items()},
                    "feedback_decisions": len(times), "clipped_decisions": int(audit["was_clipped"].sum()),
                    "sent_at_bound_decisions": int(audit["sent_at_bound"].sum()),
                    "clipped_indices": times[audit["was_clipped"]].tolist()}
        report["seeds"][str(seed)] = per_seed
    return {**report, "pngs_verified": pngs}


def main(output):
    output.mkdir(parents=True, exist_ok=False)
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    config = read_json(ROOT / "config.json")
    manifest = read_json(ROOT / "package-manifest.json")["files"]
    for name, digest in manifest.items():
        path = (ROOT / name).resolve()
        require(path.is_relative_to(ROOT) and path.is_file() and sha(path) == digest, "Package checksum mismatch.")
    for path in ROOT.rglob("*.npz"):
        numeric(path)
    if config["article"] == 15:
        report = feedback_runs(config)
    else:
        stats = numeric(ROOT / "stats/train_stats.npz")
        report = diagnostics(stats, output) if config["article"] == 12 else policy_runs(config, stats)
    report.update(article=config["article"], result="PASS", training_calls=0, simulation_calls=0)
    check_report(report, read_json(ROOT / "expected-report.json"))
    require(not any(n == p or n.startswith(p + ".") for n in sys.modules for p in ("mani_skill", "sapien", "gymnasium")),
            "Offline evaluation imported a simulator.")
    with (output / "report.json").open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"result": "PASS", "article": config["article"], "pngs_verified": report["pngs_verified"],
                      "training_calls": 0, "simulation_calls": 0}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    main(parser.parse_args().output_dir)
